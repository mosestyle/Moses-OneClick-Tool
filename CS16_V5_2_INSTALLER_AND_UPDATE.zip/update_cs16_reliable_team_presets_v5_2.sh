#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

BOLD=$'\033[1m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; RED=$'\033[31m'; CYAN=$'\033[36m'; RESET=$'\033[0m'
say(){ printf '%s\n' "$*"; }
ok(){ printf '%s✓%s %s\n' "$GREEN" "$RESET" "$*"; }
warn(){ printf '%s!%s %s\n' "$YELLOW" "$RESET" "$*"; }
info(){ printf '%s→%s %s\n' "$CYAN" "$RESET" "$*"; }
die(){ printf '%sERROR:%s %s\n' "$RED" "$RESET" "$*" >&2; exit 1; }

pause_if_tty(){ if [[ -t 0 ]]; then printf '\n'; read -r -p "Press Enter to close..." _ || true; fi; }

BACKUP=""
on_error(){
    local code=$?
    printf '\n%s%sUPDATE FAILED%s\n' "$RED" "$BOLD" "$RESET" >&2
    printf 'Line: %s\nCommand: %s\n' "${1:-?}" "${2:-unknown}" >&2
    [[ -n "$BACKUP" && -d "$BACKUP" ]] && printf '\nBackup:\n%s\n' "$BACKUP" >&2
    pause_if_tty
    exit "$code"
}
trap 'on_error "$LINENO" "$BASH_COMMAND"' ERR

[[ ${EUID:-$(id -u)} -ne 0 ]] || die "Do not run with sudo/root."

for cmd in curl python3 tar find readlink cp mkdir date grep rm sed sha256sum awk; do
    command -v "$cmd" >/dev/null 2>&1 || die "Missing required program: $cmd"
done

WORK="$(mktemp -d -t cs16-v52-XXXXXX)"
cleanup(){ rm -rf "$WORK"; }
trap cleanup EXIT
trap 'on_error "$LINENO" "$BASH_COMMAND"' ERR

YAPB_VERSION="4.4.957"
YAPB_REPO="yapb/yapb"
GITHUB_UA="cs16-reliable-singleflight-v4.6"

say
say "${BOLD}CS 1.6 — Native YaPB Menu Bridge V5.2${RESET}"
say
say "Native YaPB client-command bridge."
say "The bot-add behavior is handled by YaPB\047s own native menu path."
say

# ----------------------------------------------------------------------
# Locate CS.
# ----------------------------------------------------------------------
declare -a CANDIDATES=()

add_candidate(){
    local p="${1%/}"
    [[ -d "$p" && -f "$p/liblist.gam" ]] || return 0
    p="$(readlink -f "$p" 2>/dev/null || printf '%s' "$p")"
    local x
    for x in "${CANDIDATES[@]:-}"; do [[ "$x" == "$p" ]] && return 0; done
    CANDIDATES+=("$p")
}

[[ -n "${CS16_DIR:-}" ]] && add_candidate "$CS16_DIR"
add_candidate "$HOME/.local/share/Steam/steamapps/common/Half-Life/cstrike"
add_candidate "$HOME/.steam/steam/steamapps/common/Half-Life/cstrike"
add_candidate "$HOME/.steam/root/steamapps/common/Half-Life/cstrike"

for root in "$HOME/.local/share/Steam" "$HOME/.steam" "/run/media/$USER" "/media/$USER" "/mnt"; do
    [[ -d "$root" ]] || continue
    while IFS= read -r -d '' p; do add_candidate "$p"; done < <(
        find "$root" -maxdepth 9 -type d -path '*/steamapps/common/Half-Life/cstrike' -print0 2>/dev/null || true
    )
done

((${#CANDIDATES[@]})) || die "Could not find Counter-Strike 1.6."

if ((${#CANDIDATES[@]} == 1)); then
    CSTRIKE="${CANDIDATES[0]}"
else
    say "Multiple CS 1.6 installations found:"
    for i in "${!CANDIDATES[@]}"; do printf '  %d) %s\n' "$((i+1))" "${CANDIDATES[$i]}"; done
    read -r -p "Choose [1-${#CANDIDATES[@]}]: " choice
    [[ "$choice" =~ ^[0-9]+$ ]] || die "Invalid choice."
    (( choice >= 1 && choice <= ${#CANDIDATES[@]} )) || die "Invalid choice."
    CSTRIKE="${CANDIDATES[$((choice-1))]}"
fi

HALFLIFE="$(dirname "$CSTRIKE")"
ok "Found CS 1.6: $CSTRIKE"

[[ -d "$CSTRIKE/addons/amxmodx" ]] || die "AMX Mod X missing. Use the FULL V5.2 installer."
[[ -f "$CSTRIKE/addons/amxmodx/configs/plugins.ini" ]] || die "plugins.ini missing."
[[ -f "$CSTRIKE/addons/metamod/plugins.ini" ]] || die "Metamod plugins.ini missing."

if [[ -f "$HALFLIFE/hl.exe" && ! -f "$HALFLIFE/hl_linux" ]]; then
    PLATFORM="windows"
elif [[ -f "$CSTRIKE/addons/yapb/bin/yapb.dll" ]]; then
    PLATFORM="windows"
else
    PLATFORM="linux"
fi
ok "Detected platform: $PLATFORM"

# ----------------------------------------------------------------------
# Backup current YaPB + all menu/plugin configs.
# ----------------------------------------------------------------------
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$CSTRIKE/cs16_v5_2_backup_$STAMP"
mkdir -p "$BACKUP"

for rel in \
    "addons/yapb" \
    "addons/metamod/plugins.ini" \
    "addons/amxmodx/plugins" \
    "addons/amxmodx/scripting" \
    "addons/amxmodx/configs" \
    "config.cfg" "autoexec.cfg" "userconfig.cfg"
do
    if [[ -e "$CSTRIKE/$rel" ]]; then
        mkdir -p "$BACKUP/$(dirname "$rel")"
        cp -a "$CSTRIKE/$rel" "$BACKUP/$rel"
    fi
done
ok "Backup created: $BACKUP"

# ----------------------------------------------------------------------
# Official YaPB release helper.
# ----------------------------------------------------------------------
github_asset_info(){
    local repo="$1" tag="$2" regex="$3"
    curl -fsSL --retry 3 --connect-timeout 20 \
        -A "$GITHUB_UA" -H "Accept: application/vnd.github+json" \
        "https://api.github.com/repos/$repo/releases/tags/$tag" |
    python3 -c '
import json,re,sys
pat=re.compile(sys.argv[1],re.I)
data=json.load(sys.stdin)
m=[a for a in data.get("assets",[]) if pat.search(a.get("name",""))]
if len(m)!=1:
    raise SystemExit("Expected exactly one matching YaPB asset; got %d: %r"%(len(m),[a.get("name") for a in data.get("assets",[])]))
a=m[0]
print(a["browser_download_url"]); print(a.get("digest") or "-"); print(a["name"])
' "$regex"
}

download_yapb(){
    local regex
    if [[ "$PLATFORM" == "windows" ]]; then regex='^yapb-.*-windows\.zip$'; else regex='^yapb-.*-linux\.tar\.xz$'; fi
    local meta url digest name
    meta="$(github_asset_info "$YAPB_REPO" "$YAPB_VERSION" "$regex")"
    url="$(printf '%s\n' "$meta"|sed -n '1p')"
    digest="$(printf '%s\n' "$meta"|sed -n '2p')"
    name="$(printf '%s\n' "$meta"|sed -n '3p')"
    YAPB_ARCHIVE="$WORK/$name"
    say "Downloading official YaPB $YAPB_VERSION..."
    curl -fL --retry 3 --connect-timeout 20 -A "$GITHUB_UA" --progress-bar "$url" -o "$YAPB_ARCHIVE"
    if [[ "$digest" == sha256:* ]]; then
        local actual; actual="$(sha256sum "$YAPB_ARCHIVE"|awk '{print $1}')"
        [[ "$actual" == "${digest#sha256:}" ]] || die "YaPB SHA-256 verification failed."
        ok "YaPB SHA-256 verified"
    fi
}

download_yapb
mkdir -p "$WORK/yapb"
case "$YAPB_ARCHIVE" in
    *.zip) python3 -m zipfile -e "$YAPB_ARCHIVE" "$WORK/yapb" ;;
    *.tar.xz) tar -xJf "$YAPB_ARCHIVE" -C "$WORK/yapb" ;;
    *) die "Unknown YaPB archive." ;;
esac

if [[ "$PLATFORM" == "windows" ]]; then
    NEW_BIN="$(find "$WORK/yapb" -type f -path '*/addons/yapb/bin/yapb.dll' -print -quit)"
else
    NEW_BIN="$(find "$WORK/yapb" -type f -path '*/addons/yapb/bin/yapb.so' -print -quit)"
fi
[[ -f "$NEW_BIN" ]] || die "Could not find YaPB binary in archive."

PKG_ROOT="$(python3 - "$NEW_BIN" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]).resolve()
for parent in p.parents:
    if parent.name=="addons":
        print(parent.parent); break
PY
)"
[[ -d "$PKG_ROOT/addons/yapb" ]] || die "Could not locate YaPB package root."

# Preserve learned/downloaded graph files.
if [[ -d "$CSTRIKE/addons/yapb/data/graph" ]]; then
    mkdir -p "$WORK/preserve"
    cp -a "$CSTRIKE/addons/yapb/data/graph" "$WORK/preserve/graph"
fi

rm -rf "$CSTRIKE/addons/yapb"
cp -a "$PKG_ROOT/addons/yapb" "$CSTRIKE/addons/yapb"
if [[ -d "$WORK/preserve/graph" ]]; then
    mkdir -p "$CSTRIKE/addons/yapb/data"
    rm -rf "$CSTRIKE/addons/yapb/data/graph"
    cp -a "$WORK/preserve/graph" "$CSTRIKE/addons/yapb/data/graph"
fi
ok "Returned YaPB to stable $YAPB_VERSION"
ok "Existing graph files preserved"

# ======================================================================
# FINAL V5.2 CONFIG STAGE
# ======================================================================

# ----------------------------------------------------------------------
# Guarantee YaPB is loaded EXACTLY ONCE by Metamod.
# ----------------------------------------------------------------------
META="$CSTRIKE/addons/metamod/plugins.ini"
python3 - "$META" "$PLATFORM" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); platform=sys.argv[2]
lines=p.read_text(errors="surrogateescape").splitlines()
out=[]
for line in lines:
    norm=line.strip().lower().replace("\\","/")
    if "addons/yapb/bin/yapb." in norm:
        continue
    out.append(line)
while out and not out[-1].strip(): out.pop()
if out: out.append("")
out.append(r"win32 addons\yapb\bin\yapb.dll" if platform=="windows" else "linux addons/yapb/bin/yapb.so")
p.write_text("\n".join(out)+"\n",errors="surrogateescape")
PY
ok "Metamod YaPB entry normalized to exactly one line"

# ----------------------------------------------------------------------
# Configure stable YaPB for our NON-MANUAL, quota-only add method.
# ----------------------------------------------------------------------
YAPB_CFG="$CSTRIKE/addons/yapb/conf/yapb.cfg"
[[ -f "$YAPB_CFG" ]] || die "YaPB config missing."

python3 - "$YAPB_CFG" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); text=p.read_text(errors="surrogateescape")
settings={
 "yb_quota":'"0"',
 "yb_quota_mode":'"normal"',
 "yb_autovacate":'"0"',
 "yb_join_after_player":'"0"',
 "yb_join_delay":'"0.0"',
 "yb_join_team":'"any"',
 "yb_difficulty":'"2"',
 "yb_difficulty_min":'"-1"',
 "yb_difficulty_max":'"-1"',
 "yb_difficulty_auto":'"0"',
 "yb_whose_your_daddy":'"0"',
 "yb_chat":'"0"',
 "yb_chat_percent":'"0"',
 "yb_radio_mode":'"0"',
 "yb_quota_adding_interval":'"0.1"',
 "yb_quota_maintain_interval":'"0.4"',
}
for key,val in settings.items():
    rx=re.compile(rf'(?m)^[ \t]*{re.escape(key)}[ \t]+.*$')
    repl=f"{key} {val}"
    if rx.search(text): text=rx.sub(repl,text,count=1)
    else:
        if text and not text.endswith("\n"): text+="\n"
        text+=repl+"\n"
p.write_text(text,errors="surrogateescape")
PY
ok "YaPB configured for exact quota-only creation"
ok "Bot chat/radio disabled; difficulty randomization disabled"

# ----------------------------------------------------------------------
# CRITICAL CLEANUP:
# AMXX auto-loads plugins-*.ini and map plugin lists too.
# Remove EVERY historic CS16 menu reference there, and delete old menu
# binaries, before installing one uniquely named V5.2 plugin.
# ----------------------------------------------------------------------
AMXX_CFG="$CSTRIKE/addons/amxmodx/configs"
AMXX_PLUGINS="$CSTRIKE/addons/amxmodx/plugins"
AMXX_SCRIPTING="$CSTRIKE/addons/amxmodx/scripting"

python3 - "$AMXX_CFG" <<'PY'
from pathlib import Path
import re,sys
root=Path(sys.argv[1])
files=[]
main=root/"plugins.ini"
if main.exists(): files.append(main)
files += list(root.glob("plugins-*.ini"))
maps=root/"maps"
if maps.exists(): files += list(maps.glob("plugins-*.ini"))
seen=set()
for p in files:
    p=p.resolve()
    if p in seen: continue
    seen.add(p)
    lines=p.read_text(errors="surrogateescape").splitlines()
    out=[ln for ln in lines if "cs16_game_menu" not in ln.lower()]
    p.write_text("\n".join(out)+("\n" if out else ""),errors="surrogateescape")
PY

find "$AMXX_PLUGINS" -maxdepth 1 -type f -iname 'cs16_game_menu*.amxx' -delete 2>/dev/null || true
find "$AMXX_SCRIPTING" -maxdepth 1 -type f -iname 'cs16_game_menu*.sma' -delete 2>/dev/null || true
ok "Removed all historic CS16 menu plugin references/binaries"

# ----------------------------------------------------------------------
# Normal number/numpad + H/J/G bindings.
# ----------------------------------------------------------------------
patch_binds(){
    local cfg="$1"; touch "$cfg"
    python3 - "$cfg" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); text=p.read_text(errors="surrogateescape")
keys=["0","1","2","3","4","5","6","7","8","9","KP_INS","KP_END","KP_DOWNARROW","KP_PGDN","KP_LEFTARROW","KP_5","KP_RIGHTARROW","KP_HOME","KP_UPARROW","KP_PGUP","h","j","g"]
for key in keys:
    text=re.sub(rf'(?im)^[ \t]*bind[ \t]+"?{re.escape(key)}"?[ \t]+"[^"]*"[ \t]*\r?\n?','',text)
for marker in ["CS16 DIRECT KEY V4.1","CS16 RELIABLE BINDS V4.2","CS16 NATIVE FIFO BINDS V4.3","CS16 RACEFIX BINDS V4.4","CS16 SINGLEFLIGHT BINDS V5.2"]:
    text=re.sub(rf'(?ms)^// >>> {re.escape(marker)} BEGIN >>>.*?^// <<< {re.escape(marker)} END <<<\s*','',text)
text=text.rstrip()
b=[
'bind "0" "slot10"','bind "1" "slot1"','bind "2" "slot2"','bind "3" "slot3"','bind "4" "slot4"','bind "5" "slot5"','bind "6" "slot6"','bind "7" "slot7"','bind "8" "slot8"','bind "9" "slot9"',
'bind "KP_INS" "slot10"','bind "KP_END" "slot1"','bind "KP_DOWNARROW" "slot2"','bind "KP_PGDN" "slot3"','bind "KP_LEFTARROW" "slot4"','bind "KP_5" "slot5"','bind "KP_RIGHTARROW" "slot6"','bind "KP_HOME" "slot7"','bind "KP_UPARROW" "slot8"','bind "KP_PGUP" "slot9"',
'bind "h" "cs16menu"','bind "j" "yb menu"','bind "g" "drop"']
block=["// >>> CS16 SINGLEFLIGHT BINDS V5.2 BEGIN >>>",*b,"// <<< CS16 SINGLEFLIGHT BINDS V5.2 END <<<",""]
if text: text+="\n\n"
text+="\n".join(block)
p.write_text(text,errors="surrogateescape")
PY
}
patch_binds "$CSTRIKE/config.cfg"
patch_binds "$CSTRIKE/autoexec.cfg"
[[ -f "$CSTRIKE/userconfig.cfg" ]] && patch_binds "$CSTRIKE/userconfig.cfg"
ok "H/J/G and normal number/numpad bindings restored"

# ----------------------------------------------------------------------
# V5.2 AMXX plugin.
#
# MANUAL ADD DOES NOT CALL yb add / yb fill AT ALL.
#
# One accepted click:
#   - locks all Add buttons
#   - remembers exact CT/T bot counts
#   - forces quota manager's next random bot to requested team
#   - raises yb_quota by EXACTLY one
#   - watches until exact requested count exists
#   - restores yb_join_team=any
#   - waits 0.75 sec for YaPB/engine to settle
#   - unlocks Add buttons
#
# NO USER ADD QUEUE. Repeated/spammed clicks while locked are discarded,
# so an old CT request can never survive and appear after a T click.
# ----------------------------------------------------------------------

# ======================================================================
# V5.2 — REDEATHMATCH MAP-WIDE SPAWN REPAIR
#
# ReDM's "preset" spawn style only works when:
#   addons/amxmodx/data/redm/<map>.spawns.json
# exists and contains usable points.
#
# The official ReDeathmatch package only ships preset files for a small
# number of maps. For the normal CS 1.6 map set we import the established
# CSDM spawn-point pack and convert it to ReDeathmatch's JSON format.
#
# Existing ReDM/custom .spawns.json files are NEVER overwritten.
#
# On a map that still has no preset file, our AMXX menu/plugin switches
# ReDeathmatch to its built-in "random" spawn style as a fallback.
# ======================================================================

say
say "${BOLD}Repairing ReDeathmatch map-wide spawns...${RESET}"

REDM_PLUGIN_DIR="$CSTRIKE/addons/amxmodx/plugins"
REDM_CONFIG_DIR="$CSTRIKE/addons/amxmodx/configs"
REDM_DATA_DIR="$CSTRIKE/addons/amxmodx/data/redm"

[[ -f "$REDM_PLUGIN_DIR/ReDeathmatch.amxx" ]] ||
    die "ReDeathmatch.amxx is missing. Use the FULL V5.2 installer."
[[ -f "$REDM_PLUGIN_DIR/redm_spawns.amxx" ]] ||
    die "redm_spawns.amxx is missing. Use the FULL V5.2 installer."

mkdir -p "$REDM_DATA_DIR"

# Guarantee the official spawn manager is loaded.
cat > "$REDM_CONFIG_DIR/plugins-redm.ini" <<'EOF'
; Main plugin
ReDeathmatch.amxx debug

; Spawn manager
redm_spawns.amxx debug
EOF

ok "ReDeathmatch + redm_spawns plugin loading repaired"

# ----------------------------------------------------------------------
# Import classic CSDM preset spawns.
#
# Arkshine/CSDM contains map-wide spawn-point files for the standard
# CS 1.6 maps (dust, assault, office, italy, aztec, nuke, cbble, etc.).
#
# ReDeathmatch itself contains an official legacy CSDM converter. We use
# the same field mapping directly here, but write the result to the ACTIVE
# ReDM data directory rather than its converter's /converted subfolder.
# ----------------------------------------------------------------------
CSDM_SPAWN_ZIP="$WORK/csdm-spawns-master.zip"
CSDM_SPAWN_EXTRACT="$WORK/csdm-spawns"

if curl -fL --retry 3 --connect-timeout 20 \
    --progress-bar \
    "https://github.com/Arkshine/CSDM/archive/refs/heads/master.zip" \
    -o "$CSDM_SPAWN_ZIP"
then
    mkdir -p "$CSDM_SPAWN_EXTRACT"

    python3 - "$CSDM_SPAWN_ZIP" "$CSDM_SPAWN_EXTRACT" "$REDM_DATA_DIR" <<'PY'
from pathlib import Path
import json
import sys
import zipfile

archive = Path(sys.argv[1])
extract_root = Path(sys.argv[2])
redm_data = Path(sys.argv[3])

with zipfile.ZipFile(archive) as zf:
    zf.extractall(extract_root)

spawn_files = sorted(
    p for p in extract_root.rglob("*.spawns.cfg")
    if "/amxmodx/configs/csdm/" in p.as_posix()
    and "/extraconfigs/" not in p.as_posix()
    and "/items/" not in p.as_posix()
)

converted = 0
preserved = 0
invalid = 0

for source in spawn_files:
    map_name = source.name[:-len(".spawns.cfg")]
    destination = redm_data / f"{map_name}.spawns.json"

    # Preserve official ReDM files and any user-created spawn files.
    if destination.exists() and destination.stat().st_size > 16:
        preserved += 1
        continue

    spawns = []

    for raw in source.read_text(errors="ignore").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith(";") or line.startswith("#") or line.startswith("//"):
            continue

        parts = line.split()

        # Matches ReDeathmatch's own ConvertOldSpawnsFile():
        # accepted old CSDM rows contain 3, 6, or 10 values.
        if len(parts) not in (3, 6, 10):
            invalid += 1
            continue

        try:
            origin = [float(parts[0]), float(parts[1]), float(parts[2])]

            if len(parts) >= 6:
                angle = [float(parts[3]), float(parts[4])]
            else:
                angle = [0.0, 0.0]

            if len(parts) == 10:
                team = int(float(parts[6]))
                vangle = [float(parts[7]), float(parts[8])]
            else:
                team = 0
                vangle = [0.0, 0.0]
        except (ValueError, IndexError):
            invalid += 1
            continue

        spawns.append({
            "team": team,
            "group": "",
            "origin": origin,
            "angle": angle,
            "vAngle": vangle,
        })

    if not spawns:
        continue

    destination.write_text(
        json.dumps({"spawns": spawns}, indent=4) + "\n",
        encoding="utf-8",
    )
    converted += 1

print(f"Converted new map spawn files: {converted}")
print(f"Existing ReDM/custom spawn files preserved: {preserved}")
if invalid:
    print(f"Skipped malformed legacy spawn rows: {invalid}")
PY

    ok "Installed/converted map-wide CSDM spawn presets"
else
    warn "Could not download the CSDM spawn pack."
    warn "Preset maps already installed will still work; unsupported maps will use ReDM random fallback."
fi

SPAWN_FILE_COUNT="$(find "$REDM_DATA_DIR" -maxdepth 1 -type f -name '*.spawns.json' | wc -l | tr -d ' ')"
ok "ReDeathmatch preset maps available: $SPAWN_FILE_COUNT"

# ----------------------------------------------------------------------
# Force our two Deathmatch profiles to enable the spawn manager.
# Existing profile contents are otherwise preserved.
# ----------------------------------------------------------------------
python3 - \
    "$CSTRIKE/addons/amxmodx/configs/redm/gamemode_tdm.json" \
    "$CSTRIKE/addons/amxmodx/configs/redm/gamemode_ffa.json" <<'PY'
from pathlib import Path
import json
import re
import sys

def strip_comments(text):
    out = []
    i = 0
    in_string = False
    escaped = False

    while i < len(text):
        ch = text[i]

        if in_string:
            out.append(ch)
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            i += 1
            continue

        if ch == '"':
            in_string = True
            out.append(ch)
            i += 1
            continue

        if ch == "/" and i + 1 < len(text) and text[i + 1] == "/":
            i += 2
            while i < len(text) and text[i] not in "\r\n":
                i += 1
            continue

        if ch == "/" and i + 1 < len(text) and text[i + 1] == "*":
            i += 2
            while i + 1 < len(text) and not (text[i] == "*" and text[i + 1] == "/"):
                i += 1
            i += 2
            continue

        out.append(ch)
        i += 1

    return "".join(out)

for filename in sys.argv[1:]:
    p = Path(filename)
    if not p.exists():
        continue

    data = json.loads(strip_comments(p.read_text(encoding="utf-8")))
    cvars = data.setdefault("cvars", {})

    # Preset is preferred. The V5.2 AMXX helper automatically changes
    # this to ReDM's built-in "random" style when the current map has
    # no .spawns.json file.
    cvars["redm_randomspawn"] = "1"
    cvars["redm_randomspawn_los"] = "1"
    cvars["redm_randomspawn_dist"] = "1500"
    cvars["redm_spawn_preset"] = "preset"

    p.write_text(
        json.dumps(data, indent=4, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
PY

ok "TDM + FFA profiles configured for map-wide spawning"

# ----------------------------------------------------------------------
# Rebuild H-menu mode configs.
#
# cs16_spawn_auto:
#   preset file exists -> safe preset CSDM/ReDM points
#   no preset exists   -> ReDM's procedural random-spawn fallback
# ----------------------------------------------------------------------
mkdir -p "$CSTRIKE/gamesettings"

cat > "$CSTRIKE/gamesettings/tdm.cfg" <<'EOF'
redm_enable
redm_reload gamemode_tdm.json
redm_randomspawn "1"
mp_freeforall "0"
mp_autoteambalance "0"
mp_limitteams "0"
yb_csdm_mode "1"
yb_ignore_objectives "1"
cs16_spawn_auto
cs16_apply_spawn_protection
mapchangecfgfile "gamesettings/tdm.cfg"
sv_restart "1"
EOF

cat > "$CSTRIKE/gamesettings/ffa.cfg" <<'EOF'
redm_enable
redm_reload gamemode_ffa.json
redm_randomspawn "1"
mp_freeforall "1"
mp_autoteambalance "0"
mp_limitteams "0"
yb_csdm_mode "2"
yb_ignore_objectives "1"
cs16_spawn_auto
cs16_apply_spawn_protection
mapchangecfgfile "gamesettings/ffa.cfg"
sv_restart "1"
EOF

cat > "$CSTRIKE/gamesettings/normal.cfg" <<'EOF'
redm_disable
redm_randomspawn "0"
mp_respawn_immunitytime "0"
mp_respawn_immunity_effects "0"
mp_freeforall "0"
mp_infinite_ammo "0"
mp_autoteambalance "0"
mp_limitteams "0"
yb_csdm_mode "3"
yb_ignore_objectives "0"
mapchangecfgfile "gamesettings/normal.cfg"
sv_restart "1"
EOF

ok "TDM / FFA / Normal mode switching updated"


# ----------------------------------------------------------------------
# V5.2 persistent spawn-protection preference.
# 1.0 sec by default. Existing user choice is preserved on updates.
# ----------------------------------------------------------------------
SPAWN_PROTECT_VALUE="$CSTRIKE/addons/amxmodx/configs/cs16_spawn_protection.txt"
if [[ ! -f "$SPAWN_PROTECT_VALUE" ]]; then
    printf '%s\n' "1.0" > "$SPAWN_PROTECT_VALUE"
fi
ok "Spawn protection preference ready (default 1.0 sec)"

SOURCE="$WORK/cs16_game_menu_v52.sma"
cat > "$SOURCE" <<'PAWN'
#include <amxmodx>
#include <amxmisc>


#define PLUGIN  "CS16 Easy Game Settings"
#define VERSION "5.2"
#define AUTHOR  "OpenAI"

#define TASK_SHOW_MAIN       1100
#define TASK_REFRESH_BOTS    3300
#define TASK_LOAD_PROTECT    5500
#define TASK_FILL_RESET      6600
#define TASK_FILL_WORKER     6700

new g_maxplayers
new Float:g_spawn_protection = 1.0
new bool:g_preset_fill_active
new g_preset_fill_owner
new g_preset_fill_target
new g_preset_fill_need_ct
new g_preset_fill_need_t
new g_preset_fill_wait_team
new g_preset_fill_before_team
new g_preset_fill_checks


public plugin_init()
{
    register_plugin(PLUGIN, VERSION, AUTHOR)

    register_clcmd("cs16menu", "cmd_open_main")
    register_clcmd("say /gamesettings", "cmd_open_main")
    register_clcmd("say_team /gamesettings", "cmd_open_main")

    register_srvcmd("cs16_spawn_auto", "cmd_spawn_auto")
    register_srvcmd("cs16_apply_spawn_protection", "cmd_apply_spawn_protection")

    register_menucmd(register_menuid("CS16 Game Settings"),
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_4|MENU_KEY_5|MENU_KEY_6|MENU_KEY_7|MENU_KEY_8|MENU_KEY_9,
        "handle_main")

    register_menucmd(register_menuid("CS16 Bot Difficulty"),
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_4|MENU_KEY_5|MENU_KEY_8|MENU_KEY_9,
        "handle_difficulty")

    register_menucmd(register_menuid("CS16 Add Bots"),
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_4|MENU_KEY_5|MENU_KEY_6|MENU_KEY_7|MENU_KEY_8|MENU_KEY_9,
        "handle_add_bots")

    register_menucmd(register_menuid("CS16 Infinite Ammo"),
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_8|MENU_KEY_9,
        "handle_ammo")

    register_menucmd(register_menuid("CS16 Spawn Protection"),
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_4|MENU_KEY_5|MENU_KEY_6|MENU_KEY_7|MENU_KEY_8|MENU_KEY_9,
        "handle_spawn_protection")

    g_maxplayers = get_maxplayers()

    set_cvar_num("bot_quota", 0)
    set_cvar_num("yb_quota", 0)

    set_cvar_string("yb_quota_mode", "normal")
    set_cvar_num("yb_autovacate", 0)
    set_cvar_num("yb_join_after_player", 0)
    set_cvar_float("yb_join_delay", 0.0)
    set_cvar_string("yb_join_team", "any")

    set_cvar_num("yb_difficulty_min", -1)
    set_cvar_num("yb_difficulty_max", -1)
    set_cvar_num("yb_difficulty_auto", 0)
    set_cvar_num("yb_whose_your_daddy", 0)

    set_cvar_num("yb_chat", 0)
    set_cvar_num("yb_chat_percent", 0)
    set_cvar_num("yb_radio_mode", 0)

    set_cvar_num("mp_limitteams", 0)
    set_cvar_num("mp_autoteambalance", 0)

    // Repair spawn style after all AMXX/ReDM config files finish loading.
    set_task(1.0, "task_spawn_auto")
    set_task(1.1, "task_load_spawn_protection", TASK_LOAD_PROTECT)
}

public task_load_spawn_protection()
{
    load_spawn_protection()

    if (get_cvar_num("redm_active"))
        apply_spawn_protection()
}

stock get_spawn_protection_path(path[], len)
{
    new configsDir[192]
    get_configsdir(configsDir, charsmax(configsDir))
    formatex(path, len, "%s/cs16_spawn_protection.txt", configsDir)
}

stock load_spawn_protection()
{
    new path[256]
    new line[64]
    new textLen

    get_spawn_protection_path(path, charsmax(path))

    if (!file_exists(path))
    {
        g_spawn_protection = 1.0
        save_spawn_protection()
        return
    }

    if (read_file(path, 0, line, charsmax(line), textLen))
    {
        trim(line)

        new Float:value = str_to_float(line)

        if (value < 0.0)
            value = 0.0

        if (value > 10.0)
            value = 10.0

        g_spawn_protection = value
    }
}

stock save_spawn_protection()
{
    new path[256]
    new value[32]

    get_spawn_protection_path(path, charsmax(path))
    formatex(value, charsmax(value), "%.1f", g_spawn_protection)

    delete_file(path)
    write_file(path, value)
}

stock apply_spawn_protection()
{
    if (!get_cvar_num("redm_active"))
        return

    set_cvar_float("mp_respawn_immunitytime", g_spawn_protection)

    if (g_spawn_protection > 0.0)
        set_cvar_num("mp_respawn_immunity_effects", 1)
    else
        set_cvar_num("mp_respawn_immunity_effects", 0)

    // Keep protection while moving; firing a weapon ends it early.
    set_cvar_num("mp_respawn_immunity_force_unset", 2)
}

public cmd_apply_spawn_protection()
{
    apply_spawn_protection()
    return PLUGIN_HANDLED
}

public task_spawn_auto()
{
    if (get_cvar_num("redm_active"))
        apply_spawn_style()
}

public cmd_spawn_auto()
{
    apply_spawn_style()
    return PLUGIN_HANDLED
}

stock apply_spawn_style()
{
    // Only relevant while ReDeathmatch is active.
    if (!get_cvar_num("redm_active"))
        return

    new mapName[64]
    new dataDir[192]
    new spawnFile[256]

    get_mapname(mapName, charsmax(mapName))
    get_datadir(dataDir, charsmax(dataDir))

    formatex(
        spawnFile,
        charsmax(spawnFile),
        "%s/redm/%s.spawns.json",
        dataDir,
        mapName
    )

    set_cvar_num("redm_randomspawn", 1)

    if (file_exists(spawnFile))
    {
        // Best option: hand-made/converted map-wide spawn points.
        // ReDM checks hull, distance and enemy LOS for these.
        set_cvar_string("redm_spawn_preset", "preset")
        server_print("[CS16] ReDM spawn mode: preset (%s)", mapName)
    }
    else
    {
        // No map-specific spawn data: never fall back to CT/T bases.
        // Use ReDeathmatch's built-in procedural random style instead.
        set_cvar_string("redm_spawn_preset", "random")
        server_print("[CS16] ReDM spawn mode: random fallback (%s)", mapName)
    }
}

public cmd_open_main(id)
{
    if (!is_user_connected(id))
        return PLUGIN_HANDLED

    show_main(id)
    return PLUGIN_HANDLED
}

stock show_main(id)
{
    new menu[768], len

    len += formatex(menu[len], charsmax(menu)-len, "GAME SETTINGS^n^n")
    len += formatex(menu[len], charsmax(menu)-len, "1. Team Deathmatch^n")
    len += formatex(menu[len], charsmax(menu)-len, "2. Free For All^n")
    len += formatex(menu[len], charsmax(menu)-len, "3. Normal CS^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "4. Add Bots^n")
    len += formatex(menu[len], charsmax(menu)-len, "5. Bot Difficulty^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "6. Infinite Ammo^n")
    len += formatex(menu[len], charsmax(menu)-len, "7. Remove All Bots^n")
    len += formatex(menu[len], charsmax(menu)-len, "8. Spawn Protection^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "9. Exit")

    show_menu(id,
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_4|MENU_KEY_5|MENU_KEY_6|MENU_KEY_7|MENU_KEY_8|MENU_KEY_9,
        menu, -1, "CS16 Game Settings")
}

public handle_main(id, key)
{
    switch (key)
    {
        case 0:
        {
            server_cmd("exec gamesettings/tdm.cfg")
            server_exec()
            apply_spawn_style()
            apply_spawn_protection()
            schedule_main(id, 0.30)
        }
        case 1:
        {
            server_cmd("exec gamesettings/ffa.cfg")
            server_exec()
            apply_spawn_style()
            apply_spawn_protection()
            schedule_main(id, 0.30)
        }
        case 2:
        {
            server_cmd("exec gamesettings/normal.cfg")
            server_exec()
            schedule_main(id, 0.30)
        }
        case 3:
        {
            show_add_bots(id)
        }
        case 4:
        {
            show_difficulty(id)
        }
        case 5:
        {
            show_ammo(id)
        }
        case 6:
        {
            server_cmd("yb kickall instant")
            server_exec()
            show_main(id)
        }
        case 7:
        {
            show_spawn_protection(id)
        }
        case 8:
        {
            // 9 = Exit
        }
    }

    return PLUGIN_HANDLED
}

stock show_difficulty(id)
{
    new menu[768], len
    new current = get_cvar_num("yb_difficulty")

    len += formatex(menu[len], charsmax(menu)-len, "BOT DIFFICULTY^n")
    len += formatex(menu[len], charsmax(menu)-len, "Current: %d^n^n", current)

    len += formatex(menu[len], charsmax(menu)-len, "1. Newbie - Super Easy^n")
    len += formatex(menu[len], charsmax(menu)-len, "2. Average - Easy^n")
    len += formatex(menu[len], charsmax(menu)-len, "3. Normal - Medium^n")
    len += formatex(menu[len], charsmax(menu)-len, "4. Professional - Hard^n")
    len += formatex(menu[len], charsmax(menu)-len, "5. Godlike - Super Hard^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "8. Back^n")
    len += formatex(menu[len], charsmax(menu)-len, "9. Exit")

    show_menu(id,
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_4|MENU_KEY_5|MENU_KEY_8|MENU_KEY_9,
        menu, -1, "CS16 Bot Difficulty")
}

public handle_difficulty(id, key)
{
    if (key >= 0 && key <= 4)
    {
        set_cvar_num("yb_difficulty", key)
        set_cvar_num("yb_difficulty_min", -1)
        set_cvar_num("yb_difficulty_max", -1)
        set_cvar_num("yb_difficulty_auto", 0)
        set_cvar_num("yb_whose_your_daddy", 0)

        show_main(id)
        return PLUGIN_HANDLED
    }

    if (key == 7)
        show_main(id)

    return PLUGIN_HANDLED
}

stock count_team_bots(team)
{
    new count = 0

    for (new i = 1; i <= g_maxplayers; i++)
    {
        if (is_user_connected(i) && is_user_bot(i) && get_user_team(i) == team)
            count++
    }

    return count
}

stock count_team_humans(team)
{
    new count = 0

    for (new i = 1; i <= g_maxplayers; i++)
    {
        if (is_user_connected(i) && !is_user_bot(i) && get_user_team(i) == team)
            count++
    }

    return count
}

stock show_add_bots(id)
{
    new ctBots = count_team_bots(2)
    new tBots = count_team_bots(1)

    new ctTotal = ctBots + count_team_humans(2)
    new tTotal = tBots + count_team_humans(1)

    new menu[896], len

    len += formatex(menu[len], charsmax(menu)-len, "ADD BOTS^n")
    len += formatex(menu[len], charsmax(menu)-len,
        "CT: %d players (%d bots)   T: %d players (%d bots)^n",
        ctTotal, ctBots, tTotal, tBots)

    if (g_preset_fill_active)
        len += formatex(menu[len], charsmax(menu)-len,
            "Filling teams to %dv%d...^n^n",
            g_preset_fill_target, g_preset_fill_target)
    else
        len += formatex(menu[len], charsmax(menu)-len, "^n")

    len += formatex(menu[len], charsmax(menu)-len, "1. Add Counter-Terrorist Bot^n")
    len += formatex(menu[len], charsmax(menu)-len, "2. Remove Counter-Terrorist Bot^n")
    len += formatex(menu[len], charsmax(menu)-len, "3. Add Terrorist Bot^n")
    len += formatex(menu[len], charsmax(menu)-len, "4. Remove Terrorist Bot^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "5. Fill Teams - 5v5^n")
    len += formatex(menu[len], charsmax(menu)-len, "6. Fill Teams - 6v6^n")
    len += formatex(menu[len], charsmax(menu)-len, "7. Fill Teams - 8v8^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "8. Back^n")
    len += formatex(menu[len], charsmax(menu)-len, "9. Exit")

    show_menu(id,
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_4|MENU_KEY_5|MENU_KEY_6|MENU_KEY_7|MENU_KEY_8|MENU_KEY_9,
        menu, -1, "CS16 Add Bots")
}

/*
 * V5.2: TRUE YaPB command shortcut.
 *
 * No menu automation at all.
 *
 * YaPB exposes:
 *   yb add [difficulty] [personality] [team] [model] [name]
 *
 * "*" means "use YaPB/default/random choice" for optional values.
 *
 * Our buttons therefore execute ONE YaPB command AS THE REAL CLIENT:
 *
 *   CT -> yb add <difficulty> * 2 *
 *   T  -> yb add <difficulty> * 1 *
 *
 * This reaches YaPB's normal cmdAddBot() directly. The native YaPB
 * "Add a Bot, Specified" menu ultimately calls the same bots.addbot()
 * routine, so there is no reason to open or navigate YaPB's menus.
 */
stock yapb_direct_add_shortcut(id, team)
{
    if (!is_user_connected(id))
        return

    new difficulty = get_cvar_num("yb_difficulty")

    if (difficulty < 0 || difficulty > 4)
        difficulty = 2

    if (team == 2)
        console_cmd(id, "yb add %d * 2 *", difficulty)
    else
        console_cmd(id, "yb add %d * 1 *", difficulty)

    // Our own Add Bots menu is simply restored after the selection.
    // No YaPB UI is ever shown.
    show_add_bots(id)

    remove_task(id + TASK_REFRESH_BOTS)
    set_task(0.12, "task_refresh_bots", id + TASK_REFRESH_BOTS)
}

public task_refresh_bots(taskid)
{
    new id = taskid - TASK_REFRESH_BOTS

    if (id >= 1 && id <= 32 && is_user_connected(id))
        show_add_bots(id)
}

public handle_add_bots(id, key)
{
    new difficulty = get_cvar_num("yb_difficulty")

    if (difficulty < 0 || difficulty > 4)
        difficulty = 2

    // During an automatic preset build, ignore Add/Remove/Fill presses.
    // Back/Exit remain usable.
    if (g_preset_fill_active && key >= 0 && key <= 6)
    {
        show_add_bots(id)
        return PLUGIN_HANDLED
    }

    switch (key)
    {
        case 0:
        {
            yapb_direct_add_shortcut(id, 2)
        }
        case 1:
        {
            server_cmd("yb kick_ct")
            server_exec()
            show_add_bots(id)
        }
        case 2:
        {
            yapb_direct_add_shortcut(id, 1)
        }
        case 3:
        {
            server_cmd("yb kick_t")
            server_exec()
            show_add_bots(id)
        }
        case 4:
        {
            begin_reliable_fill(id, 5, difficulty)
        }
        case 5:
        {
            begin_reliable_fill(id, 6, difficulty)
        }
        case 6:
        {
            begin_reliable_fill(id, 8, difficulty)
        }
        case 7:
        {
            show_main(id)
        }
        case 8:
        {
            // 9 = Exit
        }
    }

    return PLUGIN_HANDLED
}

/*
 * V5.2 RELIABLE PRESET BUILDER
 *
 * We intentionally DO NOT use YaPB's batch "yb fill" command here.
 *
 * One preset click:
 *   1) quota = 0
 *   2) yb kickall instant
 *   3) wait until YaPB really reports zero bots
 *   4) calculate required bots from HUMAN counts
 *   5) add ONE CT/T bot at a time using the same direct YaPB command
 *      that already works for manual Add:
 *
 *        yb add <difficulty> * <team> *
 *
 *   6) after every request, wait until that team's real bot count
 *      has increased by exactly one before sending the next request
 *   7) finish only when BOTH team totals equal the requested target
 *
 * This means there is never a large YaPB add-request batch and never
 * several pending team requests fighting during a fresh server startup.
 */
stock begin_reliable_fill(id, target, difficulty)
{
    if (g_preset_fill_active)
        return

    g_preset_fill_active = true
    g_preset_fill_owner = id
    g_preset_fill_target = target
    g_preset_fill_need_ct = 0
    g_preset_fill_need_t = 0
    g_preset_fill_wait_team = 0
    g_preset_fill_before_team = 0
    g_preset_fill_checks = 0

    // Stop all automatic/quota work and clear YaPB's pending add queue.
    set_cvar_num("yb_quota", 0)
    set_cvar_string("yb_quota_mode", "normal")
    set_cvar_num("yb_autovacate", 0)
    set_cvar_num("yb_join_after_player", 0)
    set_cvar_string("yb_join_team", "any")

    server_cmd("yb kickall instant")
    server_exec()

    remove_task(TASK_FILL_RESET)
    remove_task(TASK_FILL_WORKER)

    set_task(0.10, "task_fill_wait_for_zero", TASK_FILL_RESET)
    show_add_bots(id)
}

public task_fill_wait_for_zero()
{
    if (!g_preset_fill_active)
        return

    g_preset_fill_checks++

    // kickall instant clears YaPB's pending add requests immediately,
    // but fake clients may take a few frames to disappear from AMXX.
    if (count_team_bots(2) > 0 || count_team_bots(1) > 0)
    {
        if (g_preset_fill_checks >= 50)
        {
            finish_reliable_fill(false)
            return
        }

        set_cvar_num("yb_quota", 0)
        set_task(0.10, "task_fill_wait_for_zero", TASK_FILL_RESET)
        return
    }

    new ctHumans = count_team_humans(2)
    new tHumans = count_team_humans(1)

    g_preset_fill_need_ct = g_preset_fill_target - ctHumans
    g_preset_fill_need_t = g_preset_fill_target - tHumans

    if (g_preset_fill_need_ct < 0)
        g_preset_fill_need_ct = 0

    if (g_preset_fill_need_t < 0)
        g_preset_fill_need_t = 0

    g_preset_fill_checks = 0
    preset_fill_next()
}

stock preset_fill_next()
{
    if (!g_preset_fill_active)
        return

    if (g_preset_fill_owner < 1 || g_preset_fill_owner > 32 ||
        !is_user_connected(g_preset_fill_owner))
    {
        finish_reliable_fill(false)
        return
    }

    // Done only when the REAL player totals match the requested preset.
    new ctTotal = count_team_bots(2) + count_team_humans(2)
    new tTotal  = count_team_bots(1) + count_team_humans(1)

    if (ctTotal == g_preset_fill_target && tTotal == g_preset_fill_target)
    {
        finish_reliable_fill(true)
        return
    }

    new difficulty = get_cvar_num("yb_difficulty")

    if (difficulty < 0 || difficulty > 4)
        difficulty = 2

    if (g_preset_fill_need_ct > 0)
    {
        g_preset_fill_need_ct--
        g_preset_fill_wait_team = 2
        g_preset_fill_before_team = count_team_bots(2)
        g_preset_fill_checks = 0

        // SAME known-good path as manual Add CT.
        console_cmd(
            g_preset_fill_owner,
            "yb add %d * 2 *",
            difficulty
        )

        set_task(0.05, "task_fill_wait_one_bot", TASK_FILL_WORKER)
        return
    }

    if (g_preset_fill_need_t > 0)
    {
        g_preset_fill_need_t--
        g_preset_fill_wait_team = 1
        g_preset_fill_before_team = count_team_bots(1)
        g_preset_fill_checks = 0

        // SAME known-good path as manual Add T.
        console_cmd(
            g_preset_fill_owner,
            "yb add %d * 1 *",
            difficulty
        )

        set_task(0.05, "task_fill_wait_one_bot", TASK_FILL_WORKER)
        return
    }

    // Defensive correction if something external changed a team count.
    ctTotal = count_team_bots(2) + count_team_humans(2)
    tTotal  = count_team_bots(1) + count_team_humans(1)

    if (ctTotal > g_preset_fill_target)
    {
        server_cmd("yb kick_ct")
        server_exec()
        set_task(0.10, "task_fill_recalculate", TASK_FILL_WORKER)
        return
    }

    if (tTotal > g_preset_fill_target)
    {
        server_cmd("yb kick_t")
        server_exec()
        set_task(0.10, "task_fill_recalculate", TASK_FILL_WORKER)
        return
    }

    task_fill_recalculate()
}

public task_fill_wait_one_bot()
{
    if (!g_preset_fill_active)
        return

    g_preset_fill_checks++

    new nowCount

    if (g_preset_fill_wait_team == 2)
        nowCount = count_team_bots(2)
    else
        nowCount = count_team_bots(1)

    if (nowCount >= g_preset_fill_before_team + 1)
    {
        // YaPB manual add increments quota by one; synchronise it to the
        // actual number of connected bots before the next request.
        set_cvar_num("yb_quota", count_team_bots(2) + count_team_bots(1))

        g_preset_fill_wait_team = 0
        g_preset_fill_checks = 0

        // Very small handoff. This is automatic preset building, not
        // keyboard debounce.
        set_task(0.03, "task_fill_continue", TASK_FILL_WORKER)
        return
    }

    if (g_preset_fill_checks >= 80) // ~4 seconds for one bot
    {
        finish_reliable_fill(false)
        return
    }

    set_task(0.05, "task_fill_wait_one_bot", TASK_FILL_WORKER)
}

public task_fill_continue()
{
    preset_fill_next()
}

public task_fill_recalculate()
{
    if (!g_preset_fill_active)
        return

    new ctTotal = count_team_bots(2) + count_team_humans(2)
    new tTotal  = count_team_bots(1) + count_team_humans(1)

    g_preset_fill_need_ct = g_preset_fill_target - ctTotal
    g_preset_fill_need_t  = g_preset_fill_target - tTotal

    if (g_preset_fill_need_ct < 0)
        g_preset_fill_need_ct = 0

    if (g_preset_fill_need_t < 0)
        g_preset_fill_need_t = 0

    set_cvar_num("yb_quota", count_team_bots(2) + count_team_bots(1))
    preset_fill_next()
}

stock finish_reliable_fill(bool:success)
{
    remove_task(TASK_FILL_RESET)
    remove_task(TASK_FILL_WORKER)

    set_cvar_string("yb_join_team", "any")
    set_cvar_num("yb_quota", count_team_bots(2) + count_team_bots(1))

    new owner = g_preset_fill_owner

    g_preset_fill_active = false
    g_preset_fill_owner = 0
    g_preset_fill_wait_team = 0

    if (owner >= 1 && owner <= 32 && is_user_connected(owner))
    {
        if (success)
        {
            client_print(
                owner,
                print_chat,
                "[GAME SETTINGS] Teams filled exactly to %dv%d.",
                g_preset_fill_target,
                g_preset_fill_target
            )
        }
        else
        {
            client_print(
                owner,
                print_chat,
                "[GAME SETTINGS] Fill did not finish. Press the preset once more."
            )
        }

        show_add_bots(owner)
    }
}

stock show_spawn_protection(id)
{
    new menu[768], len

    len += formatex(menu[len], charsmax(menu)-len, "SPAWN PROTECTION^n")
    len += formatex(menu[len], charsmax(menu)-len, "Current: %.1f sec^n", g_spawn_protection)
    len += formatex(menu[len], charsmax(menu)-len, "Ends early when you fire.^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "1. Off^n")
    len += formatex(menu[len], charsmax(menu)-len, "2. 0.5 sec^n")
    len += formatex(menu[len], charsmax(menu)-len, "3. 1.0 sec - Recommended^n")
    len += formatex(menu[len], charsmax(menu)-len, "4. 1.5 sec^n")
    len += formatex(menu[len], charsmax(menu)-len, "5. 2.0 sec^n")
    len += formatex(menu[len], charsmax(menu)-len, "6. 3.0 sec^n")
    len += formatex(menu[len], charsmax(menu)-len, "7. 5.0 sec^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "8. Back^n")
    len += formatex(menu[len], charsmax(menu)-len, "9. Exit")

    show_menu(id,
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_4|MENU_KEY_5|MENU_KEY_6|MENU_KEY_7|MENU_KEY_8|MENU_KEY_9,
        menu, -1, "CS16 Spawn Protection")
}

stock set_spawn_protection_value(id, Float:value)
{
    g_spawn_protection = value
    save_spawn_protection()

    if (get_cvar_num("redm_active"))
        apply_spawn_protection()

    client_print(id, print_chat, "[GAME SETTINGS] Spawn protection: %.1f sec.", value)
    show_spawn_protection(id)
}

public handle_spawn_protection(id, key)
{
    switch (key)
    {
        case 0: set_spawn_protection_value(id, 0.0)
        case 1: set_spawn_protection_value(id, 0.5)
        case 2: set_spawn_protection_value(id, 1.0)
        case 3: set_spawn_protection_value(id, 1.5)
        case 4: set_spawn_protection_value(id, 2.0)
        case 5: set_spawn_protection_value(id, 3.0)
        case 6: set_spawn_protection_value(id, 5.0)
        case 7: show_main(id)
        case 8:
        {
            // 9 = Exit
        }
    }

    return PLUGIN_HANDLED
}

stock show_ammo(id)
{
    new current = get_cvar_num("mp_infinite_ammo")
    new menu[640], len

    len += formatex(menu[len], charsmax(menu)-len, "INFINITE AMMO^n")
    len += formatex(menu[len], charsmax(menu)-len, "Current: %d^n^n", current)

    len += formatex(menu[len], charsmax(menu)-len, "1. ON - No Reload^n")
    len += formatex(menu[len], charsmax(menu)-len, "2. ON - Reload Normally^n")
    len += formatex(menu[len], charsmax(menu)-len, "3. OFF^n^n")

    len += formatex(menu[len], charsmax(menu)-len, "8. Back^n")
    len += formatex(menu[len], charsmax(menu)-len, "9. Exit")

    show_menu(id,
        MENU_KEY_1|MENU_KEY_2|MENU_KEY_3|MENU_KEY_8|MENU_KEY_9,
        menu, -1, "CS16 Infinite Ammo")
}

public handle_ammo(id, key)
{
    switch (key)
    {
        case 0:
        {
            set_cvar_num("mp_infinite_ammo", 1)
            show_ammo(id)
        }
        case 1:
        {
            set_cvar_num("mp_infinite_ammo", 2)
            show_ammo(id)
        }
        case 2:
        {
            set_cvar_num("mp_infinite_ammo", 0)
            show_ammo(id)
        }
        case 7:
        {
            show_main(id)
        }
        case 8:
        {
            // 9 = Exit
        }
    }

    return PLUGIN_HANDLED
}

stock schedule_main(id, Float:delay)
{
    remove_task(id + TASK_SHOW_MAIN)
    set_task(delay, "task_show_main", id + TASK_SHOW_MAIN)
}

public task_show_main(taskid)
{
    new id = taskid - TASK_SHOW_MAIN

    if (id >= 1 && id <= 32 && is_user_connected(id))
        show_main(id)
}

PAWN

mkdir -p "$AMXX_SCRIPTING"
cp -f "$SOURCE" "$AMXX_SCRIPTING/cs16_game_menu_v52.sma"

BUILD_OUTPUT="$WORK/cs16_game_menu_v52.amxx"
WEB_RESULT="$WORK/compiler_result.html"


say "Compiling the V5.2 direct YaPB + random-spawn menu..."
curl -fsS --retry 3 --connect-timeout 20 \
    --data-urlencode "fname=cs16_game_menu_v52" \
    --data-urlencode "scode@$SOURCE" \
    --data "go=send" \
    "https://www.amxmodx.org/webcompiler.cgi" -o "$WEB_RESULT" ||
    die "Could not contact the official AMX Mod X web compiler."

REMOTE_ID="$(
python3 - "$WEB_RESULT" <<'PY'
from pathlib import Path
import html,re,sys
raw=Path(sys.argv[1]).read_text(errors="replace")
m=re.search(r'go=dl(?:&amp;|&)id=(\d+)',html.unescape(raw),re.I)
if not m: raise SystemExit(1)
print(m.group(1))
PY
)" || true

if [[ -z "$REMOTE_ID" ]]; then
    warn "AMX Mod X compiler rejected V5.2:"
    python3 - "$WEB_RESULT" <<'PY'
from pathlib import Path
import html,re,sys
raw=Path(sys.argv[1]).read_text(errors="replace")
for block in re.findall(r'(?is)<pre[^>]*>(.*?)</pre>',raw):
    t=html.unescape(re.sub(r'(?s)<[^>]+>','',block)).strip()
    if t: print(t)
PY
    die "V5.2 menu did not compile."
fi

curl -fL --retry 3 --connect-timeout 20 --progress-bar \
    "https://www.amxmodx.org/webcompiler.cgi?go=dl&id=${REMOTE_ID}" -o "$BUILD_OUTPUT"

python3 - "$BUILD_OUTPUT" <<'PY'
from pathlib import Path
import sys
d=Path(sys.argv[1]).read_bytes()
if len(d)<256 or b"<html" in d[:512].lower(): raise SystemExit("Invalid AMXX output.")
PY

cp -f "$BUILD_OUTPUT" "$AMXX_PLUGINS/cs16_game_menu_v52.amxx"

# Add exactly ONE reference, only in main plugins.ini.
PLUGINS_INI="$AMXX_CFG/plugins.ini"
python3 - "$PLUGINS_INI" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); lines=p.read_text(errors="surrogateescape").splitlines()
out=[ln for ln in lines if "cs16_game_menu" not in ln.lower()]
while out and not out[-1].strip(): out.pop()
out += ["","; CS16 Reliable Native-Menu Bridge Menu V5.2","cs16_game_menu_v52.amxx"]
p.write_text("\n".join(out)+"\n",errors="surrogateescape")
PY

# Verify there is exactly one active reference across all auto-loaded plugin lists.
REF_COUNT="$(
python3 - "$AMXX_CFG" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1]); files=[]
if (root/"plugins.ini").exists(): files.append(root/"plugins.ini")
files += list(root.glob("plugins-*.ini"))
if (root/"maps").exists(): files += list((root/"maps").glob("plugins-*.ini"))
count=0
for p in files:
    for ln in p.read_text(errors="ignore").splitlines():
        s=ln.strip()
        if s and not s.startswith(";") and "cs16_game_menu" in s.lower():
            count+=1
print(count)
PY
)"
[[ "$REF_COUNT" == "1" ]] || die "Expected exactly one CS16 menu plugin reference, found $REF_COUNT."
ok "Verified exactly ONE CS16 menu plugin is configured"

say
say "${GREEN}${BOLD}V5.2 UPDATE COMPLETE!${RESET}"
say
say "Completely close and restart Counter-Strike."
say
say "V5.2 keeps these working systems unchanged:"
say "  • V4.9 direct Add CT/T"
say "  • V5.0 random Deathmatch spawns"
say "  • V5.1 configurable spawn protection"
say
say "FIXED: 5v5 / 6v6 / 8v8 presets"
say "  • no batch 'yb fill' commands anymore"
say "  • one click first clears all YaPB bots + pending requests"
say "  • waits until all bots are really gone"
say "  • calculates exact bots needed after counting human players"
say "  • adds bots ONE AT A TIME using the proven V4.9 direct yb add path"
say "  • verifies the real CT/T count after every single bot"
say "  • finishes only when the requested team totals are exact"
say
say "One preset click should now be enough even on a brand-new server."
say
say "Backup:"
say "  $BACKUP"
say
pause_if_tty
