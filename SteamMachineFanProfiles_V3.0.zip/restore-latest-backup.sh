#!/usr/bin/env bash
set -euo pipefail

BASE="$HOME/.local/share/steam-machine-fan-profiles"
BACKEND="$BASE/fanprofiles-backend.py"

echo
echo "Steam Machine Fan Profiles - Emergency Backup Restore"
echo "====================================================="
echo
echo "This restores the latest full backups of localconfig.vdf and shortcuts.vdf."
echo "Use this only as an emergency rollback."
echo
read -r -p "Press Enter to continue, or Ctrl+C to cancel..."

steam -shutdown >/dev/null 2>&1 || true
for _ in {1..50}; do
    pgrep -x steam >/dev/null 2>&1 || break
    sleep 0.2
done

if pgrep -x steam >/dev/null 2>&1; then
    echo "ERROR: Steam is still running."
    read -r -p "Press Enter to close..."
    exit 1
fi

if [[ ! -x "$BACKEND" ]]; then
    echo "ERROR: Fan Profiles backend is not installed."
    echo "Backups, if present, are under:"
    echo "  ~/.config/steam-machine-fan-profiles/backups"
    read -r -p "Press Enter to close..."
    exit 1
fi

if "$BACKEND" restore-latest; then
    echo
    echo "Latest backups restored."
else
    echo
    echo "No backups were found."
fi

read -r -p "Press Enter to close..."
