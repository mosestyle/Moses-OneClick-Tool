# Steam Machine Fan Profiles V3.0

## Major change: fully automatic new-game detection

V3.0 no longer needs a launch-option wrapper on every game.

A lightweight user service runs in both:

- SteamOS Gaming Mode
- SteamOS Desktop Mode

It detects Steam-launched games automatically.

### Fan Profiles enabled

No game running:
Updated Fan Control = ON

Any Steam / non-Steam game starts:
Updated Fan Control = OFF by default
= Aggressive Cooling

Game marked "Keep Fan Control ON":
Updated Fan Control = ON

Game exits:
Updated Fan Control = ON again

### New games

Newly installed or newly added Steam shortcuts require NO manual setup.

A game that Fan Profiles has never seen before automatically gets the normal
game default:

Updated Fan Control OFF / Aggressive Cooling

You only need to open the GUI if you want to make that game a Keep-ON
exception.

## No more per-game fan-run launch options

V3 does not add new `fan-run` commands to Steam Launch Options.

When upgrading from V2.x:

1. the installed `fan-run` becomes a harmless pass-through immediately,
2. the automatic monitor takes over fan switching,
3. old V2 launch-option wrappers are removed automatically the next time
   Steam has been fully closed for a few seconds.

This cleanup makes timestamped Steam config backups first.

## Apply Profiles no longer restarts Steam

Changing exceptions or enabling/disabling Fan Profiles now saves the profile
without rewriting Steam's per-game launch settings.

## Background service

User service:

`steam-machine-fan-profiles-monitor.service`

It uses `/proc` Steam AppID information to detect current Steam-launched
games. Unknown/new AppIDs are treated as normal games and therefore default
to Aggressive Cooling.

The monitor only asks SteamOS to change the fan state when the desired ON/OFF
state changes; it does not continuously write RPM values or create a custom
fan curve.

## Existing safety behavior retained

When Fan Profiles is enabled, the tool remembers the SteamOS Updated Fan
Control state from before activation.

When Fan Profiles is disabled or uninstalled, that original state is restored.

## Package contents

- install.sh
- uninstall.sh
- fan-run
- fan-monitor.py
- steam-machine-fan-profiles-monitor.service
- fanprofiles-backend.py
- fanprofiles-gui.py
- steam-machine-fan-profiles
- restore-latest-backup.sh
- README.md
