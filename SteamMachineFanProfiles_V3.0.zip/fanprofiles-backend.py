#!/usr/bin/env python3
import os, sys, re, json, struct, shutil, subprocess, time
from pathlib import Path

HOME = Path.home()
BASE = HOME / ".local" / "share" / "steam-machine-fan-profiles"
CONF = HOME / ".config" / "steam-machine-fan-profiles"
PROFILES = CONF / "profiles.json"
BACKUPS = CONF / "backups"
WRAPPER = BASE / "fan-run"

STEAM_CANDIDATES = [
    HOME / ".local/share/Steam",
    HOME / ".steam/steam",
]

def steam_root():
    for p in STEAM_CANDIDATES:
        if p.exists():
            return p.resolve()
    raise SystemExit("Steam installation not found.")

def active_userdata_dir(root):
    u = root / "userdata"
    if not u.exists():
        raise SystemExit("Steam userdata folder not found.")
    candidates = []
    for d in u.iterdir():
        if d.is_dir() and d.name.isdigit():
            lc = d / "config/localconfig.vdf"
            sc = d / "config/shortcuts.vdf"
            score = max(lc.stat().st_mtime if lc.exists() else 0,
                        sc.stat().st_mtime if sc.exists() else 0)
            candidates.append((score, d))
    if not candidates:
        raise SystemExit("No Steam user configuration found.")
    return max(candidates)[1]

def load_profiles():
    try:
        data = json.loads(PROFILES.read_text())
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}

    # Backward-compatible migration from V1.8 and earlier.
    if data.get("policy") not in ("select_aggressive", "aggressive_by_default"):
        data["policy"] = "aggressive_by_default"
    if not isinstance(data.get("aggressive"), dict):
        data["aggressive"] = {}
    if not isinstance(data.get("default_on"), dict):
        data["default_on"] = {}
    if not isinstance(data.get("enabled"), bool):
        data["enabled"] = False

    # SteamOS Updated Fan Control state that existed BEFORE Fan Profiles
    # took control. It is intentionally kept until a successful restore.
    if data.get("original_fan_state") not in ("on", "off"):
        data["original_fan_state"] = None
    return data

def save_profiles(data):
    CONF.mkdir(parents=True, exist_ok=True)
    PROFILES.write_text(json.dumps(data, indent=2, sort_keys=True))

def parse_acf_text(path):
    txt = path.read_text(errors="replace")
    def val(k):
        m = re.search(r'"'+re.escape(k)+r'"\s+"([^"]*)"', txt, re.I)
        return m.group(1) if m else ""
    return val("appid"), val("name"), val("installdir")

def library_folders(root):
    out = [root]
    vdf = root / "steamapps/libraryfolders.vdf"
    if not vdf.exists():
        return out
    txt = vdf.read_text(errors="replace")
    for p in re.findall(r'"path"\s+"([^"]+)"', txt, re.I):
        p = p.replace("\\\\", "\\")
        pp = Path(p)
        if pp.exists() and pp not in out:
            out.append(pp)
    return out

# Minimal binary KeyValues reader/writer sufficient for Steam shortcuts.vdf.
# Preserves common types used by Steam shortcut records.
def cstr(data, pos):
    end = data.index(b"\x00", pos)
    return data[pos:end].decode("utf-8", "replace"), end+1

def read_obj(data, pos=0, stop_at_end=True):
    obj = []
    n = len(data)
    while pos < n:
        typ = data[pos]; pos += 1
        if typ == 0x08:
            break
        key, pos = cstr(data, pos)
        if typ == 0x00:
            val, pos = read_obj(data, pos)
        elif typ == 0x01:
            val, pos = cstr(data, pos)
        elif typ == 0x02:
            val = struct.unpack_from("<i", data, pos)[0]; pos += 4
        elif typ == 0x07:
            val = struct.unpack_from("<Q", data, pos)[0]; pos += 8
        else:
            raise ValueError(f"Unsupported shortcuts.vdf type 0x{typ:02x}")
        obj.append([typ, key, val])
    return obj, pos

def write_obj(obj, root=False):
    b = bytearray()
    for typ, key, val in obj:
        b.append(typ)
        b += key.encode("utf-8") + b"\x00"
        if typ == 0x00:
            b += write_obj(val)
        elif typ == 0x01:
            b += str(val).encode("utf-8") + b"\x00"
        elif typ == 0x02:
            b += struct.pack("<i", int(val))
        elif typ == 0x07:
            b += struct.pack("<Q", int(val))
        else:
            raise ValueError(f"Unsupported type {typ}")
    b.append(0x08)
    return bytes(b)

def field(obj, name):
    for e in obj:
        if e[1].lower() == name.lower():
            return e
    return None

def shortcuts_records(path):
    if not path.exists():
        return [], None
    data = path.read_bytes()
    tree, _ = read_obj(data, 0)
    sh = field(tree, "shortcuts")
    if not sh or sh[0] != 0x00:
        return [], tree
    rows = []
    for ent in sh[2]:
        if ent[0] != 0x00:
            continue
        rec = ent[2]
        appname = field(rec, "AppName")
        appid = field(rec, "appid")
        exe = field(rec, "Exe")
        lo = field(rec, "LaunchOptions")
        if appname and appid:
            signed = int(appid[2])
            unsigned = signed & 0xffffffff
            rows.append({
                "id": str(unsigned),
                "name": str(appname[2]),
                "exe": str(exe[2]) if exe else "",
                "launch": str(lo[2]) if lo else "",
                "_rec": rec,
            })
    return rows, tree

def discover_games():
    root = steam_root()
    games = {}
    for lib in library_folders(root):
        apps = lib / "steamapps"
        if not apps.exists(): continue
        for mf in apps.glob("appmanifest_*.acf"):
            try:
                appid, name, installdir = parse_acf_text(mf)
                if appid and name:
                    games[appid] = {"id": appid, "name": name, "type": "steam"}
            except Exception:
                pass

    udir = active_userdata_dir(root)
    rows, _ = shortcuts_records(udir / "config/shortcuts.vdf")
    for r in rows:
        games["n:"+r["id"]] = {"id": r["id"], "name": r["name"], "type":"nonsteam"}

    return sorted(games.values(), key=lambda x: x["name"].lower())

SYSTEM_ENTRY_PREFIXES = (
    "Proton ",
    "Steam Linux Runtime",
    "Steamworks Common Redistributables",
    "Pressure Vessel",
    "Linux Runtime",
)
SYSTEM_ENTRY_EXACT = {
    "Proton Experimental",
    "Proton Hotfix",
}

def is_system_entry(name):
    return name in SYSTEM_ENTRY_EXACT or any(name.startswith(p) for p in SYSTEM_ENTRY_PREFIXES)

def q(s):
    return '"' + s.replace('\\','\\\\').replace('"','\\"') + '"'

def find_braced_block(text, key_start):
    # key_start points at start of the quoted key
    brace = text.find("{", key_start)
    if brace < 0: return None
    depth=0; inq=False; esc=False
    for i in range(brace, len(text)):
        c=text[i]
        if inq:
            if esc: esc=False
            elif c=="\\": esc=True
            elif c=='"': inq=False
            continue
        if c=='"': inq=True
        elif c=="{": depth += 1
        elif c=="}":
            depth -= 1
            if depth==0: return brace, i+1
    return None

def set_text_launch_option(path, appid, newopt):
    txt = path.read_text(errors="replace")
    # Find exact appid quoted key, then its immediately following braced block.
    pat = re.compile(r'"'+re.escape(str(appid))+r'"\s*\{', re.I)
    matches = list(pat.finditer(txt))
    if not matches:
        raise RuntimeError(f"AppID {appid} not found in localconfig.vdf")
    # Prefer match after an "apps" section marker.
    m = matches[-1]
    block = find_braced_block(txt, m.start())
    if not block: raise RuntimeError("Could not locate app block.")
    a,b = block
    body = txt[a:b]
    lopat = re.compile(r'("LaunchOptions"\s+)"((?:\\.|[^"])*)"', re.I)
    escaped = newopt.replace("\\","\\\\").replace('"','\\"')
    if lopat.search(body):
        body2 = lopat.sub(lambda mm: mm.group(1)+'"'+escaped+'"', body, count=1)
    else:
        # Insert before closing brace, preserving tabs roughly.
        insert_at = body.rfind("}")
        body2 = body[:insert_at] + '\n\t\t\t\t\t\t"LaunchOptions"\t\t"'+escaped+'"\n' + body[insert_at:]
    path.write_text(txt[:a]+body2+txt[b:])

def remove_our_wrapper(opt):
    # Replace our wrapper with %command% when it was inserted into an existing
    # launch-option chain. If it was the entire prefix for plain arguments,
    # remove the redundant leading %command% again.
    marker = str(WRAPPER)
    if marker not in opt:
        return opt.strip()
    pat = re.compile(r'(?:"?'+re.escape(marker)+r'"?)\s+--app\s+\S+\s+--\s+%command%', re.I)
    out = pat.sub("%command%", opt, count=1).strip()
    # If the original launch options had no %command%, our generated form was
    # "wrapper ... %command% <plain args>". Steam treats plain args as
    # "%command% <plain args>", so restore the user's original plain args.
    if out.startswith("%command% ") and out.count("%command%") == 1:
        # We can only strip it when nothing before it remains.
        out = out[len("%command% "):].strip()
    elif out == "%command%":
        out = ""
    return out

def make_opt(appid, existing):
    base = remove_our_wrapper(existing)
    ours = f'"{WRAPPER}" --app {appid} -- %command%'
    if "%command%" in base:
        # Preserve environment variables/wrappers/arguments in exactly the
        # user's existing order and put our wrapper at the command insertion.
        return base.replace("%command%", ours, 1)
    # Steam interprets launch options without %command% as arguments appended
    # to the game command. Put our wrapper first and retain those arguments.
    return (ours + (" " + base if base else "")).strip()

def steam_running():
    try:
        r = subprocess.run(["pgrep","-x","steam"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return r.returncode == 0
    except Exception:
        return False

def backup_file(path):
    if not path.exists(): return
    BACKUPS.mkdir(parents=True, exist_ok=True)
    stamp=time.strftime("%Y%m%d-%H%M%S")
    shutil.copy2(path, BACKUPS/(path.name+"."+stamp+".bak"))


def latest_backup_for(filename):
    if not BACKUPS.exists():
        return None
    matches = sorted(BACKUPS.glob(filename + ".*.bak"), key=lambda p: p.stat().st_mtime, reverse=True)
    return matches[0] if matches else None

def restore_latest_backups():
    root = steam_root()
    udir = active_userdata_dir(root)
    targets = [
        udir / "config/localconfig.vdf",
        udir / "config/shortcuts.vdf",
    ]
    restored = []
    for target in targets:
        b = latest_backup_for(target.name)
        if b and b.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(b, target)
            restored.append((target, b))
    return restored

def save_policy(selected_keys, policy="aggressive_by_default", enabled=True):
    """Save Fan Profiles policy only.

    V3 does not add per-game launch-option wrappers. The background monitor
    applies the fan state automatically for Steam-launched games.
    """
    if policy not in ("select_aggressive", "aggressive_by_default"):
        raise RuntimeError(f"Unknown policy: {policy}")

    prof = load_profiles()
    allgames = discover_games()
    bykey = {(("n:" if g["type"] == "nonsteam" else "") + g["id"]): g for g in allgames}

    selected = {
        k for k in set(selected_keys)
        if k in bykey and not is_system_entry(bykey[k]["name"])
    }

    prof["policy"] = policy
    prof["enabled"] = bool(enabled)

    if policy == "aggressive_by_default":
        prof["default_on"] = {k: bykey[k] for k in selected}
    else:
        prof["aggressive"] = {k: bykey[k] for k in selected}

    save_profiles(prof)


def cleanup_text_launch_options(path):
    """Remove only legacy Fan Profiles wrappers from localconfig.vdf."""
    if not path.exists():
        return False

    txt = path.read_text(errors="replace")
    changed = False

    pat = re.compile(r'("LaunchOptions"\s+)"((?:\\.|[^"])*)"', re.I)

    def repl(m):
        nonlocal changed
        raw = m.group(2)
        decoded = raw.replace('\\"', '"').replace('\\\\', '\\')

        if str(WRAPPER) not in decoded:
            return m.group(0)

        cleaned = remove_our_wrapper(decoded)
        escaped = cleaned.replace("\\", "\\\\").replace('"', '\\"')
        changed = True
        return m.group(1) + '"' + escaped + '"'

    new_txt = pat.sub(repl, txt)
    if changed:
        path.write_text(new_txt)
    return changed


def cleanup_shortcuts_launch_options(path):
    """Remove only legacy Fan Profiles wrappers from shortcuts.vdf."""
    if not path.exists():
        return False

    rows, tree = shortcuts_records(path)
    if tree is None:
        return False

    changed = False
    for r in rows:
        rec = r["_rec"]
        lo = field(rec, "LaunchOptions")
        if not lo:
            continue

        existing = str(lo[2])
        if str(WRAPPER) not in existing:
            continue

        lo[2] = remove_our_wrapper(existing)
        changed = True

    if changed:
        path.write_bytes(write_obj(tree))
    return changed


def legacy_wrapper_present():
    try:
        root = steam_root()
        udir = active_userdata_dir(root)
    except Exception:
        return False

    local = udir / "config/localconfig.vdf"
    shortcuts = udir / "config/shortcuts.vdf"

    try:
        if local.exists() and str(WRAPPER) in local.read_text(errors="replace"):
            return True
    except Exception:
        pass

    try:
        rows, _ = shortcuts_records(shortcuts)
        for r in rows:
            lo = field(r["_rec"], "LaunchOptions")
            if lo and str(WRAPPER) in str(lo[2]):
                return True
    except Exception:
        pass

    return False


def cleanup_legacy_wrappers():
    """Safely remove V2.x launch-option wrappers.

    Steam must be fully closed because Steam owns these config files.
    """
    if steam_running():
        raise RuntimeError("Steam is running; legacy cleanup is deferred.")

    root = steam_root()
    udir = active_userdata_dir(root)
    local = udir / "config/localconfig.vdf"
    shortcuts = udir / "config/shortcuts.vdf"

    if local.exists():
        backup_file(local)
    if shortcuts.exists():
        backup_file(shortcuts)

    changed_local = cleanup_text_launch_options(local)
    changed_shortcuts = cleanup_shortcuts_launch_options(shortcuts)
    return changed_local or changed_shortcuts


def system_ids_cmd():
    for g in discover_games():
        if is_system_entry(g["name"]):
            print(g["id"])


def current_fan_state():
    """Best-effort read of SteamOS Updated Fan Control state.

    jupiter-fan-control.service running == Updated Fan Control ON.
    Service inactive/failed/not-running == Updated Fan Control OFF.
    This is read-only and does not need root.
    """
    try:
        r = subprocess.run(
            ["systemctl", "is-active", "--quiet", "jupiter-fan-control.service"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return "on" if r.returncode == 0 else "off"
    except Exception:
        return None

def fan_state_cmd():
    state = current_fan_state()
    print(state if state in ("on", "off") else "unknown")

def original_state_cmd():
    prof = load_profiles()
    state = prof.get("original_fan_state")
    print(state if state in ("on", "off") else "unknown")

def capture_original_cmd():
    prof = load_profiles()
    existing = prof.get("original_fan_state")
    if existing in ("on", "off"):
        print(existing)
        return 0

    state = current_fan_state()
    if state not in ("on", "off"):
        print("unknown")
        return 4

    prof["original_fan_state"] = state
    save_profiles(prof)
    print(state)
    return 0

def clear_original_cmd():
    prof = load_profiles()
    prof["original_fan_state"] = None
    save_profiles(prof)
    return 0

def settings_cmd():
    prof = load_profiles()
    print(prof.get("policy", "aggressive_by_default"))

def enabled_cmd():
    prof = load_profiles()
    print("1" if prof.get("enabled", True) else "0")


def list_cmd(policy=None):
    prof = load_profiles()
    if policy not in ("select_aggressive", "aggressive_by_default"):
        policy = prof.get("policy", "select_aggressive")

    if policy == "aggressive_by_default":
        selected = set(prof.get("default_on", {}).keys())
    else:
        selected = set(prof.get("aggressive", {}).keys())

    for g in discover_games():
        key = ("n:" if g["type"] == "nonsteam" else "") + g["id"]
        system = "1" if is_system_entry(g["name"]) else "0"
        print("\t".join([
            key,
            g["name"],
            g["type"],
            "1" if key in selected else "0",
            system,
        ]))


def main():
    if len(sys.argv) < 2:
        print("Usage: fanprofiles-backend list|list-policy|settings|enabled|fan-state|original-state|capture-original|clear-original|apply|apply-policy|legacy-status|cleanup-legacy|system-ids")
        return 2

    cmd = sys.argv[1]

    if cmd == "settings":
        settings_cmd()
        return 0

    if cmd == "enabled":
        enabled_cmd()
        return 0

    if cmd == "fan-state":
        fan_state_cmd()
        return 0

    if cmd == "original-state":
        original_state_cmd()
        return 0

    if cmd == "capture-original":
        return capture_original_cmd()

    if cmd == "clear-original":
        clear_original_cmd()
        return 0

    if cmd == "list":
        list_cmd()
        return 0

    if cmd == "list-policy":
        if len(sys.argv) < 3:
            return 2
        list_cmd(sys.argv[2])
        return 0

    if cmd == "apply":
        save_policy([], "aggressive_by_default", enabled=False)
        return 0

    if cmd == "apply-policy":
        if len(sys.argv) < 4:
            return 2
        enabled_arg = sys.argv[3].strip().lower()
        enabled = enabled_arg in ("1", "true", "yes", "on", "enabled")
        save_policy(sys.argv[4:], sys.argv[2], enabled=enabled)
        return 0

    if cmd == "legacy-status":
        print("1" if legacy_wrapper_present() else "0")
        return 0

    if cmd == "cleanup-legacy":
        cleanup_legacy_wrappers()
        return 0

    if cmd == "system-ids":
        system_ids_cmd()
        return 0

    if cmd == "restore-latest":
        restored = restore_latest_backups()
        for target, backup in restored:
            print(f"RESTORED\t{target}\t{backup}")
        return 0 if restored else 3

    return 2

if __name__=="__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print("ERROR:",e,file=sys.stderr)
        sys.exit(1)
