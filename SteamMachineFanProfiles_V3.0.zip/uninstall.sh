#!/usr/bin/env bash
set -euo pipefail

BASE="$HOME/.local/share/steam-machine-fan-profiles"
CONF="$HOME/.config/steam-machine-fan-profiles"
BACKEND="$BASE/fanprofiles-backend.py"
HELPER="/usr/bin/steamos-polkit-helpers/jupiter-fan-control"
APPS="$HOME/.local/share/applications"

echo
echo "Steam Machine Fan Profiles V3.0 - Uninstaller"

# Stop automatic game detection before changing/removing anything.
systemctl --user disable --now steam-machine-fan-profiles-monitor.service >/dev/null 2>&1 || true
echo "==============================================="
echo
echo "This will:"
echo "  - remove Fan Profiles launch hooks"
echo "  - request Updated Fan Control ON"
echo "  - remove the application"
echo "  - KEEP your timestamped Steam configuration backups"
echo
read -r -p "Press Enter to continue, or Ctrl+C to cancel..."

steam -shutdown >/dev/null 2>&1 || true
for _ in {1..50}; do
    pgrep -x steam >/dev/null 2>&1 || break
    sleep 0.2
done

if pgrep -x steam >/dev/null 2>&1; then
    echo
    echo "ERROR: Steam is still running."
    echo "Close Steam completely and run this uninstaller again."
    read -r -p "Press Enter to close..."
    exit 1
fi

# Remove only our launch hooks while preserving the user's other launch options.
if [[ -x "$BACKEND" ]]; then
    "$BACKEND" cleanup-legacy || true
    "$BACKEND" apply || true
fi

# Restore the exact SteamOS Updated Fan Control state that existed before
# Fan Profiles took control. Do this after the per-game hooks are removed.
ORIGINAL_STATE="unknown"
if [[ -x "$BACKEND" ]]; then
    ORIGINAL_STATE="$("$BACKEND" original-state 2>/dev/null || printf 'unknown')"
fi

if [[ -x "$HELPER" ]]; then
    case "$ORIGINAL_STATE" in
        on)
            pkexec "$HELPER" --enable || true
            ;;
        off)
            pkexec "$HELPER" --disable || true
            ;;
        *)
            # No trustworthy pre-activation snapshot exists. Do not guess.
            ;;
    esac
fi

rm -f "$APPS/steam-machine-fan-profiles.desktop"
rm -f "$APPS/steam-machine-fan-profiles-uninstall.desktop"
rm -f "$HOME/.local/bin/steam-machine-fan-profiles"
rm -f "$HOME/.config/systemd/user/steam-machine-fan-profiles-monitor.service"
systemctl --user daemon-reload >/dev/null 2>&1 || true
rm -rf "$BASE"

echo
echo "Uninstall complete."
echo
if [[ "$ORIGINAL_STATE" == "on" || "$ORIGINAL_STATE" == "off" ]]; then
    echo "Restored pre-Fan-Profiles Updated Fan Control state: ${ORIGINAL_STATE^^}"
else
    echo "No saved pre-Fan-Profiles fan state existed, so the global setting was left unchanged."
fi
echo "Backups were intentionally kept in:"
echo "  $CONF/backups"
echo
read -r -p "Press Enter to close..."
