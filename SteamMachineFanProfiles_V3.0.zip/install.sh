#!/usr/bin/env bash
set -euo pipefail

VERSION="3.0"

# IMPORTANT:
# Resolve the actual folder containing this script. Do not rely on Dolphin /
# Konsole's current working directory.
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd -P)"

BASE="$HOME/.local/share/steam-machine-fan-profiles"
CONF="$HOME/.config/steam-machine-fan-profiles"
APPS="$HOME/.local/share/applications"
BIN="$HOME/.local/bin"
VENV="$BASE/.venv"
PROGRAM_BACKUPS="$CONF/program-backups"

required=(
    "fanprofiles-backend.py"
    "fanprofiles-gui.py"
    "fan-run"
    "fan-monitor.py"
    "steam-machine-fan-profiles-monitor.service"
    "steam-machine-fan-profiles"
    "uninstall.sh"
    "restore-latest-backup.sh"
)

echo
echo "Steam Machine Fan Profiles V$VERSION"
echo "===================================="
echo
echo "Installer folder:"
echo "  $HERE"
echo

for f in "${required[@]}"; do
    if [[ ! -f "$HERE/$f" ]]; then
        echo "ERROR: Required package file is missing:"
        echo "  $HERE/$f"
        echo
        echo "Please extract the complete ZIP before running install.sh."
        read -r -p "Press Enter to close..."
        exit 1
    fi
done

mkdir -p "$BASE" "$CONF" "$APPS" "$BIN" "$PROGRAM_BACKUPS"

# Back up the currently-installed PROGRAM files before an in-place update.
# This is separate from the Steam config backups created by the backend.
if [[ -f "$BASE/fanprofiles-backend.py" || -f "$BASE/fanprofiles-gui.py" ]]; then
    STAMP="$(date '+%Y%m%d-%H%M%S')"
    PREV="$PROGRAM_BACKUPS/pre-V${VERSION}-$STAMP"
    mkdir -p "$PREV"

    for f in \
        fanprofiles-backend.py \
        fanprofiles-gui.py \
        fan-run \
        steam-machine-fan-profiles \
        uninstall.sh \
        restore-latest-backup.sh \
        README.md \
        README.txt
    do
        [[ -f "$BASE/$f" ]] && cp -a "$BASE/$f" "$PREV/$f"
    done

    echo "Existing installation found."
    echo "Updating it in place."
    echo "Your fan profiles and Steam configuration backups will be kept."
    echo
else
    echo "Fresh installation detected."
    echo
fi

install -m 755 "$HERE/fanprofiles-backend.py" "$BASE/fanprofiles-backend.py"
install -m 755 "$HERE/fanprofiles-gui.py" "$BASE/fanprofiles-gui.py"
install -m 755 "$HERE/fan-run" "$BASE/fan-run"
install -m 755 "$HERE/fan-monitor.py" "$BASE/fan-monitor.py"
install -m 755 "$HERE/steam-machine-fan-profiles" "$BASE/steam-machine-fan-profiles"
install -m 755 "$HERE/uninstall.sh" "$BASE/uninstall.sh"
install -m 755 "$HERE/restore-latest-backup.sh" "$BASE/restore-latest-backup.sh"
install -m 644 "$HERE/README.md" "$BASE/README.md"

# Validate the installed Python source before exposing the launcher.
python3 -m py_compile \
    "$BASE/fanprofiles-backend.py" \
    "$BASE/fanprofiles-gui.py"

# Keep a reusable virtualenv. An update does not redownload PySide6 if the
# existing environment is healthy.
GUI_OK=0
if [[ -x "$VENV/bin/python" ]] && "$VENV/bin/python" -c 'import PySide6' >/dev/null 2>&1; then
    GUI_OK=1
fi

if [[ "$GUI_OK" -ne 1 ]]; then
    echo "Preparing the Fan Profiles GUI dependency..."
    echo "This is normally only required on the first installation."
    echo

    rm -rf "$VENV"

    if ! python3 -m venv "$VENV"; then
        echo
        echo "ERROR: Could not create the Python GUI environment."
        echo "No SteamOS system files were modified."
        read -r -p "Press Enter to close..."
        exit 1
    fi

    PIP_DISABLE_PIP_VERSION_CHECK=1 "$VENV/bin/python" -m pip install --upgrade pip
    PIP_DISABLE_PIP_VERSION_CHECK=1 "$VENV/bin/python" -m pip install 'PySide6>=6.7,<7'
fi

if ! "$VENV/bin/python" -c 'import PySide6' >/dev/null 2>&1; then
    echo
    echo "ERROR: PySide6 could not be loaded after installation."
    echo "Please keep this Konsole output if you report the problem."
    read -r -p "Press Enter to close..."
    exit 1
fi

cat > "$APPS/steam-machine-fan-profiles.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Steam Machine Fan Profiles
Comment=Per-game SteamOS fan profiles
Exec=$BASE/steam-machine-fan-profiles
Icon=preferences-system
Terminal=false
Categories=Utility;System;
EOF
chmod +x "$APPS/steam-machine-fan-profiles.desktop"

cat > "$APPS/steam-machine-fan-profiles-uninstall.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Uninstall Steam Machine Fan Profiles
Comment=Remove Steam Machine Fan Profiles safely
Exec=konsole -e bash "$BASE/uninstall.sh"
Icon=edit-delete
Terminal=false
Categories=Utility;System;
EOF
chmod +x "$APPS/steam-machine-fan-profiles-uninstall.desktop"

ln -sf "$BASE/steam-machine-fan-profiles" "$BIN/steam-machine-fan-profiles"

# Install and enable the lightweight automatic game monitor. It runs in both
# Gaming Mode and Desktop Mode via the user's systemd manager.
USER_UNITS="$HOME/.config/systemd/user"
mkdir -p "$USER_UNITS"
install -m 644 \
    "$HERE/steam-machine-fan-profiles-monitor.service" \
    "$USER_UNITS/steam-machine-fan-profiles-monitor.service"

if systemctl --user daemon-reload >/dev/null 2>&1; then
    systemctl --user enable --now steam-machine-fan-profiles-monitor.service >/dev/null 2>&1 || true
fi

echo
echo "===================================="
echo "Steam Machine Fan Profiles V$VERSION installed successfully."
echo
echo "Automatic game detection has been installed for Gaming + Desktop Mode."
echo "New games inherit Aggressive Cooling automatically."
echo
echo "Open 'Steam Machine Fan Profiles' only when you want to change exceptions."
echo
echo "Future updates:"
echo "  Extract ZIP -> right-click install.sh -> Run in Konsole"
echo "  No uninstall is required before an update."
echo "===================================="
echo
read -r -p "Press Enter to close..."
