#!/usr/bin/env python3
from __future__ import annotations

import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QApplication, QAbstractItemView, QCheckBox, QComboBox, QFrame, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget
)

HOME = Path.home()
BASE = HOME / ".local" / "share" / "steam-machine-fan-profiles"
BACKEND = BASE / "fanprofiles-backend.py"
HELPER = Path("/usr/bin/steamos-polkit-helpers/jupiter-fan-control")
THEME_FILE = BASE / "ui_theme.txt"
MONITOR_SERVICE = "steam-machine-fan-profiles-monitor.service"
POLICY = "aggressive_by_default"
APP_VERSION = "3.0"


def backend_call(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run([str(BACKEND), *args], text=True, capture_output=True)


def load_theme_pref() -> str:
    try:
        theme = THEME_FILE.read_text(encoding="utf-8").strip().lower()
        if theme in ("dark", "light"):
            return theme
    except Exception:
        pass
    return "dark"


def save_theme_pref(theme: str) -> None:
    try:
        BASE.mkdir(parents=True, exist_ok=True)
        THEME_FILE.write_text(theme.strip().lower(), encoding="utf-8")
    except Exception:
        pass


def dark_stylesheet() -> str:
    return r"""
        QWidget {
            background-color: #151a21;
            color: #e6edf3;
            font-size: 14px;
        }

        QLabel#title {
            font-size: 21px;
            font-weight: 700;
            color: #f0f6fc;
        }

        QLabel#version {
            color: #8b949e;
            font-size: 11px;
            font-weight: 600;
            padding-top: 5px;
        }

        QLabel#masterTitle {
            color: #f0f6fc;
            font-size: 13px;
            font-weight: 700;
        }

        QLabel#compactGood {
            color: #7ee787;
            font-size: 12px;
            font-weight: 700;
        }

        QLabel#compactAggressive {
            color: #58a6ff;
            font-size: 12px;
            font-weight: 700;
        }

        QLabel#compactSeparator,
        QLabel#themeLabel {
            color: #7d8590;
            font-size: 12px;
            font-weight: 600;
        }

        QLabel#statusText {
            color: #8b949e;
            font-size: 12px;
        }

        QLabel#originalState {
            color: #58a6ff;
            font-size: 11px;
            font-weight: 600;
        }

        QFrame#tableCard,
        QFrame#masterCard,
        QFrame#compactStatus {
            background-color: #1c222b;
            border: 1px solid #343d49;
            border-radius: 8px;
        }

        QFrame#tableCard QLabel,
        QFrame#masterCard QLabel,
        QFrame#compactStatus QLabel {
            background-color: transparent;
        }

        QLineEdit {
            background-color: #0f141a;
            color: #f0f6fc;
            border: 1px solid #3a4552;
            border-radius: 6px;
            padding: 6px 9px;
            min-height: 18px;
        }

        QLineEdit:focus {
            border: 1px solid #2f81f7;
        }

        QComboBox {
            background-color: #0f141a;
            color: #f0f6fc;
            border: 1px solid #3a4552;
            border-radius: 6px;
            padding: 5px 10px;
            min-height: 18px;
        }

        QComboBox:hover {
            border-color: #58a6ff;
        }

        QComboBox::drop-down {
            border: none;
            width: 22px;
        }

        QComboBox QAbstractItemView {
            background-color: #151a21;
            color: #e6edf3;
            selection-background-color: #264f78;
            border: 1px solid #343d49;
        }

        QCheckBox {
            spacing: 8px;
            color: #d8dee4;
            font-weight: 600;
        }

        QCheckBox::indicator {
            width: 22px;
            height: 22px;
            border: 2px solid #8b949e;
            border-radius: 4px;
            background-color: #0f141a;
        }

        QCheckBox::indicator:hover {
            border-color: #58a6ff;
            background-color: #18273a;
        }

        QCheckBox::indicator:checked {
            border-color: #2f81f7;
            background-color: #2f81f7;
        }

        QCheckBox::indicator:disabled {
            border-color: #444c56;
            background-color: #21262d;
        }

        QWidget#checkHost {
            background-color: transparent;
        }

        QTableWidget {
            background-color: #151a21;
            alternate-background-color: #151a21;
            color: #e6edf3;
            border: none;
            gridline-color: transparent;
            selection-background-color: #2e5b89;
            selection-color: #ffffff;
        }

        QHeaderView::section {
            background-color: #202731;
            color: #d8dee4;
            border: none;
            border-bottom: 1px solid #3a4552;
            padding: 10px;
            font-weight: 700;
        }

        QScrollBar:vertical {
            background: #151a21;
            width: 14px;
            margin: 0;
        }

        QScrollBar::handle:vertical {
            background: #4b5563;
            min-height: 30px;
            border-radius: 6px;
        }

        QScrollBar::handle:vertical:hover {
            background: #657181;
        }

        QPushButton {
            min-height: 32px;
            padding: 0 12px;
            border-radius: 6px;
            font-weight: 650;
        }

        QPushButton#primary {
            background-color: #2f81f7;
            color: #ffffff;
            border: 1px solid #2f81f7;
        }

        QPushButton#primary:hover {
            background-color: #1f6feb;
            border-color: #1f6feb;
        }

        QPushButton#secondary {
            background-color: #21262d;
            color: #e6edf3;
            border: 1px solid #444c56;
        }

        QPushButton#secondary:hover {
            background-color: #30363d;
            border-color: #5a6572;
        }
    """


def light_stylesheet() -> str:
    return r"""
        QWidget {
            background-color: #f3f5f8;
            color: #1f2328;
            font-size: 14px;
        }

        QLabel#title {
            font-size: 21px;
            font-weight: 700;
            color: #111827;
        }

        QLabel#version {
            color: #6b7280;
            font-size: 11px;
            font-weight: 600;
            padding-top: 5px;
        }

        QLabel#masterTitle {
            color: #111827;
            font-size: 13px;
            font-weight: 700;
        }

        QLabel#compactGood {
            color: #18794e;
            font-size: 12px;
            font-weight: 700;
        }

        QLabel#compactAggressive {
            color: #1f6fd5;
            font-size: 12px;
            font-weight: 700;
        }

        QLabel#compactSeparator,
        QLabel#themeLabel {
            color: #6b7280;
            font-size: 12px;
            font-weight: 600;
        }

        QLabel#statusText {
            color: #6b7280;
            font-size: 12px;
        }

        QLabel#originalState {
            color: #1f6fd5;
            font-size: 11px;
            font-weight: 600;
        }

        QFrame#tableCard,
        QFrame#masterCard,
        QFrame#compactStatus {
            background-color: #ffffff;
            border: 1px solid #c9d1da;
            border-radius: 8px;
        }

        QFrame#tableCard QLabel,
        QFrame#masterCard QLabel,
        QFrame#compactStatus QLabel {
            background-color: transparent;
        }

        QLineEdit {
            background-color: #ffffff;
            color: #111827;
            border: 1px solid #c2cad3;
            border-radius: 6px;
            padding: 6px 9px;
            min-height: 18px;
        }

        QLineEdit:focus {
            border: 1px solid #2f81f7;
        }

        QComboBox {
            background-color: #ffffff;
            color: #111827;
            border: 1px solid #c2cad3;
            border-radius: 6px;
            padding: 5px 10px;
            min-height: 18px;
        }

        QComboBox:hover {
            border-color: #2f81f7;
        }

        QComboBox::drop-down {
            border: none;
            width: 22px;
        }

        QComboBox QAbstractItemView {
            background-color: #ffffff;
            color: #111827;
            selection-background-color: #dcecff;
            border: 1px solid #c9d1da;
        }

        QCheckBox {
            spacing: 8px;
            color: #374151;
            font-weight: 600;
        }

        QCheckBox::indicator {
            width: 22px;
            height: 22px;
            border: 2px solid #7b8794;
            border-radius: 4px;
            background-color: #ffffff;
        }

        QCheckBox::indicator:hover {
            border-color: #2f81f7;
            background-color: #eff6ff;
        }

        QCheckBox::indicator:checked {
            border-color: #2f81f7;
            background-color: #2f81f7;
        }

        QCheckBox::indicator:disabled {
            border-color: #c5cbd3;
            background-color: #eceff3;
        }

        QWidget#checkHost {
            background-color: transparent;
        }

        QTableWidget {
            background-color: #f3f5f8;
            alternate-background-color: #f3f5f8;
            color: #1f2328;
            border: none;
            gridline-color: transparent;
            selection-background-color: #d4e7ff;
            selection-color: #111827;
        }

        QHeaderView::section {
            background-color: #e8edf3;
            color: #374151;
            border: none;
            border-bottom: 1px solid #c9d1da;
            padding: 10px;
            font-weight: 700;
        }

        QScrollBar:vertical {
            background: #f3f5f8;
            width: 14px;
            margin: 0;
        }

        QScrollBar::handle:vertical {
            background: #aeb6c1;
            min-height: 30px;
            border-radius: 6px;
        }

        QScrollBar::handle:vertical:hover {
            background: #95a0ad;
        }

        QPushButton {
            min-height: 32px;
            padding: 0 12px;
            border-radius: 6px;
            font-weight: 650;
        }

        QPushButton#primary {
            background-color: #2f81f7;
            color: #ffffff;
            border: 1px solid #2f81f7;
        }

        QPushButton#primary:hover {
            background-color: #1f6feb;
            border-color: #1f6feb;
        }

        QPushButton#secondary {
            background-color: #ffffff;
            color: #1f2328;
            border: 1px solid #c9d1da;
        }

        QPushButton#secondary:hover {
            background-color: #f3f6fa;
            border-color: #b7c0cb;
        }
    """


def theme_colors(theme: str) -> dict[str, str]:
    if theme == "light":
        return {
            "system_bg": "#eef2f6",
            "system_fg": "#6b7280",
            "on_bg": "#e8f8ea",
            "on_fg": "#18794e",
            "off_bg": "#edf5ff",
            "off_fg": "#1f6fd5",
        }
    return {
        "system_bg": "#1f252d",
        "system_fg": "#8b949e",
        "on_bg": "#17351f",
        "on_fg": "#7ee787",
        "off_bg": "#172a3a",
        "off_fg": "#58a6ff",
    }


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Steam Machine Fan Profiles")
        self.resize(1080, 680)
        self.setMinimumSize(930, 560)

        self.rows: list[dict] = []
        self.loading_table = False
        self.saved_enabled = False
        self.saved_original_state: str | None = None
        self.current_theme = load_theme_pref()
        self.colors = theme_colors(self.current_theme)

        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(16, 13, 16, 12)
        outer.setSpacing(8)

        # Compact title row with top-right theme selector.
        title_row = QHBoxLayout()
        title_row.setSpacing(9)

        title = QLabel("Steam Machine Fan Profiles")
        title.setObjectName("title")
        title_row.addWidget(title)

        version = QLabel(f"Version {APP_VERSION}")
        version.setObjectName("version")
        title_row.addWidget(version)

        title_row.addStretch(1)

        theme_label = QLabel("Theme")
        theme_label.setObjectName("themeLabel")
        title_row.addWidget(theme_label)

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Dark", "Light"])
        self.theme_combo.setFixedWidth(110)
        self.theme_combo.currentTextChanged.connect(self.on_theme_changed)
        title_row.addWidget(self.theme_combo)

        outer.addLayout(title_row)

        # Compact behavior strip.
        behavior = QFrame()
        behavior.setObjectName("compactStatus")
        behavior_layout = QHBoxLayout(behavior)
        behavior_layout.setContentsMargins(12, 7, 12, 7)
        behavior_layout.setSpacing(18)

        desktop_label = QLabel("Desktop + Gaming UI:  Updated Fan Control ON")
        desktop_label.setObjectName("compactGood")
        behavior_layout.addWidget(desktop_label)

        separator = QLabel("•")
        separator.setObjectName("compactSeparator")
        behavior_layout.addWidget(separator)

        games_label = QLabel("Games:  Updated Fan Control OFF by default")
        games_label.setObjectName("compactAggressive")
        behavior_layout.addWidget(games_label)

        separator2 = QLabel("•")
        separator2.setObjectName("compactSeparator")
        behavior_layout.addWidget(separator2)

        self.monitor_label = QLabel("Auto detection: checking…")
        self.monitor_label.setObjectName("compactGood")
        behavior_layout.addWidget(self.monitor_label)

        behavior_layout.addStretch(1)
        outer.addWidget(behavior)

        # Compact master row.
        master = QFrame()
        master.setObjectName("masterCard")
        master_layout = QHBoxLayout(master)
        master_layout.setContentsMargins(12, 7, 12, 7)
        master_layout.setSpacing(10)

        master_title = QLabel("Fan Profiles")
        master_title.setObjectName("masterTitle")
        master_layout.addWidget(master_title)

        self.master_toggle = QCheckBox("Enabled")
        self.master_toggle.setObjectName("masterToggle")
        self.master_toggle.toggled.connect(self.master_toggled)
        master_layout.addWidget(self.master_toggle)

        master_layout.addSpacing(8)

        self.original_label = QLabel("")
        self.original_label.setObjectName("originalState")
        self.original_label.setWordWrap(False)
        master_layout.addWidget(self.original_label, 1)

        outer.addWidget(master)

        # Search / filters.
        controls = QHBoxLayout()
        controls.setSpacing(7)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search games…")
        self.search.textChanged.connect(self.apply_filter)
        controls.addWidget(self.search, 1)

        self.show_tools = QCheckBox("Show Proton / runtime entries")
        self.show_tools.setChecked(False)
        self.show_tools.toggled.connect(self.apply_filter)
        controls.addWidget(self.show_tools)

        refresh = QPushButton("Refresh Library")
        refresh.setObjectName("secondary")
        refresh.clicked.connect(self.load_games)
        controls.addWidget(refresh)

        outer.addLayout(controls)

        table_frame = QFrame()
        table_frame.setObjectName("tableCard")
        table_lay = QVBoxLayout(table_frame)
        table_lay.setContentsMargins(0, 0, 0, 0)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels([
            "Game",
            "Source",
            "Keep Fan Control ON",
            "While game runs",
        ])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(False)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(36)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        header = self.table.horizontalHeader()
        # Keep columns stable so the UI does not shift when a row changes
        # from OFF to ON.
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(1, 130)
        self.table.setColumnWidth(2, 170)
        self.table.setColumnWidth(3, 270)

        table_lay.addWidget(self.table)
        outer.addWidget(table_frame, 1)

        bottom = QHBoxLayout()
        bottom.setSpacing(7)

        self.summary = QLabel("")
        self.summary.setObjectName("statusText")
        bottom.addWidget(self.summary, 1)

        apply_btn = QPushButton("Apply Profiles")
        apply_btn.setObjectName("primary")
        apply_btn.clicked.connect(self.apply_profiles)
        bottom.addWidget(apply_btn)

        outer.addLayout(bottom)

        self.status = QLabel("Loading Steam library…")
        self.status.setObjectName("statusText")
        outer.addWidget(self.status)

        # Apply initial theme and load state.
        self.theme_combo.blockSignals(True)
        self.theme_combo.setCurrentText("Dark" if self.current_theme == "dark" else "Light")
        self.theme_combo.blockSignals(False)
        self.apply_theme(self.current_theme)
        self.load_initial_state()

    def apply_theme(self, theme: str) -> None:
        theme = theme.lower().strip()
        if theme not in ("dark", "light"):
            theme = "dark"

        self.current_theme = theme
        self.colors = theme_colors(theme)
        stylesheet = dark_stylesheet() if theme == "dark" else light_stylesheet()
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(stylesheet)

        if hasattr(self, "table"):
            for row in range(self.table.rowCount()):
                self.paint_row(row)

    def on_theme_changed(self, text: str) -> None:
        theme = "dark" if text.strip().lower() == "dark" else "light"
        self.apply_theme(theme)
        save_theme_pref(theme)

    def monitor_active(self) -> bool:
        try:
            return subprocess.run(
                ["systemctl", "--user", "is-active", "--quiet", MONITOR_SERVICE],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode == 0
        except Exception:
            return False

    def update_monitor_label(self):
        if self.monitor_active():
            self.monitor_label.setText("Auto detection: Active")
            self.monitor_label.setObjectName("compactGood")
        else:
            self.monitor_label.setText("Auto detection: Not running")
            self.monitor_label.setObjectName("compactAggressive")
        self.monitor_label.style().unpolish(self.monitor_label)
        self.monitor_label.style().polish(self.monitor_label)

    def backend_scalar(self, command: str, fallback: str = "unknown") -> str:
        result = backend_call(command)
        if result.returncode != 0:
            return fallback
        value = result.stdout.strip().lower()
        return value or fallback

    def load_initial_state(self):
        enabled_value = self.backend_scalar("enabled", "0")
        self.saved_enabled = enabled_value == "1"

        original = self.backend_scalar("original-state", "unknown")
        self.saved_original_state = original if original in ("on", "off") else None

        self.master_toggle.blockSignals(True)
        self.master_toggle.setChecked(self.saved_enabled)
        self.master_toggle.blockSignals(False)

        self.load_games()
        self.update_master_ui()
        self.update_monitor_label()

    def master_toggled(self, _enabled: bool):
        self.update_master_ui()

    def update_master_ui(self):
        desired_enabled = self.master_toggle.isChecked()
        self.table.setEnabled(desired_enabled)
        self.search.setEnabled(desired_enabled)
        self.show_tools.setEnabled(desired_enabled)

        if self.saved_enabled and self.saved_original_state in ("on", "off"):
            original_text = self.saved_original_state.upper()
            if desired_enabled:
                self.original_label.setText(
                    f"Restore state: Updated Fan Control {original_text}"
                )
            else:
                self.original_label.setText(
                    f"Apply to disable and restore Updated Fan Control {original_text}"
                )
        elif desired_enabled:
            self.original_label.setText(
                "Apply will save the current SteamOS fan state first"
            )
        else:
            self.original_label.setText(
                "SteamOS global fan setting is in control"
            )

        if desired_enabled:
            if self.saved_enabled:
                self.status.setText(
                    "Enabled • Desktop/Gaming UI ON • Games OFF by default"
                )
            else:
                self.status.setText(
                    "Enable staged • Press Apply Profiles"
                )
        else:
            if self.saved_enabled:
                self.status.setText(
                    "Disable staged • Apply removes hooks and restores saved state"
                )
            else:
                self.status.setText(
                    "Disabled • SteamOS global fan setting in control"
                )

    def load_games(self):
        result = backend_call("list-policy", POLICY)
        if result.returncode != 0:
            QMessageBox.critical(
                self,
                "Could not read Steam library",
                (result.stderr or result.stdout or "Unknown error").strip(),
            )
            return

        rows = []
        for line in result.stdout.splitlines():
            if not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) != 5:
                continue

            key, name, typ, checked, system = parts
            rows.append({
                "key": key,
                "name": name,
                "type": typ,
                "keep_on": checked == "1",
                "system": system == "1",
            })

        self.rows = sorted(rows, key=lambda r: r["name"].casefold())
        self.populate_table()
        self.status.setText(f"Loaded {len(self.rows)} Steam library entries.")
        self.update_master_ui()
        self.update_monitor_label()

    def populate_table(self):
        self.loading_table = True
        self.table.setRowCount(0)

        for entry in self.rows:
            row = self.table.rowCount()
            self.table.insertRow(row)

            game = QTableWidgetItem(entry["name"])
            game.setData(Qt.ItemDataRole.UserRole, entry["key"])
            game.setFlags(game.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.table.setItem(row, 0, game)

            if entry["system"]:
                source_text = "System / Runtime"
            else:
                source_text = "Non-Steam" if entry["type"] == "nonsteam" else "Steam"

            source = QTableWidgetItem(source_text)
            source.setFlags(source.flags() & ~Qt.ItemFlag.ItemIsEditable)
            source.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 1, source)

            check_host = QWidget()
            check_host.setObjectName("checkHost")
            check_layout = QHBoxLayout(check_host)
            check_layout.setContentsMargins(0, 0, 0, 0)
            check_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

            keep = QCheckBox()
            keep.setObjectName("gameCheck")

            if entry["system"]:
                keep.setEnabled(False)
                keep.setChecked(False)
                keep.setToolTip("Runtime/system entry — Fan Profiles never modifies this.")
            else:
                keep.setChecked(entry["keep_on"])
                keep.setToolTip(
                    "Checked = keep Updated Fan Control ON for this game.\n"
                    "Unchecked = Updated Fan Control OFF / Aggressive Cooling."
                )
                keep.toggled.connect(
                    lambda checked, key=entry["key"]: self.game_checkbox_toggled(key, checked)
                )

            check_layout.addWidget(keep)
            self.table.setCellWidget(row, 2, check_host)

            status = QTableWidgetItem()
            status.setFlags(status.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.table.setItem(row, 3, status)

            self.paint_row(row)

        self.loading_table = False
        self.apply_filter()
        self.update_summary()

    def game_checkbox_toggled(self, key: str, checked: bool):
        if self.loading_table:
            return

        entry = next((x for x in self.rows if x["key"] == key), None)
        if not entry or entry["system"]:
            return

        entry["keep_on"] = checked

        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item and item.data(Qt.ItemDataRole.UserRole) == key:
                self.paint_row(row)
                break

        self.update_summary()

    def paint_row(self, row: int):
        key = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
        entry = next((x for x in self.rows if x["key"] == key), None)
        if not entry:
            return

        status = self.table.item(row, 3)
        host = self.table.cellWidget(row, 2)

        if entry["system"]:
            status.setText("Ignored")
            status.setForeground(QColor(self.colors["system_fg"]))
            bg = QColor(self.colors["system_bg"])
        elif entry["keep_on"]:
            status.setText("ON • Keep Fan Control")
            status.setForeground(QColor(self.colors["on_fg"]))
            bg = QColor(self.colors["on_bg"])
        else:
            status.setText("OFF • Aggressive Cooling")
            status.setForeground(QColor(self.colors["off_fg"]))
            bg = QColor(self.colors["off_bg"])

        font = status.font()
        font.setBold(True)
        status.setFont(font)
        status.setTextAlignment(Qt.AlignmentFlag.AlignCenter)

        for col in (0, 1, 3):
            item = self.table.item(row, col)
            if item:
                item.setBackground(bg)

        if host is not None:
            host.setStyleSheet(f"background-color: {bg.name()};")

    def apply_filter(self):
        query = self.search.text().strip().casefold()
        show_tools = self.show_tools.isChecked()

        for row in range(self.table.rowCount()):
            key = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
            entry = next((x for x in self.rows if x["key"] == key), None)

            if not entry:
                continue

            hidden = bool(
                (entry["system"] and not show_tools) or
                (query and query not in entry["name"].casefold())
            )
            self.table.setRowHidden(row, hidden)

        self.update_summary()

    def update_summary(self):
        games = [x for x in self.rows if not x["system"]]
        on_exceptions = sum(1 for x in games if x["keep_on"])
        off_default = len(games) - on_exceptions
        visible = sum(
            1 for row in range(self.table.rowCount())
            if not self.table.isRowHidden(row)
        )

        if not self.master_toggle.isChecked():
            self.summary.setText(
                "Fan Profiles OFF  •  No game overrides will be active after Apply Profiles"
            )
        else:
            self.summary.setText(
                f"{off_default} OFF by default"
                f"   •   {on_exceptions} ON exception{'s' if on_exceptions != 1 else ''}"
                f"   •   {visible} shown"
            )

    def set_updated_fan_control(self, state: str) -> bool:
        if state not in ("on", "off"):
            return False
        if not HELPER.is_file():
            QMessageBox.critical(
                self,
                "SteamOS fan-control helper not found",
                f"Could not find:\n{HELPER}\n\nNo fan setting was changed.",
            )
            return False

        action = "--enable" if state == "on" else "--disable"
        try:
            result = subprocess.run(
                ["pkexec", str(HELPER), action],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            return False

        if result.returncode != 0:
            QMessageBox.critical(
                self,
                "Could not change Updated Fan Control",
                "SteamOS did not accept the fan-control change. "
                "No further profile changes were applied.",
            )
            return False
        return True

    @staticmethod
    def direct_steam_launcher() -> Path | None:
        direct = Path("/usr/lib/steam/steam")
        if direct.is_file() and direct.stat().st_mode & 0o111:
            return direct
        return None

    def steam_running(self) -> bool:
        return subprocess.run(
            ["pgrep", "-x", "steam"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

    def close_steam(self) -> bool:
        if not self.steam_running():
            return True

        ans = QMessageBox.question(
            self,
            "Steam must close briefly",
            "Steam needs to close while the per-game launch settings are updated.\n\n"
            "Close Steam now and continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return False

        direct = self.direct_steam_launcher()
        if direct is None:
            QMessageBox.critical(
                self,
                "Direct Steam launcher not found",
                "Fan Profiles intentionally will not call /usr/bin/steam because SteamOS may "
                "open the Screen Sharing chooser.\n\n"
                "Please close Steam manually, then press Apply Profiles again.",
            )
            return False

        subprocess.run(
            [str(direct), "-shutdown"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        for _ in range(125):
            if not self.steam_running():
                return True
            time.sleep(0.2)

        QMessageBox.critical(
            self,
            "Steam is still running",
            "Steam did not close completely. Close Steam manually and try Apply Profiles again.",
        )
        return False

    def start_steam_without_pipewire(self) -> bool:
        direct = self.direct_steam_launcher()
        if direct is None:
            return False

        env = dict(os.environ)
        for key in (
            "GIO_LAUNCHED_DESKTOP_FILE",
            "GIO_LAUNCHED_DESKTOP_FILE_PID",
            "DESKTOP_STARTUP_ID",
            "XDG_ACTIVATION_TOKEN",
        ):
            env.pop(key, None)

        try:
            subprocess.Popen(
                [str(direct), "-steamdeck"],
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
            )
        except Exception:
            return False

        deadline = time.time() + 35
        while time.time() < deadline:
            if self.steam_running():
                time.sleep(2.0)
                try:
                    subprocess.run(
                        [str(direct), "steam://open/main"],
                        env=env,
                        stdin=subprocess.DEVNULL,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        timeout=8,
                    )
                except Exception:
                    pass
                return True
            time.sleep(0.35)

        return False

    def apply_profiles(self):
        desired_enabled = self.master_toggle.isChecked()
        was_enabled = self.saved_enabled

        keep_on = sorted(
            x["key"] for x in self.rows
            if x["keep_on"] and not x["system"]
        )

        if desired_enabled:
            captured_now = False

            if not was_enabled:
                capture = backend_call("capture-original")
                original = capture.stdout.strip().lower()

                if capture.returncode != 0 or original not in ("on", "off"):
                    QMessageBox.critical(
                        self,
                        "Could not remember the original fan setting",
                        "Fan Profiles could not reliably determine whether Updated Fan "
                        "Control was ON or OFF before activation.\n\n"
                        "Nothing was activated, so your existing fan setting was left alone.",
                    )
                    return

                self.saved_original_state = original
                captured_now = True

            # Outside a game, Fan Profiles always owns the ON state.
            if not self.set_updated_fan_control("on"):
                if captured_now:
                    backend_call("clear-original")
                    self.saved_original_state = None
                return

            result = backend_call("apply-policy", POLICY, "1", *keep_on)

            if result.returncode != 0:
                if captured_now and self.saved_original_state in ("on", "off"):
                    self.set_updated_fan_control(self.saved_original_state)
                    backend_call("clear-original")
                    self.saved_original_state = None

                QMessageBox.critical(
                    self,
                    "Could not save profiles",
                    (result.stderr or result.stdout or "Unknown error").strip(),
                )
                return

            self.saved_enabled = True

        else:
            original = self.backend_scalar("original-state", "unknown")
            if original not in ("on", "off"):
                original = self.saved_original_state

            result = backend_call("apply-policy", POLICY, "0", *keep_on)

            if result.returncode != 0:
                QMessageBox.critical(
                    self,
                    "Could not disable Fan Profiles",
                    (result.stderr or result.stdout or "Unknown error").strip(),
                )
                return

            if original in ("on", "off"):
                if not self.set_updated_fan_control(original):
                    self.saved_enabled = False
                    self.saved_original_state = original
                    self.update_master_ui()
                    QMessageBox.warning(
                        self,
                        "Profiles disabled, fan state not restored",
                        f"Fan Profiles was disabled, but SteamOS could not be switched "
                        f"back to Updated Fan Control {original.upper()}.\n\n"
                        "The saved original state was kept so you can press Apply Profiles "
                        "again to retry the restore.",
                    )
                    return

                backend_call("clear-original")
                self.saved_original_state = None

            self.saved_enabled = False

        self.update_master_ui()
        self.update_monitor_label()

        if desired_enabled:
            original_text = (
                self.saved_original_state.upper()
                if self.saved_original_state in ("on", "off")
                else "UNKNOWN"
            )
            message = (
                "Fan Profiles enabled.\n\n"
                f"Restore state: Updated Fan Control {original_text}\n\n"
                "Automatic detection is active:\n"
                "• Desktop/Gaming UI: Updated Fan Control ON\n"
                "• Any new game: Updated Fan Control OFF automatically\n"
                "• Checked exceptions: Updated Fan Control ON\n\n"
                "You no longer need to open Fan Profiles when you install a new game."
            )
        else:
            if original in ("on", "off"):
                message = (
                    "Fan Profiles disabled.\n\n"
                    f"Your original SteamOS state was restored: "
                    f"Updated Fan Control {original.upper()}"
                )
            else:
                message = (
                    "Fan Profiles disabled.\n\n"
                    "SteamOS global fan control is in charge."
                )

        QMessageBox.information(self, "Fan Profiles", message)


def _exception_hook(exc_type, exc_value, exc_tb):
    traceback.print_exception(exc_type, exc_value, exc_tb, file=sys.stderr)
    try:
        QMessageBox.critical(
            None,
            "Steam Machine Fan Profiles",
            "The Fan Profiles GUI encountered an unexpected error.\n\n"
            "A diagnostic log has been written automatically.",
        )
    except Exception:
        pass


def main():
    sys.excepthook = _exception_hook
    app = QApplication(sys.argv)
    app.setApplicationName("Steam Machine Fan Profiles")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
