#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import subprocess
import time
from pathlib import Path

HOME = Path.home()
BASE = HOME / ".local" / "share" / "steam-machine-fan-profiles"
CONF = HOME / ".config" / "steam-machine-fan-profiles"
PROFILES = CONF / "profiles.json"
BACKEND = BASE / "fanprofiles-backend.py"
HELPER = Path("/usr/bin/steamos-polkit-helpers/jupiter-fan-control")
LOG = CONF / "monitor.log"

POLL_SECONDS = 1.5
SYSTEM_IDS_REFRESH_SECONDS = 60.0
LEGACY_CLEANUP_IDLE_SECONDS = 5.0
CHANGE_RETRY_SECONDS = 12.0

APPID_PATTERNS = (
    re.compile(rb"(?:^|\x00)SteamAppId=(\d+)(?:\x00|$)"),
    re.compile(rb"(?:^|\x00)SteamGameId=(\d+)(?:\x00|$)"),
    re.compile(rb"(?:^|\x00)STEAM_COMPAT_APP_ID=(\d+)(?:\x00|$)"),
)
CMD_PATTERNS = (
    re.compile(rb"SteamLaunch AppId=(\d+)"),
    re.compile(rb"STEAM_COMPAT_APP_ID=(\d+)"),
)


def log(message: str) -> None:
    try:
        CONF.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%F %T')} {message}\n")
    except Exception:
        pass


def load_profiles() -> dict:
    try:
        data = json.loads(PROFILES.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def exception_ids(data: dict) -> set[str]:
    out: set[str] = set()
    default_on = data.get("default_on", {})
    if not isinstance(default_on, dict):
        return out

    for key in default_on:
        key = str(key)
        if key.startswith("n:"):
            key = key[2:]
        if key.isdigit():
            out.add(key)
    return out


def current_fan_state() -> str | None:
    try:
        r = subprocess.run(
            ["systemctl", "is-active", "--quiet", "jupiter-fan-control.service"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return "on" if r.returncode == 0 else "off"
    except Exception:
        return None


def set_fan_state(state: str) -> bool:
    if state not in ("on", "off") or not HELPER.is_file():
        return False

    action = "--enable" if state == "on" else "--disable"

    try:
        r = subprocess.run(
            ["pkexec", str(HELPER), action],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=20,
        )
        if r.returncode == 0:
            log(f"fan -> {state.upper()}")
            return True
        log(f"fan change to {state} failed rc={r.returncode}")
    except Exception as e:
        log(f"fan change to {state} exception: {e}")
    return False


def steam_running() -> bool:
    try:
        return subprocess.run(
            ["pgrep", "-x", "steam"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0
    except Exception:
        return False


def process_appids() -> set[str]:
    """Detect Steam-launched AppIDs from current user processes.

    This works for native Steam games, Proton games, and typical non-Steam
    shortcuts because Steam's launcher/reaper carries the shortcut AppID.
    """
    ids: set[str] = set()
    uid = os.getuid()

    proc = Path("/proc")
    try:
        entries = list(proc.iterdir())
    except Exception:
        return ids

    for p in entries:
        if not p.name.isdigit():
            continue

        try:
            if p.stat().st_uid != uid:
                continue
        except Exception:
            continue

        blobs = []
        try:
            blobs.append((p / "environ").read_bytes())
        except Exception:
            pass
        try:
            blobs.append((p / "cmdline").read_bytes())
        except Exception:
            pass

        for blob in blobs:
            if not blob:
                continue

            for pat in APPID_PATTERNS + CMD_PATTERNS:
                for m in pat.finditer(blob):
                    value = m.group(1).decode("ascii", "ignore")
                    if value.isdigit() and value != "0":
                        ids.add(value)

    return ids


def load_system_ids() -> set[str]:
    try:
        r = subprocess.run(
            [str(BACKEND), "system-ids"],
            text=True,
            capture_output=True,
            timeout=10,
        )
        if r.returncode != 0:
            return set()
        return {line.strip() for line in r.stdout.splitlines() if line.strip().isdigit()}
    except Exception:
        return set()


def legacy_status() -> bool:
    try:
        r = subprocess.run(
            [str(BACKEND), "legacy-status"],
            text=True,
            capture_output=True,
            timeout=10,
        )
        return r.returncode == 0 and r.stdout.strip() == "1"
    except Exception:
        return False


def cleanup_legacy() -> bool:
    try:
        r = subprocess.run(
            [str(BACKEND), "cleanup-legacy"],
            text=True,
            capture_output=True,
            timeout=30,
        )
        if r.returncode == 0:
            log("legacy V2 launch-option wrappers cleaned")
            return True
        log(f"legacy cleanup deferred/failed rc={r.returncode}")
    except Exception as e:
        log(f"legacy cleanup exception: {e}")
    return False


def main() -> int:
    log("monitor started")

    cached_system_ids: set[str] = set()
    next_system_refresh = 0.0
    last_desired: str | None = None
    last_change_attempt = 0.0

    # Legacy cleanup waits until Steam has been continuously absent for a few
    # seconds. This avoids racing Steam startup/shutdown.
    steam_absent_since: float | None = None
    legacy_check_due = 0.0

    while True:
        now = time.monotonic()

        if now >= next_system_refresh:
            cached_system_ids = load_system_ids()
            next_system_refresh = now + SYSTEM_IDS_REFRESH_SECONDS

        # One-time cleanup of old V2 launch-option wrappers.
        if steam_running():
            steam_absent_since = None
        else:
            if steam_absent_since is None:
                steam_absent_since = now

            if (
                now - steam_absent_since >= LEGACY_CLEANUP_IDLE_SECONDS
                and now >= legacy_check_due
            ):
                legacy_check_due = now + 60.0
                if legacy_status():
                    cleanup_legacy()

        data = load_profiles()
        enabled = bool(data.get("enabled", False))

        if not enabled:
            # GUI/uninstaller owns restoring the original pre-activation state.
            last_desired = None
            time.sleep(POLL_SECONDS)
            continue

        keep_on = exception_ids(data)
        active_ids = process_appids() - cached_system_ids

        # Conservative rule:
        # - no game -> Updated Fan Control ON
        # - only Keep-ON games -> ON
        # - any other/new game -> OFF
        if not active_ids:
            desired = "on"
        elif all(appid in keep_on for appid in active_ids):
            desired = "on"
        else:
            desired = "off"

        current = current_fan_state()

        if desired != current:
            # Avoid hammering polkit if a state change temporarily fails.
            if desired != last_desired or now - last_change_attempt >= CHANGE_RETRY_SECONDS:
                last_change_attempt = now
                last_desired = desired
                if set_fan_state(desired):
                    current = desired
        else:
            last_desired = desired

        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    raise SystemExit(main())
