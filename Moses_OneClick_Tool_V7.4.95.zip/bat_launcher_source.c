/* Minimal Windows/Proton launcher. Built without a C runtime. */
typedef __WCHAR_TYPE__ wchar_t;
typedef unsigned long DWORD;
typedef int BOOL;
typedef void *HANDLE;
typedef const wchar_t *LPCWSTR;
typedef wchar_t *LPWSTR;
typedef void *LPVOID;
typedef unsigned short WORD;
typedef unsigned char BYTE;
typedef struct { DWORD cb; LPWSTR lpReserved; LPWSTR lpDesktop; LPWSTR lpTitle; DWORD dwX; DWORD dwY; DWORD dwXSize; DWORD dwYSize; DWORD dwXCountChars; DWORD dwYCountChars; DWORD dwFillAttribute; DWORD dwFlags; WORD wShowWindow; WORD cbReserved2; BYTE *lpReserved2; HANDLE hStdInput; HANDLE hStdOutput; HANDLE hStdError; } STARTUPINFOW;
typedef struct { HANDLE hProcess; HANDLE hThread; DWORD dwProcessId; DWORD dwThreadId; } PROCESS_INFORMATION;
__declspec(dllimport) LPWSTR __stdcall GetCommandLineW(void);
__declspec(dllimport) BOOL __stdcall CreateProcessW(LPCWSTR, LPWSTR, LPVOID, LPVOID, BOOL, DWORD, LPVOID, LPCWSTR, STARTUPINFOW*, PROCESS_INFORMATION*);
__declspec(dllimport) DWORD __stdcall WaitForSingleObject(HANDLE, DWORD);
__declspec(dllimport) BOOL __stdcall GetExitCodeProcess(HANDLE, DWORD*);
__declspec(dllimport) BOOL __stdcall CloseHandle(HANDLE);
__declspec(dllimport) void __stdcall ExitProcess(DWORD);
__declspec(dllimport) int __stdcall MessageBoxW(void*, LPCWSTR, LPCWSTR, unsigned int);
static wchar_t bat[8192], parent[8192], cmd[16420];
static void fail(const wchar_t *message, DWORD code) {
    MessageBoxW(0, message, L"Moses OneClick BAT launcher", 0x10);
    ExitProcess(code);
}
void __stdcall WinMainCRTStartup(void) {
    wchar_t *p=GetCommandLineW();
    if (!p) fail(L"Steam did not supply the batch script path.", 2);
    if (*p==L'"') { ++p; while (*p && *p != L'"') ++p; if (*p) ++p; }
    else while (*p && *p!=L' ' && *p!=L'\t') ++p;
    while (*p==L' ' || *p==L'\t') ++p;
    /* Steam/Proton may strip quotes while constructing Windows argv. This
       launcher takes exactly one argument, so unquoted paths can safely use
       the entire remaining command line, including spaces. */
    int quoted = (*p==L'"');
    if (quoted) ++p;
    unsigned n=0;
    while (*p && (!quoted || *p!=L'"') && n<8190) bat[n++]=*p++;
    if (quoted && *p!=L'"') fail(L"Unterminated quoted batch script path.",2);
    if (!quoted) while (n>0 && (bat[n-1]==L' ' || bat[n-1]==L'\t')) --n;
    bat[n]=0;
    if (n<5) fail(L"Invalid batch script path in Steam launch options.",2);
    if (!((bat[n-4]==L'.') && (bat[n-3]==L'b'||bat[n-3]==L'B') && (bat[n-2]==L'a'||bat[n-2]==L'A') && (bat[n-1]==L't'||bat[n-1]==L'T'))) fail(L"Launch target is not a .bat file.",2);
    unsigned i; for (i=0;i<n;i++) parent[i]=bat[i]; parent[n]=0;
    for (i=n;i>0;i--) if (parent[i-1]==L'\\' || parent[i-1]==L'/') { parent[i-1]=0; break; }
    if (i==0 || !parent[0]) fail(L"Could not determine batch script working directory.",2);
    const wchar_t start[]=L"cmd.exe /D /S /C \"\"";
    const wchar_t end[]=L"\"\"";
    unsigned j=0;
    for (i=0;start[i];i++) cmd[j++]=start[i];
    for (i=0;bat[i];i++) cmd[j++]=bat[i];
    for (i=0;end[i];i++) cmd[j++]=end[i];
    cmd[j]=0;
    STARTUPINFOW si={0}; si.cb=sizeof(si);
    PROCESS_INFORMATION pi={0};
    if (!CreateProcessW(L"C:\\windows\\system32\\cmd.exe", cmd, 0, 0, 0, 0, 0, parent, &si, &pi))
        fail(L"Could not start cmd.exe in Proton. Check Steam's compatibility tool.",3);
    WaitForSingleObject(pi.hProcess, 0xffffffff);
    DWORD result=1;
    GetExitCodeProcess(pi.hProcess,&result);
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    ExitProcess(result);
}
