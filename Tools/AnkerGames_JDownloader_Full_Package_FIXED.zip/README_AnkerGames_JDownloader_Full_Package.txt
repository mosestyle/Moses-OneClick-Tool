AnkerGames JDownloader 2 Full Package — FIXED

Contains:
  AnkerGames_JDownloader_Full_Setup.sh
  AnkerGames_JDownloader_Full_Uninstaller.sh

INSTALL
1. Close JDownloader completely.
2. Run:
   bash ~/Downloads/AnkerGames_JDownloader_Full_Setup.sh

EXPECTED EXTRACTION LAYOUT
If:
  PEAK-AnkerGames.zip

contains:
  Read Me.txt
  Run Me!.bat
  Picture.png
  PEAK/
    ...game files...

the final result is:
  ~/Downloads/PEAK-AnkerGames/
    Read Me.txt
    Run Me!.bat
    Picture.png
    PEAK/
      ...game files...

UNINSTALL
1. Close JDownloader completely.
2. Run:
   bash ~/Downloads/AnkerGames_JDownloader_Full_Uninstaller.sh

This corrected package fixes the installer runtime error caused by an
accidentally uncommented descriptive bullet near the top of the setup script.
