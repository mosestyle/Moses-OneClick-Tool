#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# AnkerGames -> JDownloader 2 FULL setup for SteamOS/Linux
# Version: 1.1-fixed
#
# One complete installer:
#   * On-demand localhost bridge (no permanent Python process)
#   * Automatic JDownloader LinkCrawler rules
#   * Downloads archives directly into ~/Downloads
#   * Automatic ZIP/RAR/7Z extraction after download
#   * Creates one folder named exactly like the archive (minus extension)
#   * Deletes archive only after successful extraction
#   * ZIP Zstandard method 93 support
#   * Preserves the archive's original internal folder/file layout
#   * Removes old experimental AnkerGames Event Scripter rules
#
# Uninstall everything installed by this script:
#   bash AnkerGames_JDownloader_Full_Setup.sh --uninstall
# ============================================================

APP_DIR="$HOME/.local/share/ankergames-jd-bridge"
VENV_DIR="$APP_DIR/.venv"
BRIDGE_PY="$APP_DIR/bridge.py"
POSTPROCESS_PY="$APP_DIR/postprocess_after_jd.py"
STATE_FILE="$APP_DIR/full-setup-state.json"
BACKUP_DIR="$APP_DIR/config-backups"

SYSTEMD_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.service"
SOCKET_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.socket"
SERVICE_NAME="ankergames-jd-bridge.service"
SOCKET_NAME="ankergames-jd-bridge.socket"
PORT="17892"

JD_LINK_RULES_NAME="jd.controlling.linkcrawler.LinkCrawlerConfig.linkcrawlerrules.json"
JD_LINK_MAIN_NAME="jd.controlling.linkcrawler.LinkCrawlerConfig.json"
JD_PACK_RULES_NAME="org.jdownloader.controlling.packagizer.PackagizerSettings.rulelist.json"
JD_EVENT_SCRIPTS_NAME="org.jdownloader.extensions.eventscripter.EventScripterExtension.scripts.json"

RULE_NAME_REWRITE="AnkerGames to JD Bridge"
RULE_NAME_DIRECT="AnkerGames JD Bridge DirectHTTP"

echo
echo "============================================================"
echo " AnkerGames JDownloader 2 - Full Setup"
echo "============================================================"
echo

find_jd_cfg_dir() {
    local f=""

    # Prefer the config folder which already contains our known JD files.
    for filename in \
        "$JD_LINK_RULES_NAME" \
        "$JD_PACK_RULES_NAME" \
        "$JD_EVENT_SCRIPTS_NAME"
    do
        while IFS= read -r f; do
            [[ -n "$f" ]] || continue
            dirname "$f"
            return 0
        done < <(
            find "$HOME" -maxdepth 10 -type f -name "$filename" \
                -printf '%T@ %p\n' 2>/dev/null | sort -nr | cut -d' ' -f2-
        )
    done

    # Common Linux / SteamOS paths.
    local d
    for d in \
        "$HOME/.var/app/org.jdownloader.JDownloader/data/jdownloader/cfg" \
        "$HOME/.var/app/org.jdownloader.JDownloader/data/JDownloader/cfg" \
        "$HOME/.jd/cfg" \
        "$HOME/JDownloader/cfg" \
        "$HOME/JDownloader2/cfg" \
        "$HOME/.local/share/JDownloader/cfg"
    do
        if [[ -d "$d" ]]; then
            printf '%s\n' "$d"
            return 0
        fi
    done

    return 1
}

jdownloader_is_running() {
    pgrep -af \
        'java.*JDownloader|JDownloader\.jar|org\.jdownloader\.update|org\.jdownloader\.launcher' \
        >/dev/null 2>&1
}

restore_packagizer_state() {
    local cfg_dir="$1"
    local pack_rules="$cfg_dir/$JD_PACK_RULES_NAME"

    [[ -f "$STATE_FILE" && -f "$pack_rules" ]] || return 0

    STATE_FILE="$STATE_FILE" PACK_RULES="$pack_rules" python3 <<'PY'
import json
import os
from pathlib import Path

state_path = Path(os.environ["STATE_FILE"])
pack_path = Path(os.environ["PACK_RULES"])

try:
    state = json.loads(state_path.read_text(encoding="utf-8"))
    rules = json.loads(pack_path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(rules, list):
    raise SystemExit(0)

if state.get("subfolder_rule_found"):
    old_enabled = bool(state.get("subfolder_rule_original_enabled"))
    changed = False
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        rid = str(rule.get("id") or "")
        name = str(rule.get("name") or "")
        if rid == "SubFolderByPackageRule" or name == "Create Subfolder by Packagename":
            rule["enabled"] = old_enabled
            changed = True

    if changed:
        tmp = pack_path.with_suffix(pack_path.suffix + ".tmp")
        tmp.write_text(
            json.dumps(rules, ensure_ascii=False, separators=(",", ":")) + "\n",
            encoding="utf-8",
        )
        os.replace(tmp, pack_path)
        print("Restored JDownloader's original package-subfolder setting.")
PY
}

remove_our_jd_rules() {
    local cfg_dir="$1"
    local link_rules="$cfg_dir/$JD_LINK_RULES_NAME"
    local event_scripts="$cfg_dir/$JD_EVENT_SCRIPTS_NAME"

    if [[ -f "$link_rules" ]]; then
        LINK_RULES="$link_rules" python3 <<'PY'
import json
import os
from pathlib import Path

p = Path(os.environ["LINK_RULES"])
try:
    data = json.loads(p.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(data, list):
    raise SystemExit(0)

names = {
    "AnkerGames to JD Bridge",
    "AnkerGames JD Bridge DirectHTTP",
}

cleaned = []
for item in data:
    if isinstance(item, dict):
        name = str(item.get("name") or "")
        pattern = str(item.get("pattern") or "")
        if name in names:
            continue
        if "AnkerGames" in name and (
            "dlproxy" in pattern or "127\\.0\\.0\\.1:17892" in pattern
        ):
            continue
    cleaned.append(item)

tmp = p.with_suffix(p.suffix + ".tmp")
tmp.write_text(
    json.dumps(cleaned, ensure_ascii=False, indent=1) + "\n",
    encoding="utf-8",
)
os.replace(tmp, p)
PY
    fi

    # Remove only our old experimental Event Scripter entries.
    if [[ -f "$event_scripts" ]]; then
        EVENT_SCRIPTS="$event_scripts" python3 <<'PY'
import json
import os
from pathlib import Path

p = Path(os.environ["EVENT_SCRIPTS"])
try:
    data = json.loads(p.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(data, list):
    raise SystemExit(0)

names = {
    "AnkerGames Download Folder",
    "AnkerGames Force Extract",
    "AnkerGames Actual Package Folder",
    "AnkerGames Archive Fallback",
}

cleaned = [
    item for item in data
    if not (
        isinstance(item, dict)
        and str(item.get("name") or "") in names
    )
]

tmp = p.with_suffix(p.suffix + ".tmp")
tmp.write_text(
    json.dumps(cleaned, ensure_ascii=False, indent=1) + "\n",
    encoding="utf-8",
)
os.replace(tmp, p)
PY
    fi
}

uninstall_all() {
    if jdownloader_is_running; then
        echo "JDownloader 2 is still running."
        echo "Close JDownloader completely, then run:"
        echo "  bash \"$0\" --uninstall"
        exit 1
    fi

    local cfg_dir=""
    cfg_dir="$(find_jd_cfg_dir || true)"

    if [[ -n "$cfg_dir" ]]; then
        restore_packagizer_state "$cfg_dir" || true
        remove_our_jd_rules "$cfg_dir" || true
    fi

    systemctl --user disable --now "$SOCKET_NAME" >/dev/null 2>&1 || true
    systemctl --user disable --now "$SERVICE_NAME" >/dev/null 2>&1 || true
    rm -f "$SOCKET_FILE" "$SERVICE_FILE"
    systemctl --user daemon-reload >/dev/null 2>&1 || true
    systemctl --user reset-failed "$SERVICE_NAME" >/dev/null 2>&1 || true

    rm -rf "$APP_DIR"

    echo
    echo "AnkerGames JDownloader integration removed."
    echo "Unrelated JDownloader settings/rules were preserved."
    exit 0
}

if [[ "${1:-}" == "--uninstall" ]]; then
    uninstall_all
fi

if jdownloader_is_running; then
    echo "JDownloader 2 is still running."
    echo
    echo "CLOSE JDownloader completely before installing."
    echo "JDownloader keeps configuration in memory and may overwrite changes on exit."
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "ERROR: python3 was not found."
    exit 1
fi

if ! python3 -m venv --help >/dev/null 2>&1; then
    echo "ERROR: Python venv support was not found."
    exit 1
fi

CFG_DIR="$(find_jd_cfg_dir || true)"
if [[ -z "$CFG_DIR" ]]; then
    echo "ERROR: Could not find JDownloader's cfg folder."
    echo
    echo "Open JDownloader once, then close it completely and run this script again."
    exit 1
fi

LINK_RULES="$CFG_DIR/$JD_LINK_RULES_NAME"
LINK_MAIN="$CFG_DIR/$JD_LINK_MAIN_NAME"
PACK_RULES="$CFG_DIR/$JD_PACK_RULES_NAME"
EVENT_SCRIPTS="$CFG_DIR/$JD_EVENT_SCRIPTS_NAME"

mkdir -p "$APP_DIR" "$SYSTEMD_DIR" "$BACKUP_DIR"

STAMP="$(date +%Y%m%d-%H%M%S)"
THIS_BACKUP="$BACKUP_DIR/$STAMP"
mkdir -p "$THIS_BACKUP"

for f in "$LINK_RULES" "$LINK_MAIN" "$PACK_RULES" "$EVENT_SCRIPTS"; do
    if [[ -f "$f" ]]; then
        cp -a "$f" "$THIS_BACKUP/$(basename "$f")"
    fi
done

echo "JDownloader cfg:"
echo "  $CFG_DIR"
echo
echo "Backup:"
echo "  $THIS_BACKUP"
echo

# Stop all old variants before replacing them.
systemctl --user disable --now "$SERVICE_NAME" >/dev/null 2>&1 || true
systemctl --user disable --now "$SOCKET_NAME" >/dev/null 2>&1 || true

# ------------------------------------------------------------
# Private Python environment
# ------------------------------------------------------------
if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    echo "Creating private Python environment..."
    rm -rf "$VENV_DIR"
    python3 -m venv "$VENV_DIR"
fi

echo "Installing/updating bridge dependencies..."
PIP_DISABLE_PIP_VERSION_CHECK=1 "$VENV_DIR/bin/python" -m pip install -q \
    'httpx>=0.27,<1' \
    'backports.zstd>=1.0.0'

"$VENV_DIR/bin/python" - <<'PY'
import importlib
import sys

importlib.import_module("httpx")
if sys.version_info < (3, 14):
    importlib.import_module("backports.zstd.zipfile")
else:
    importlib.import_module("zipfile")

print("Dependencies: OK")
PY

# ------------------------------------------------------------
# Postprocessor
#
# This is deliberately NOT a permanent service.
# The bridge starts it only after an archive's last byte is served.
# ------------------------------------------------------------
cat > "$POSTPROCESS_PY" <<'PYPOST'
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path, PurePosixPath

DOWNLOADS = Path.home() / "Downloads"
APP_DIR = Path.home() / ".local" / "share" / "ankergames-jd-bridge"
LOG_FILE = APP_DIR / "postprocess.log"
LOCK_DIR = APP_DIR / "postprocess-locks"
LOCK_DIR.mkdir(parents=True, exist_ok=True)

SUPPORTED = {".zip", ".rar", ".7z"}


def log(message: str) -> None:
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    try:
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def safe_member(base: Path, name: str) -> Path:
    normalized = str(name or "").replace("\\", "/")
    pure = PurePosixPath(normalized)

    if pure.is_absolute():
        raise RuntimeError(f"Unsafe absolute path in archive: {name}")

    parts = [p for p in pure.parts if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise RuntimeError(f"Unsafe parent path in archive: {name}")
    if parts and ":" in parts[0]:
        raise RuntimeError(f"Unsafe drive path in archive: {name}")

    result = base.joinpath(*parts)
    result.resolve().relative_to(base.resolve())
    return result


def clean_archive_folder_name(filename: str) -> str:
    """Create a container folder with the SAME name as the archive minus extension.

    Example:
      PEAK-AnkerGames.zip -> PEAK-AnkerGames/
    """
    stem = Path(filename).stem.strip()
    if not stem:
        stem = "AnkerGames"

    stem = re.sub(r"[\x00-\x1f\x7f/\\]+", "_", stem).strip(" .")
    return stem or "AnkerGames"


def find_finished_archive(
    filename: str,
    expected_size: int,
    timeout_seconds: int = 6 * 60 * 60,
) -> Path | None:
    """Wait for JDownloader's final file, wherever it put it under Downloads."""
    deadline = time.monotonic() + timeout_seconds

    while time.monotonic() < deadline:
        try:
            matches = [p for p in DOWNLOADS.rglob(filename) if p.is_file()]
        except Exception:
            matches = []

        for path in matches:
            try:
                s1 = path.stat().st_size

                # Exact size prevents us from treating an unfinished/partial file
                # as a completed download.
                if expected_size > 0 and s1 != expected_size:
                    continue

                time.sleep(1.0)
                s2 = path.stat().st_size

                if s1 == s2 and (expected_size <= 0 or s2 == expected_size):
                    return path
            except OSError:
                continue

        time.sleep(1.0)

    return None


def move_archive_to_downloads_root(path: Path) -> tuple[Path, Path | None]:
    if path.parent.resolve() == DOWNLOADS.resolve():
        return path, None

    old_parent = path.parent
    target = DOWNLOADS / path.name

    if target.exists():
        # Never overwrite an unrelated file.
        log(f"Archive already exists in Downloads root; using source path: {path}")
        return path, old_parent

    os.replace(path, target)
    log(f"Moved completed archive to Downloads root: {target}")
    return target, old_parent


def get_zipfile_module():
    if sys.version_info >= (3, 14):
        import zipfile as zstd_zipfile
        return zstd_zipfile

    from backports.zstd import zipfile as zstd_zipfile
    return zstd_zipfile


def extract_zip_to_staging(archive: Path, staging: Path) -> None:
    zfmod = get_zipfile_module()

    with zfmod.ZipFile(archive, "r") as zf:
        infos = zf.infolist()
        if not infos:
            raise RuntimeError("ZIP archive contains no entries")

        methods = sorted({
            int(getattr(info, "compress_type", -1))
            for info in infos
        })
        log(f"ZIP compression methods: {methods}")

        # Validate every archive member before writing anything.
        for info in infos:
            safe_member(staging, info.filename)

        for info in infos:
            target = safe_member(staging, info.filename)

            if info.is_dir() or str(info.filename).replace("\\", "/").endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                continue

            target.parent.mkdir(parents=True, exist_ok=True)

            with zf.open(info, "r") as source, target.open("wb") as dest:
                shutil.copyfileobj(source, dest, length=4 * 1024 * 1024)


def validate_bsdtar_members(archive: Path, staging: Path) -> None:
    proc = subprocess.run(
        ["bsdtar", "-tf", str(archive)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    if proc.returncode != 0:
        raise RuntimeError(
            proc.stderr.strip()
            or f"bsdtar could not list {archive.name}"
        )

    for name in proc.stdout.splitlines():
        if name.strip():
            safe_member(staging, name.strip())


def extract_bsdtar_to_staging(archive: Path, staging: Path) -> None:
    if shutil.which("bsdtar") is None:
        raise RuntimeError("bsdtar is not installed")

    validate_bsdtar_members(archive, staging)

    proc = subprocess.run(
        ["bsdtar", "-xf", str(archive), "-C", str(staging)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    if proc.returncode != 0:
        raise RuntimeError(
            proc.stderr.strip()
            or f"bsdtar exited with code {proc.returncode}"
        )


def extract_7z_to_staging(archive: Path, staging: Path) -> None:
    exe = shutil.which("7z") or shutil.which("7zz")
    if exe is None:
        raise RuntimeError("Neither bsdtar nor 7z/7zz is installed")

    proc = subprocess.run(
        [exe, "x", str(archive), f"-o{staging}", "-y", "-aoa"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    if proc.returncode != 0:
        tail = "\n".join((proc.stdout or "").splitlines()[-20:])
        raise RuntimeError(tail or f"7z exited with code {proc.returncode}")

    # 7z extraction itself performed the path handling. Refuse any unexpected
    # symlink-like escape by checking every produced path remains below staging.
    staging_resolved = staging.resolve()
    for p in staging.rglob("*"):
        p.resolve().relative_to(staging_resolved)


def extract_to_staging(archive: Path, staging: Path) -> None:
    ext = archive.suffix.lower()

    if ext == ".zip":
        extract_zip_to_staging(archive, staging)
        return

    # Prefer SteamOS libarchive for RAR/7Z.
    try:
        extract_bsdtar_to_staging(archive, staging)
    except Exception as first:
        log(f"bsdtar extraction failed; trying 7z: {first}")
        extract_7z_to_staging(archive, staging)


def remove_existing_target(path: Path) -> None:
    if not path.exists() and not path.is_symlink():
        return

    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def merge_item(source: Path, target: Path) -> None:
    if source.is_dir() and not source.is_symlink():
        target.mkdir(parents=True, exist_ok=True)
        for child in list(source.iterdir()):
            merge_item(child, target / child.name)
        try:
            source.rmdir()
        except OSError:
            pass
        return

    target.parent.mkdir(parents=True, exist_ok=True)
    remove_existing_target(target)
    os.replace(source, target)


def merge_staging_into_archive_folder(staging: Path, archive_folder: Path) -> None:
    """Preserve the archive's original top-level layout inside one container folder.

    Example archive contents:
      Read Me.txt
      Run Me!.bat
      Picture.png
      PEAK/

    Result:
      Downloads/PEAK-AnkerGames/
          Read Me.txt
          Run Me!.bat
          Picture.png
          PEAK/
    """
    archive_folder.mkdir(parents=True, exist_ok=True)

    for child in list(staging.iterdir()):
        merge_item(child, archive_folder / child.name)


def remove_empty_old_package_folder(folder: Path | None) -> None:
    if folder is None:
        return

    current = folder
    downloads_resolved = DOWNLOADS.resolve()

    while True:
        try:
            if current.resolve() == downloads_resolved:
                break
            current.rmdir()
            log(f"Removed empty old JDownloader package folder: {current}")
            current = current.parent
        except OSError:
            break


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--filename", required=True)
    parser.add_argument("--size", required=True, type=int)
    args = parser.parse_args()

    filename = Path(args.filename).name
    expected_size = int(args.size)

    if Path(filename).suffix.lower() not in SUPPORTED:
        return 0

    lock_name = re.sub(
        r"[^A-Za-z0-9_.-]+",
        "_",
        f"{filename}-{expected_size}",
    ) + ".lock"

    lock_file = LOCK_DIR / lock_name

    try:
        fd = os.open(
            lock_file,
            os.O_CREAT | os.O_EXCL | os.O_WRONLY,
            0o600,
        )
        os.close(fd)
    except FileExistsError:
        # Another helper for the same exact archive is already waiting/working.
        return 0

    staging: Path | None = None

    try:
        log(
            f"Waiting for JDownloader final file: "
            f"{filename} ({expected_size} bytes)"
        )

        archive = find_finished_archive(filename, expected_size)

        if archive is None:
            log(f"Timed out waiting for completed archive: {filename}")
            return 2

        # Give JDownloader's native extractor a very short chance first.
        # If JD succeeds, its delete-after-extraction setting removes the archive.
        time.sleep(3)

        if not archive.exists():
            log(f"JDownloader extracted archive itself: {filename}")
            return 0

        archive, old_package_folder = move_archive_to_downloads_root(archive)

        archive_folder_name = clean_archive_folder_name(archive.name)
        archive_folder = DOWNLOADS / archive_folder_name

        staging = Path(
            tempfile.mkdtemp(
                prefix=".ankergames-extract-",
                dir=str(DOWNLOADS),
            )
        )

        log(f"Archive: {archive}")
        log(f"Archive container folder: {archive_folder}")
        log(f"Extracting safely to staging: {staging}")

        extract_to_staging(archive, staging)

        log("Archive extraction completed; preserving original layout inside archive-named folder.")
        merge_staging_into_archive_folder(staging, archive_folder)

        # Match the user's JD setting: delete archive only AFTER success.
        archive.unlink()
        log(f"SUCCESS. Deleted archive: {archive}")

        remove_empty_old_package_folder(old_package_folder)
        return 0

    except Exception as exc:
        log(
            f"FAILED for {filename}: "
            f"{type(exc).__name__}: {exc}"
        )
        # Archive remains untouched on failure.
        return 1

    finally:
        if staging is not None:
            try:
                shutil.rmtree(staging, ignore_errors=True)
            except Exception:
                pass

        try:
            lock_file.unlink()
        except OSError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
PYPOST

chmod +x "$POSTPROCESS_PY"
"$VENV_DIR/bin/python" -m py_compile "$POSTPROCESS_PY"

# ------------------------------------------------------------
# On-demand bridge
# ------------------------------------------------------------
cat > "$BRIDGE_PY" <<'PYBRIDGE'
from __future__ import annotations

import os
import re
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlsplit

import httpx

HOST_RE = re.compile(r"^tunnel\d+\.dlproxy\.uk$", re.I)

PORT = 17892
MIB = 1024 * 1024
CHUNK = 1024 * 1024
MAX_RETRIES = 6
IDLE_SECONDS = 45.0
CACHE_SECONDS = 15 * 60

RETRYABLE = {
    408, 425, 429,
    500, 502, 503, 504,
    520, 521, 522, 523, 524,
}

BASE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/128.0 Safari/537.36"
    ),
    "Accept": "*/*",
    "Accept-Encoding": "identity",
}

APP_DIR = os.path.dirname(os.path.abspath(__file__))
POSTPROCESS_PATH = os.path.join(APP_DIR, "postprocess_after_jd.py")
POSTPROCESS_LAUNCH_LOG = os.path.join(APP_DIR, "postprocess-launch.log")

_cache_lock = threading.Lock()
_meta_cache: dict[str, tuple[float, dict]] = {}


def parse_content_range(value: str | None):
    if not value:
        return None

    m = re.match(
        r"^\s*bytes\s+(\d+)-(\d+)/(\d+|\*)\s*$",
        value,
        re.I,
    )

    if not m:
        return None

    start = int(m.group(1))
    end = int(m.group(2))
    total = None if m.group(3) == "*" else int(m.group(3))

    if end < start:
        return None

    return start, end, total


def sniff_extension(data: bytes) -> str:
    head = bytes(data or b"")

    if head.startswith((
        b"Rar!\x1a\x07\x01\x00",
        b"Rar!\x1a\x07\x00",
    )):
        return "rar"

    if head.startswith((
        b"PK\x03\x04",
        b"PK\x05\x06",
        b"PK\x07\x08",
    )):
        return "zip"

    if head.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "7z"

    return "bin"


def clean_filename(value: str | None, fallback: str) -> str:
    name = unquote(str(value or "")).strip().strip("\"'")
    name = name.replace("\\", "/").split("/")[-1].strip()
    name = re.sub(r"[\x00-\x1f\x7f/\\]+", "_", name).strip(" .")

    if not name or name in (".", ".."):
        return fallback

    return name[:220]


def filename_from_content_disposition(value: str | None) -> str | None:
    if not value:
        return None

    m = re.search(
        r"(?i)(?:^|;)\s*filename\*\s*=\s*"
        r"(?:UTF-8''|utf-8'[^']*')?([^;]+)",
        value,
    )

    if m:
        name = clean_filename(m.group(1).strip().strip("\"'"), "")
        if name:
            return name

    m = re.search(
        r'(?i)(?:^|;)\s*filename\s*=\s*"([^"]+)"',
        value,
    )

    if not m:
        m = re.search(
            r"(?i)(?:^|;)\s*filename\s*=\s*([^;]+)",
            value,
        )

    if m:
        name = clean_filename(m.group(1).strip(), "")
        if name:
            return name

    return None


def make_client():
    timeout = httpx.Timeout(
        connect=30.0,
        read=None,
        write=30.0,
        pool=30.0,
    )

    return httpx.Client(
        follow_redirects=True,
        timeout=timeout,
        headers=BASE_HEADERS,
        http2=False,
    )


def retry_delay(response: httpx.Response | None, attempt: int) -> float:
    if response is not None:
        try:
            retry_after = float(
                response.headers.get("Retry-After", "")
            )
            if retry_after >= 0:
                return min(max(retry_after, 0.25), 12.0)
        except Exception:
            pass

    return min(
        0.5 * (2 ** max(0, attempt)),
        5.0,
    )


def get_target(path: str) -> str | None:
    parsed = urlsplit(path)

    # Main JDownloader rewrite form.
    if parsed.path == "/AnkerGames-download.bin":
        qs = parse_qs(parsed.query, keep_blank_values=True)

        host = (qs.get("host") or [""])[0]
        token = (qs.get("token") or [""])[0]
        sig = (qs.get("sig") or [""])[0]

        if not HOST_RE.fullmatch(host):
            return None

        if not re.fullmatch(r"[A-Za-z0-9_-]+", token):
            return None

        if not re.fullmatch(r"[A-Za-z0-9_-]+", sig):
            return None

        return (
            f"https://{host}/download/{token}"
            f"?sig={sig}"
        )

    # Backward compatibility for older local bridge URLs.
    clean_path = parsed.path.lstrip("/")

    if "/" not in clean_path:
        return None

    host, rest = clean_path.split("/", 1)

    if not HOST_RE.fullmatch(host):
        return None

    if not rest.startswith("download/"):
        return None

    target = f"https://{host}/{rest}"

    if parsed.query:
        target += "?" + parsed.query

    return target


def probe_target(target: str) -> dict:
    now = time.monotonic()

    with _cache_lock:
        cached = _meta_cache.get(target)

        if cached and now - cached[0] < CACHE_SECONDS:
            return dict(cached[1])

    last_error = None

    with make_client() as client:
        for attempt in range(MAX_RETRIES):
            try:
                headers = {
                    "Range": f"bytes=0-{MIB - 1}",
                    "Accept-Encoding": "identity",
                }

                with client.stream(
                    "GET",
                    target,
                    headers=headers,
                ) as response:
                    status = int(response.status_code)

                    if status in RETRYABLE:
                        last_error = (
                            f"HTTP {status} "
                            f"{response.reason_phrase}"
                        )
                        time.sleep(
                            retry_delay(response, attempt)
                        )
                        continue

                    if status >= 400:
                        body = b""

                        try:
                            body = next(
                                response.iter_raw(
                                    chunk_size=4096
                                ),
                                b"",
                            )[:512]
                        except Exception:
                            pass

                        detail = (
                            body.decode(
                                "utf-8",
                                "replace",
                            )
                            .replace("\n", " ")
                            [:300]
                        )

                        raise RuntimeError(
                            f"upstream HTTP {status}: "
                            f"{detail}"
                        )

                    total = None
                    content_range = parse_content_range(
                        response.headers.get(
                            "Content-Range"
                        )
                    )

                    if content_range and content_range[2]:
                        total = content_range[2]

                    elif status == 200:
                        length = response.headers.get(
                            "Content-Length"
                        )

                        if (
                            response.headers
                            .get("Accept-Ranges", "")
                            .lower()
                            == "bytes"
                            and length
                            and length.isdigit()
                        ):
                            total = int(length)

                    first_chunk = b""

                    try:
                        first_chunk = next(
                            response.iter_raw(
                                chunk_size=4096
                            ),
                            b"",
                        )
                    except Exception:
                        pass

                    extension = sniff_extension(first_chunk)

                    upstream_cd = response.headers.get(
                        "Content-Disposition"
                    )

                    filename = (
                        filename_from_content_disposition(
                            upstream_cd
                        )
                    )

                    if filename:
                        if (
                            "." not in filename
                            and extension != "bin"
                        ):
                            filename = (
                                f"{filename}.{extension}"
                            )
                    else:
                        filename = (
                            f"AnkerGames-download."
                            f"{extension}"
                        )

                    filename = clean_filename(
                        filename,
                        f"AnkerGames-download."
                        f"{extension}",
                    )

                    safe_cd_name = filename.replace(
                        '"',
                        "_",
                    )

                    meta = {
                        "total": total,
                        "filename": filename,
                        "content_type": (
                            response.headers.get(
                                "Content-Type"
                            )
                            or "application/octet-stream"
                        ),
                        "content_disposition": (
                            f'attachment; '
                            f'filename="{safe_cd_name}"'
                        ),
                        "last_modified": (
                            response.headers.get(
                                "Last-Modified"
                            )
                        ),
                        "etag": response.headers.get(
                            "ETag"
                        ),
                        "final_url": str(response.url),
                    }

                    with _cache_lock:
                        _meta_cache[target] = (
                            time.monotonic(),
                            dict(meta),
                        )

                    return meta

            except (
                httpx.RequestError,
                RuntimeError,
            ) as exc:
                last_error = str(exc)

                if (
                    isinstance(exc, RuntimeError)
                    and "upstream HTTP 4"
                    in str(exc)
                ):
                    raise

                if attempt + 1 < MAX_RETRIES:
                    time.sleep(
                        min(
                            0.5 * (2 ** attempt),
                            5.0,
                        )
                    )

    raise RuntimeError(
        last_error
        or "could not probe upstream file"
    )


def parse_client_range(
    value: str | None,
    total: int,
):
    if not value:
        return 0, total - 1, False

    value = value.strip()

    m = re.fullmatch(
        r"bytes=(\d*)-(\d*)",
        value,
        re.I,
    )

    if not m:
        raise ValueError(
            "unsupported Range header"
        )

    left, right = m.group(1), m.group(2)

    if not left and not right:
        raise ValueError("invalid Range header")

    if left:
        start = int(left)
        end = int(right) if right else total - 1
    else:
        suffix = int(right)

        if suffix <= 0:
            raise ValueError(
                "invalid suffix range"
            )

        start = max(
            0,
            total - suffix,
        )
        end = total - 1

    if (
        start < 0
        or start >= total
        or end < start
    ):
        raise ValueError(
            "range outside file"
        )

    end = min(
        end,
        total - 1,
    )

    return start, end, True


def stream_exact(
    target: str,
    start: int,
    end: int,
    out,
) -> None:
    cursor = start
    continuations = 0
    no_progress = 0

    with make_client() as client:
        while cursor <= end:
            before = cursor
            opened = False

            for attempt in range(MAX_RETRIES):
                response_ctx = None

                try:
                    headers = {
                        "Range": (
                            f"bytes={cursor}-{end}"
                        ),
                        "Accept-Encoding": "identity",
                    }

                    response_ctx = client.stream(
                        "GET",
                        target,
                        headers=headers,
                    )

                    response = (
                        response_ctx.__enter__()
                    )

                    status = int(
                        response.status_code
                    )

                    if status in RETRYABLE:
                        response_ctx.__exit__(
                            None,
                            None,
                            None,
                        )
                        response_ctx = None

                        time.sleep(
                            retry_delay(
                                response,
                                attempt,
                            )
                        )
                        continue

                    response.raise_for_status()

                    content_range = parse_content_range(
                        response.headers.get(
                            "Content-Range"
                        )
                    )

                    if (
                        status != 206
                        or not content_range
                        or content_range[0]
                        != cursor
                    ):
                        if response_ctx is not None:
                            response_ctx.__exit__(
                                None,
                                None,
                                None,
                            )

                        raise RuntimeError(
                            "upstream did not honor "
                            f"byte range at {cursor} "
                            f"(HTTP {status})"
                        )

                    opened = True

                    try:
                        for chunk in response.iter_raw(
                            chunk_size=CHUNK
                        ):
                            if not chunk:
                                continue

                            remaining = (
                                end - cursor + 1
                            )

                            if remaining <= 0:
                                break

                            if len(chunk) > remaining:
                                chunk = chunk[
                                    :remaining
                                ]

                            out.write(chunk)
                            cursor += len(chunk)

                            if cursor > end:
                                break
                    finally:
                        response_ctx.__exit__(
                            None,
                            None,
                            None,
                        )

                    break

                except (
                    BrokenPipeError,
                    ConnectionResetError,
                ):
                    raise

                except httpx.RequestError:
                    if response_ctx is not None:
                        try:
                            response_ctx.__exit__(
                                *sys.exc_info()
                            )
                        except Exception:
                            pass

                    if attempt + 1 >= MAX_RETRIES:
                        raise

                    time.sleep(
                        min(
                            0.25 * (attempt + 1),
                            1.0,
                        )
                    )

            if not opened and cursor == before:
                raise RuntimeError(
                    "could not open upstream "
                    f"range at byte {cursor}"
                )

            if cursor == before:
                no_progress += 1

                if no_progress >= 4:
                    raise RuntimeError(
                        "upstream returned no "
                        f"data at byte {cursor}"
                    )
            else:
                no_progress = 0

            if cursor <= end:
                continuations += 1

                if continuations > 512:
                    raise RuntimeError(
                        "too many upstream "
                        "continuation requests"
                    )


def launch_postprocess(
    filename: str | None,
    total: int,
) -> None:
    if not filename:
        return

    filename = os.path.basename(
        str(filename)
    )

    if not filename.lower().endswith(
        (".zip", ".rar", ".7z")
    ):
        return

    try:
        log_handle = open(
            POSTPROCESS_LAUNCH_LOG,
            "ab",
            buffering=0,
        )

        try:
            subprocess.Popen(
                [
                    sys.executable,
                    POSTPROCESS_PATH,
                    "--filename",
                    filename,
                    "--size",
                    str(int(total)),
                ],
                stdin=subprocess.DEVNULL,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                close_fds=True,
            )
        finally:
            log_handle.close()

    except Exception as exc:
        sys.stderr.write(
            "[AnkerGamesJD] could not "
            "launch postprocessor: "
            f"{exc}\n"
        )


class BridgeHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = (
        "AnkerGamesJD-Bridge/2.0-full"
    )

    def setup(self):
        super().setup()
        self.server.connection_opened()

    def finish(self):
        try:
            super().finish()
        finally:
            self.server.connection_closed()

    def log_message(self, fmt, *args):
        sys.stderr.write(
            "[AnkerGamesJD] "
            + (fmt % args)
            + "\n"
        )

    def _send_text(
        self,
        status: int,
        text: str,
    ):
        data = text.encode(
            "utf-8",
            "replace",
        )

        self.send_response(status)
        self.send_header(
            "Content-Type",
            "text/plain; charset=utf-8",
        )
        self.send_header(
            "Content-Length",
            str(len(data)),
        )
        self.send_header(
            "Connection",
            "close",
        )
        self.end_headers()

        if self.command != "HEAD":
            self.wfile.write(data)

    def _send_common_headers(
        self,
        meta: dict,
    ):
        self.send_header(
            "Content-Type",
            meta.get("content_type")
            or "application/octet-stream",
        )

        self.send_header(
            "Accept-Ranges",
            "bytes",
        )

        if meta.get(
            "content_disposition"
        ):
            self.send_header(
                "Content-Disposition",
                meta[
                    "content_disposition"
                ],
            )

        if meta.get("last_modified"):
            self.send_header(
                "Last-Modified",
                meta["last_modified"],
            )

        if meta.get("etag"):
            self.send_header(
                "ETag",
                meta["etag"],
            )

        self.send_header(
            "Cache-Control",
            "no-store",
        )

    def do_HEAD(self):
        if self.path == "/health":
            self._send_text(
                200,
                "OK",
            )
            return

        target = get_target(self.path)

        if not target:
            self._send_text(
                404,
                "Invalid bridge URL",
            )
            return

        try:
            meta = probe_target(target)
            total = meta.get("total")

            if not total:
                self._send_text(
                    502,
                    "Upstream did not expose "
                    "the complete file size",
                )
                return

            self.send_response(200)
            self._send_common_headers(meta)
            self.send_header(
                "Content-Length",
                str(total),
            )
            self.end_headers()

        except Exception as exc:
            self._send_text(
                502,
                f"Bridge upstream error: {exc}",
            )

    def do_GET(self):
        if self.path == "/health":
            self._send_text(
                200,
                "OK",
            )
            return

        target = get_target(self.path)

        if not target:
            self._send_text(
                404,
                "Invalid bridge URL",
            )
            return

        try:
            meta = probe_target(target)
            total = meta.get("total")

            if not total:
                self._send_text(
                    502,
                    "Upstream did not expose "
                    "the complete file size",
                )
                return

            try:
                start, end, partial = (
                    parse_client_range(
                        self.headers.get("Range"),
                        int(total),
                    )
                )
            except ValueError:
                self.send_response(416)
                self.send_header(
                    "Content-Range",
                    f"bytes */{total}",
                )
                self.send_header(
                    "Content-Length",
                    "0",
                )
                self.end_headers()
                return

            self.send_response(
                206 if partial else 200
            )

            self._send_common_headers(meta)

            if partial:
                self.send_header(
                    "Content-Range",
                    (
                        f"bytes {start}-{end}/"
                        f"{total}"
                    ),
                )

            self.send_header(
                "Content-Length",
                str(end - start + 1),
            )

            self.end_headers()

            try:
                stream_exact(
                    target,
                    start,
                    end,
                    self.wfile,
                )

                # Start the helper whenever a successfully-served range reached
                # the real end of the archive. Duplicate starts are harmless:
                # postprocess_after_jd.py has an exact archive lock.
                if end == int(total) - 1:
                    launch_postprocess(
                        meta.get("filename"),
                        int(total),
                    )

            except (
                BrokenPipeError,
                ConnectionResetError,
            ):
                return

            except Exception as exc:
                self.log_message(
                    "stream failed after "
                    "response started: %s",
                    exc,
                )
                self.close_connection = True
                return

        except Exception as exc:
            try:
                self._send_text(
                    502,
                    f"Bridge upstream error: {exc}",
                )
            except Exception:
                pass


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(
        self,
        server_address,
        handler_class,
        inherited_socket=False,
    ):
        self._activity_lock = (
            threading.Lock()
        )
        self._active_connections = 0
        self._last_activity = (
            time.monotonic()
        )

        if inherited_socket:
            super().__init__(
                server_address,
                handler_class,
                bind_and_activate=False,
            )

            try:
                self.socket.close()
            except Exception:
                pass

            self.socket = socket.fromfd(
                3,
                socket.AF_INET,
                socket.SOCK_STREAM,
            )

            self.server_address = (
                self.socket.getsockname()
            )
            self.server_name = socket.getfqdn(
                self.server_address[0]
            )
            self.server_port = int(
                self.server_address[1]
            )

        else:
            super().__init__(
                server_address,
                handler_class,
            )

    def connection_opened(self):
        with self._activity_lock:
            self._active_connections += 1
            self._last_activity = (
                time.monotonic()
            )

    def connection_closed(self):
        with self._activity_lock:
            self._active_connections = max(
                0,
                self._active_connections - 1,
            )
            self._last_activity = (
                time.monotonic()
            )

    def idle_expired(self):
        with self._activity_lock:
            return (
                self._active_connections == 0
                and (
                    time.monotonic()
                    - self._last_activity
                )
                >= IDLE_SECONDS
            )


def socket_activated() -> bool:
    try:
        return (
            int(
                os.environ.get(
                    "LISTEN_PID",
                    "0",
                )
            )
            == os.getpid()
            and int(
                os.environ.get(
                    "LISTEN_FDS",
                    "0",
                )
            )
            >= 1
        )
    except ValueError:
        return False


def idle_watchdog(server: Server):
    while True:
        time.sleep(2.0)

        if server.idle_expired():
            print(
                "AnkerGames JDownloader "
                f"Bridge idle for "
                f"{IDLE_SECONDS:.0f}s; "
                "exiting until next request.",
                flush=True,
            )
            server.shutdown()
            return


if __name__ == "__main__":
    inherited = socket_activated()

    server = Server(
        ("127.0.0.1", PORT),
        BridgeHandler,
        inherited_socket=inherited,
    )

    mode = (
        "socket-activated"
        if inherited
        else "standalone"
    )

    print(
        "AnkerGames JDownloader Bridge "
        f"({mode}) listening on "
        f"http://127.0.0.1:{PORT}",
        flush=True,
    )

    watchdog = threading.Thread(
        target=idle_watchdog,
        args=(server,),
        daemon=True,
    )
    watchdog.start()

    try:
        server.serve_forever(
            poll_interval=0.5
        )
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
PYBRIDGE

chmod +x "$BRIDGE_PY"
"$VENV_DIR/bin/python" -m py_compile "$BRIDGE_PY"

# ------------------------------------------------------------
# systemd user socket activation
# ------------------------------------------------------------
cat > "$SERVICE_FILE" <<SERVICEEOF
[Unit]
Description=AnkerGames JDownloader on-demand compatibility bridge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$VENV_DIR/bin/python $BRIDGE_PY
Restart=no
SERVICEEOF

cat > "$SOCKET_FILE" <<SOCKETEOF
[Unit]
Description=AnkerGames JDownloader on-demand socket

[Socket]
ListenStream=127.0.0.1:$PORT
NoDelay=true
Service=$SERVICE_NAME

[Install]
WantedBy=sockets.target
SOCKETEOF

systemctl --user daemon-reload
systemctl --user enable --now "$SOCKET_NAME"

# ------------------------------------------------------------
# JDownloader configuration
# ------------------------------------------------------------
echo "Configuring JDownloader automatically..."

LINK_RULES="$LINK_RULES" \
LINK_MAIN="$LINK_MAIN" \
PACK_RULES="$PACK_RULES" \
EVENT_SCRIPTS="$EVENT_SCRIPTS" \
STATE_FILE="$STATE_FILE" \
python3 <<'PYCFG'
import json
import os
import time
from pathlib import Path

link_rules_path = Path(os.environ["LINK_RULES"])
link_main_path = Path(os.environ["LINK_MAIN"])
pack_rules_path = Path(os.environ["PACK_RULES"])
event_scripts_path = Path(os.environ["EVENT_SCRIPTS"])
state_path = Path(os.environ["STATE_FILE"])

rewrite_name = "AnkerGames to JD Bridge"
direct_name = "AnkerGames JD Bridge DirectHTTP"

rewrite_pattern = (
    r"https://(?<host>tunnel[0-9]+\.dlproxy\.uk)"
    r"/download/(?<token>[A-Za-z0-9_-]+)"
    r"\?sig=(?<sig>[A-Za-z0-9_-]+)"
)

direct_pattern = (
    r"http://127\.0\.0\.1:17892/"
    r"AnkerGames-download\.bin\?.+"
)

rewrite_target = (
    "http://127.0.0.1:17892/"
    "AnkerGames-download.bin"
    "?host=${host}&token=${token}&sig=${sig}"
)

now = int(time.time() * 1000)

# ---- LinkCrawler rules ----
link_rules = []

if link_rules_path.exists():
    try:
        loaded = json.loads(
            link_rules_path.read_text(
                encoding="utf-8"
            )
        )
        if isinstance(loaded, list):
            link_rules = loaded
    except Exception:
        pass

cleaned_link_rules = []

for rule in link_rules:
    if not isinstance(rule, dict):
        cleaned_link_rules.append(rule)
        continue

    name = str(rule.get("name") or "")
    pattern = str(rule.get("pattern") or "")

    if name in {
        rewrite_name,
        direct_name,
    }:
        continue

    if "AnkerGames" in name and (
        "dlproxy" in pattern
        or "127\\.0\\.0\\.1:17892"
        in pattern
    ):
        continue

    cleaned_link_rules.append(rule)

wanted_rules = [
    {
        "enabled": True,
        "logging": True,
        "maxDecryptDepth": 1,
        "name": rewrite_name,
        "pattern": rewrite_pattern,
        "rule": "REWRITE",
        "rewriteReplaceWith": rewrite_target,
        "id": now,
    },
    {
        "enabled": True,
        "logging": True,
        "maxDecryptDepth": 1,
        "name": direct_name,
        "pattern": direct_pattern,
        "rule": "DIRECTHTTP",
        "id": now + 1,
    },
]

link_rules_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

tmp = link_rules_path.with_suffix(
    link_rules_path.suffix + ".tmp"
)

tmp.write_text(
    json.dumps(
        cleaned_link_rules + wanted_rules,
        ensure_ascii=False,
        indent=1,
    ) + "\n",
    encoding="utf-8",
)

os.replace(
    tmp,
    link_rules_path,
)

# ---- Ensure LinkCrawler rules are enabled ----
link_main = {}

if link_main_path.exists():
    try:
        loaded = json.loads(
            link_main_path.read_text(
                encoding="utf-8"
            )
        )
        if isinstance(loaded, dict):
            link_main = loaded
    except Exception:
        pass

found = False

for key in list(link_main):
    normalized = "".join(
        c for c in str(key).lower()
        if c.isalnum()
    )

    if normalized == "linkcrawlerrulesenabled":
        link_main[key] = True
        found = True
        break

if not found:
    link_main[
        "linkcrawlerrulesenabled"
    ] = True

tmp = link_main_path.with_suffix(
    link_main_path.suffix + ".tmp"
)

tmp.write_text(
    json.dumps(
        link_main,
        ensure_ascii=False,
        separators=(",", ":"),
    ) + "\n",
    encoding="utf-8",
)

os.replace(
    tmp,
    link_main_path,
)

# ---- Disable JDownloader's built-in package-name subfolder rule ----
state = {
    "subfolder_rule_found": False,
    "subfolder_rule_original_enabled": None,
}

pack_rules = []

if pack_rules_path.exists():
    try:
        loaded = json.loads(
            pack_rules_path.read_text(
                encoding="utf-8"
            )
        )
        if isinstance(loaded, list):
            pack_rules = loaded
    except Exception:
        pass

# Remove our old custom Packagizer experiment if present.
pack_rules = [
    rule for rule in pack_rules
    if not (
        isinstance(rule, dict)
        and str(rule.get("name") or "")
        == "AnkerGames Direct Downloads + Extract"
    )
]

for rule in pack_rules:
    if not isinstance(rule, dict):
        continue

    rid = str(rule.get("id") or "")
    name = str(rule.get("name") or "")

    if (
        rid == "SubFolderByPackageRule"
        or name
        == "Create Subfolder by Packagename"
    ):
        state["subfolder_rule_found"] = True
        state[
            "subfolder_rule_original_enabled"
        ] = bool(
            rule.get("enabled", True)
        )
        rule["enabled"] = False

if pack_rules_path.exists() or pack_rules:
    tmp = pack_rules_path.with_suffix(
        pack_rules_path.suffix + ".tmp"
    )

    tmp.write_text(
        json.dumps(
            pack_rules,
            ensure_ascii=False,
            separators=(",", ":"),
        ) + "\n",
        encoding="utf-8",
    )

    os.replace(
        tmp,
        pack_rules_path,
    )

# ---- Remove previous experimental AnkerGames Event Scripter entries ----
if event_scripts_path.exists():
    try:
        events = json.loads(
            event_scripts_path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        events = []

    if isinstance(events, list):
        old_names = {
            "AnkerGames Download Folder",
            "AnkerGames Force Extract",
            "AnkerGames Actual Package Folder",
            "AnkerGames Archive Fallback",
        }

        events = [
            entry for entry in events
            if not (
                isinstance(entry, dict)
                and str(entry.get("name") or "")
                in old_names
            )
        ]

        tmp = event_scripts_path.with_suffix(
            event_scripts_path.suffix
            + ".tmp"
        )

        tmp.write_text(
            json.dumps(
                events,
                ensure_ascii=False,
                indent=1,
            ) + "\n",
            encoding="utf-8",
        )

        os.replace(
            tmp,
            event_scripts_path,
        )

state_path.write_text(
    json.dumps(
        state,
        indent=2,
    ) + "\n",
    encoding="utf-8",
)

print("JDownloader configuration: OK")
PYCFG

# ------------------------------------------------------------
# Test socket activation
# ------------------------------------------------------------
echo
echo "Testing on-demand bridge..."

if command -v curl >/dev/null 2>&1; then
    if curl -fsS \
        --max-time 5 \
        "http://127.0.0.1:${PORT}/health" \
        >/dev/null
    then
        echo "Bridge health check: OK"
    else
        echo "WARNING: Bridge health check did not answer."
        echo "Check:"
        echo "  systemctl --user status $SOCKET_NAME"
        echo "  journalctl --user -u $SERVICE_NAME -n 50 --no-pager"
    fi
else
    echo "curl is not installed; skipped health check."
fi

echo
echo "============================================================"
echo " FULL SETUP COMPLETE"
echo "============================================================"
echo
echo "Start JDownloader 2 and add a FRESH AnkerGames link."
echo
echo "Expected behavior:"
echo
echo "  1. Archive downloads to:"
echo "       $HOME/Downloads/Game-AnkerGames.zip"
echo
echo "  2. After completion, a folder with the SAME archive name is created:"
echo "       $HOME/Downloads/Game-AnkerGames/"
echo
echo "  3. The archive's original top-level layout is preserved inside it."
echo
echo "     Example:"
echo "       Game-AnkerGames/"
echo "         Read Me.txt"
echo "         Run Me!.bat"
echo "         Picture.png"
echo "         Game/"
echo
echo "  4. Nothing is flattened into the actual game folder."
echo
echo "  5. Archive is deleted only after successful extraction."
echo
echo "  6. The Python bridge exits after 45 seconds of inactivity."
echo
echo "Logs if anything fails:"
echo "  $APP_DIR/postprocess.log"
echo "  journalctl --user -u $SERVICE_NAME -n 100 --no-pager"
echo
echo "Uninstall everything from this setup:"
echo "  bash \"$0\" --uninstall"
echo
