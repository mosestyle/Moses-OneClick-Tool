#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$HOME/.local/share/ankergames-jd-bridge"
STATE_FILE="$APP_DIR/full-setup-state.json"

SYSTEMD_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.service"
SOCKET_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.socket"
SERVICE_NAME="ankergames-jd-bridge.service"
SOCKET_NAME="ankergames-jd-bridge.socket"

JD_LINK_RULES_NAME="jd.controlling.linkcrawler.LinkCrawlerConfig.linkcrawlerrules.json"
JD_PACK_RULES_NAME="org.jdownloader.controlling.packagizer.PackagizerSettings.rulelist.json"
JD_EVENT_SCRIPTS_NAME="org.jdownloader.extensions.eventscripter.EventScripterExtension.scripts.json"

echo
echo "============================================================"
echo " AnkerGames JDownloader 2 - Full Uninstaller"
echo "============================================================"
echo

jdownloader_is_running() {
    pgrep -af \
        'java.*JDownloader|JDownloader\.jar|org\.jdownloader\.update|org\.jdownloader\.launcher' \
        >/dev/null 2>&1
}

find_jd_cfg_dir() {
    local f=""

    for filename in \
        "$JD_LINK_RULES_NAME" \
        "$JD_PACK_RULES_NAME" \
        "$JD_EVENT_SCRIPTS_NAME"
    do
        while IFS= read -r f; do
            [[ -n "$f" ]] || continue
            dirname "$f"
            return 0
        done < <(
            find "$HOME" -maxdepth 10 -type f -name "$filename" \
                -printf '%T@ %p\n' 2>/dev/null | sort -nr | cut -d' ' -f2-
        )
    done

    local d
    for d in \
        "$HOME/.var/app/org.jdownloader.JDownloader/data/jdownloader/cfg" \
        "$HOME/.var/app/org.jdownloader.JDownloader/data/JDownloader/cfg" \
        "$HOME/.jd/cfg" \
        "$HOME/JDownloader/cfg" \
        "$HOME/JDownloader2/cfg" \
        "$HOME/.local/share/JDownloader/cfg"
    do
        if [[ -d "$d" ]]; then
            printf '%s\n' "$d"
            return 0
        fi
    done

    return 1
}

restore_packagizer_state() {
    local cfg_dir="$1"
    local pack_rules="$cfg_dir/$JD_PACK_RULES_NAME"

    [[ -f "$STATE_FILE" && -f "$pack_rules" ]] || return 0

    STATE_FILE="$STATE_FILE" PACK_RULES="$pack_rules" python3 <<'PY'
import json
import os
from pathlib import Path

state_path = Path(os.environ["STATE_FILE"])
pack_path = Path(os.environ["PACK_RULES"])

try:
    state = json.loads(state_path.read_text(encoding="utf-8"))
    rules = json.loads(pack_path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(rules, list):
    raise SystemExit(0)

if state.get("subfolder_rule_found"):
    old_enabled = bool(state.get("subfolder_rule_original_enabled"))
    changed = False

    for rule in rules:
        if not isinstance(rule, dict):
            continue

        rid = str(rule.get("id") or "")
        name = str(rule.get("name") or "")

        if rid == "SubFolderByPackageRule" or name == "Create Subfolder by Packagename":
            rule["enabled"] = old_enabled
            changed = True

    if changed:
        tmp = pack_path.with_suffix(pack_path.suffix + ".tmp")
        tmp.write_text(
            json.dumps(rules, ensure_ascii=False, separators=(",", ":")) + "\n",
            encoding="utf-8",
        )
        os.replace(tmp, pack_path)
        print("Restored JDownloader's original package-subfolder setting.")
PY
}

remove_our_jd_rules() {
    local cfg_dir="$1"
    local link_rules="$cfg_dir/$JD_LINK_RULES_NAME"
    local event_scripts="$cfg_dir/$JD_EVENT_SCRIPTS_NAME"

    if [[ -f "$link_rules" ]]; then
        LINK_RULES="$link_rules" python3 <<'PY'
import json
import os
from pathlib import Path

p = Path(os.environ["LINK_RULES"])

try:
    data = json.loads(p.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(data, list):
    raise SystemExit(0)

names = {
    "AnkerGames to JD Bridge",
    "AnkerGames to JD Bridge - Current Format",
    "AnkerGames to JD Bridge - New Format",
    "AnkerGames to JD Bridge - Legacy Format",
    "AnkerGames JD Bridge DirectHTTP",
}

cleaned = []

for item in data:
    if isinstance(item, dict):
        name = str(item.get("name") or "")
        pattern = str(item.get("pattern") or "")

        if name in names:
            continue

        if "AnkerGames" in name and (
            "dlproxy" in pattern
            or "127\\.0\\.0\\.1:17892" in pattern
        ):
            continue

    cleaned.append(item)

tmp = p.with_suffix(p.suffix + ".tmp")
tmp.write_text(
    json.dumps(cleaned, ensure_ascii=False, indent=1) + "\n",
    encoding="utf-8",
)
os.replace(tmp, p)

print("Removed AnkerGames LinkCrawler rules.")
PY
    fi

    if [[ -f "$event_scripts" ]]; then
        EVENT_SCRIPTS="$event_scripts" python3 <<'PY'
import json
import os
from pathlib import Path

p = Path(os.environ["EVENT_SCRIPTS"])

try:
    data = json.loads(p.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(data, list):
    raise SystemExit(0)

names = {
    "AnkerGames Download Folder",
    "AnkerGames Force Extract",
    "AnkerGames Actual Package Folder",
    "AnkerGames Archive Fallback",
}

cleaned = [
    item for item in data
    if not (
        isinstance(item, dict)
        and str(item.get("name") or "") in names
    )
]

tmp = p.with_suffix(p.suffix + ".tmp")
tmp.write_text(
    json.dumps(cleaned, ensure_ascii=False, indent=1) + "\n",
    encoding="utf-8",
)
os.replace(tmp, p)

print("Removed old AnkerGames Event Scripter entries.")
PY
    fi
}

if jdownloader_is_running; then
    echo "JDownloader 2 is still running."
    echo "Close JDownloader completely, then run this uninstaller again."
    exit 1
fi

CFG_DIR="$(find_jd_cfg_dir || true)"

if [[ -n "$CFG_DIR" ]]; then
    restore_packagizer_state "$CFG_DIR" || true
    remove_our_jd_rules "$CFG_DIR" || true
fi

systemctl --user disable --now "$SOCKET_NAME" >/dev/null 2>&1 || true
systemctl --user disable --now "$SERVICE_NAME" >/dev/null 2>&1 || true

rm -f "$SOCKET_FILE" "$SERVICE_FILE"

systemctl --user daemon-reload >/dev/null 2>&1 || true
systemctl --user reset-failed "$SERVICE_NAME" >/dev/null 2>&1 || true

rm -rf "$APP_DIR"

echo
echo "AnkerGames JDownloader integration has been completely removed."
echo "Unrelated JDownloader settings and rules were left untouched."
echo
