AnkerGames JDownloader Full Package v1.4

FIX IN v1.4
SteamOS is using Python 3.14. backports.zstd intentionally supports only
Python versions below 3.14 because Python 3.14 includes native Zstandard support.

v1.4 now installs dependencies conditionally:

  Python 3.10-3.13:
    installs backports.zstd

  Python 3.14+:
    does NOT install backports.zstd
    uses built-in zipfile + compression.zstd instead

This fixes:
  ERROR: Could not find a version that satisfies the requirement backports.zstd>=1.0.0

The package still includes all previous functionality:
  * current ag1.<payload>.<signature> AnkerGames links
  * legacy ?sig= links
  * on-demand bridge
  * automatic extraction
  * archive-name container folder
  * original archive layout preserved
  * archive deletion only after successful extraction
  * standalone full uninstaller

INSTALL
1. Close JDownloader completely.
2. Run:
     bash ~/Downloads/AnkerGames_JDownloader_v1.4_Full_Setup.sh
3. Do not close the terminal until you see:
     FULL SETUP COMPLETE
4. Start JDownloader and paste a fresh AnkerGames link.

UNINSTALL
1. Close JDownloader completely.
2. Run:
     bash ~/Downloads/AnkerGames_JDownloader_v1.4_Full_Uninstaller.sh
