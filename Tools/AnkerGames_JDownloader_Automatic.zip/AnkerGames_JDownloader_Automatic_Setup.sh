#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$HOME/.local/share/ankergames-jd-bridge"
VENV_DIR="$APP_DIR/.venv"
BRIDGE_PY="$APP_DIR/bridge.py"
SYSTEMD_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.service"
SOCKET_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.socket"
PORT="17892"


# ---------------------------------------------------------------------------
# JDownloader LinkCrawler rule integration
# ---------------------------------------------------------------------------

JD_RULES_FILENAME="jd.controlling.linkcrawler.LinkCrawlerConfig.linkcrawlerrules.json"
JD_MAIN_FILENAME="jd.controlling.linkcrawler.LinkCrawlerConfig.json"

find_jd_cfg_dir() {
  local candidate=""

  # First prefer an existing LinkCrawler rules file.
  while IFS= read -r candidate; do
    [[ -n "$candidate" ]] || continue
    dirname "$candidate"
    return 0
  done < <(
    find "$HOME" -maxdepth 8 -type f -name "$JD_RULES_FILENAME" \
      -printf '%T@ %p\n' 2>/dev/null | sort -nr | cut -d' ' -f2-
  )

  # Then look for the main LinkCrawler config.
  while IFS= read -r candidate; do
    [[ -n "$candidate" ]] || continue
    dirname "$candidate"
    return 0
  done < <(
    find "$HOME" -maxdepth 8 -type f -name "$JD_MAIN_FILENAME" \
      -printf '%T@ %p\n' 2>/dev/null | sort -nr | cut -d' ' -f2-
  )

  # Common Linux / SteamOS locations if JDownloader has not created the
  # LinkCrawler-specific files yet.
  local dir
  for dir in \
    "$HOME/.jd/cfg" \
    "$HOME/JDownloader/cfg" \
    "$HOME/JDownloader2/cfg" \
    "$HOME/.local/share/JDownloader/cfg" \
    "$HOME/.var/app/org.jdownloader.JDownloader/data/JDownloader/cfg" \
    "$HOME/.var/app/org.jdownloader.JDownloader/data/jdownloader/cfg" \
    "$HOME/.var/app/org.jdownloader.JDownloader/config/JDownloader/cfg" \
    "$HOME/.var/app/org.jdownloader.JDownloader/config/jdownloader/cfg"
  do
    if [[ -d "$dir" ]]; then
      printf '%s\n' "$dir"
      return 0
    fi
  done

  return 1
}

configure_jdownloader_rules() {
  local cfg_dir rules_file main_file backup_dir
  if ! cfg_dir="$(find_jd_cfg_dir)"; then
    echo
    echo "WARNING: JDownloader's cfg folder could not be found automatically."
    echo "The on-demand bridge is installed, but the two LinkCrawler rules were not added."
    echo "Open JDownloader once, close it, then run this installer again."
    return 0
  fi

  rules_file="$cfg_dir/$JD_RULES_FILENAME"
  main_file="$cfg_dir/$JD_MAIN_FILENAME"
  backup_dir="$APP_DIR/jdownloader-config-backup"
  mkdir -p "$backup_dir"

  [[ -f "$rules_file" ]] && cp -a "$rules_file" "$backup_dir/$JD_RULES_FILENAME.before-ankergames" || true
  [[ -f "$main_file" ]] && cp -a "$main_file" "$backup_dir/$JD_MAIN_FILENAME.before-ankergames" || true

  JD_RULES_FILE="$rules_file" JD_MAIN_FILE="$main_file" python3 <<'PYJD'
import json
import os
import time
from pathlib import Path

rules_path = Path(os.environ["JD_RULES_FILE"])
main_path = Path(os.environ["JD_MAIN_FILE"])

RULE_NAMES = {
    "AnkerGames to JD Bridge",
    "AnkerGames JD Bridge DirectHTTP",
}

rewrite_pattern = r"https://(?<host>tunnel[0-9]+\.dlproxy\.uk)/download/(?<token>[A-Za-z0-9_-]+)\?sig=(?<sig>[A-Za-z0-9_-]+)"
direct_pattern = r"http://127\.0\.0\.1:17892/AnkerGames-download\.bin\?.+"

now = int(time.time() * 1000)

wanted = [
    {
        "cookies": None,
        "deepPattern": None,
        "formPattern": None,
        "headers": None,
        "id": now,
        "maxDecryptDepth": 1,
        "name": "AnkerGames to JD Bridge",
        "packageNamePattern": None,
        "passwordPattern": None,
        "pattern": rewrite_pattern,
        "propertyPatterns": None,
        "rewriteReplaceWith": "http://127.0.0.1:17892/AnkerGames-download.bin?host=${host}&token=${token}&sig=${sig}",
        "rule": "REWRITE",
        "enabled": True,
        "logging": True,
        "updateCookies": False,
    },
    {
        "cookies": None,
        "deepPattern": None,
        "formPattern": None,
        "headers": None,
        "id": now + 1,
        "maxDecryptDepth": 1,
        "name": "AnkerGames JD Bridge DirectHTTP",
        "packageNamePattern": None,
        "passwordPattern": None,
        "pattern": direct_pattern,
        "propertyPatterns": None,
        "rewriteReplaceWith": None,
        "rule": "DIRECTHTTP",
        "enabled": True,
        "logging": True,
        "updateCookies": False,
    },
]

existing = []
if rules_path.exists():
    try:
        loaded = json.loads(rules_path.read_text(encoding="utf-8"))
        if isinstance(loaded, list):
            existing = loaded
    except Exception:
        pass

# Preserve every unrelated rule. Replace any older AnkerGames variants.
kept = []
for rule in existing:
    if not isinstance(rule, dict):
        kept.append(rule)
        continue
    name = str(rule.get("name") or "")
    pattern = str(rule.get("pattern") or "")
    if name in RULE_NAMES:
        continue
    if "dlproxy" in pattern and "AnkerGames" in name:
        continue
    if "127\\.0\\.0\\.1:17892" in pattern and "AnkerGames" in name:
        continue
    kept.append(rule)

rules_path.parent.mkdir(parents=True, exist_ok=True)
tmp = rules_path.with_suffix(rules_path.suffix + ".tmp")
tmp.write_text(json.dumps(kept + wanted, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
os.replace(tmp, rules_path)

# Enable the LinkCrawler Rules checkbox in the main config while preserving
# every other JDownloader setting.
data = {}
if main_path.exists():
    try:
        loaded = json.loads(main_path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict):
            data = loaded
    except Exception:
        data = {}

normalized_target = "linkcrawlerrulesenabled"
found = False
for key in list(data):
    normalized = "".join(ch for ch in str(key).lower() if ch.isalnum())
    if normalized == normalized_target:
        data[key] = True
        found = True
        break
if not found:
    data["linkcrawlerrulesenabled"] = True

main_path.parent.mkdir(parents=True, exist_ok=True)
tmp_main = main_path.with_suffix(main_path.suffix + ".tmp")
tmp_main.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")
os.replace(tmp_main, main_path)

print(f"JDownloader rules installed in: {cfg_dir if False else rules_path.parent}")
PYJD

  echo "JDownloader LinkCrawler rules installed automatically."
  echo "Existing unrelated LinkCrawler rules were preserved."
}

remove_jdownloader_rules() {
  local cfg_dir rules_file
  if ! cfg_dir="$(find_jd_cfg_dir)"; then
    return 0
  fi
  rules_file="$cfg_dir/$JD_RULES_FILENAME"
  [[ -f "$rules_file" ]] || return 0

  JD_RULES_FILE="$rules_file" python3 <<'PYJDREMOVE'
import json
import os
from pathlib import Path

path = Path(os.environ["JD_RULES_FILE"])
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(data, list):
    raise SystemExit(0)

names = {
    "AnkerGames to JD Bridge",
    "AnkerGames JD Bridge DirectHTTP",
}

cleaned = []
changed = False
for rule in data:
    if isinstance(rule, dict):
        name = str(rule.get("name") or "")
        pattern = str(rule.get("pattern") or "")
        if name in names or ("AnkerGames" in name and ("dlproxy" in pattern or "127\\.0\\.0\\.1:17892" in pattern)):
            changed = True
            continue
    cleaned.append(rule)

if changed:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(cleaned, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    print("Removed the AnkerGames LinkCrawler rules from JDownloader.")
PYJDREMOVE
}

uninstall_all() {
  systemctl --user disable --now ankergames-jd-bridge.socket >/dev/null 2>&1 || true
  systemctl --user disable --now ankergames-jd-bridge.service >/dev/null 2>&1 || true
  rm -f "$SOCKET_FILE" "$SERVICE_FILE"
  systemctl --user daemon-reload >/dev/null 2>&1 || true
  systemctl --user reset-failed ankergames-jd-bridge.service >/dev/null 2>&1 || true
  remove_jdownloader_rules || true
  rm -rf "$APP_DIR"
  echo "AnkerGames JDownloader On-Demand Bridge and its JDownloader rules were removed."
}

if [[ "${1:-}" == "--uninstall" ]]; then
  uninstall_all
  exit 0
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 was not found."
  exit 1
fi
if ! python3 -m venv --help >/dev/null 2>&1; then
  echo "ERROR: Python venv support was not found."
  exit 1
fi

mkdir -p "$APP_DIR" "$SYSTEMD_DIR"

# Migrate cleanly from the old always-running bridge, if installed.
systemctl --user disable --now ankergames-jd-bridge.service >/dev/null 2>&1 || true
systemctl --user disable --now ankergames-jd-bridge.socket >/dev/null 2>&1 || true

cat > "$BRIDGE_PY" <<'PYEOF'
from __future__ import annotations

import os
import re
import sys
import time
import threading
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs

import httpx

HOST_RE = re.compile(r"^tunnel\d+\.dlproxy\.uk$", re.I)
PORT = 17892
MIB = 1024 * 1024
RETRYABLE = {408, 425, 429, 500, 502, 503, 504, 520, 521, 522, 523, 524}
MAX_RETRIES = 6
CHUNK = 1024 * 1024
IDLE_SECONDS = 45.0

BASE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/128.0 Safari/537.36"
    ),
    "Accept": "*/*",
    "Accept-Encoding": "identity",
}

_cache_lock = threading.Lock()
_meta_cache: dict[str, tuple[float, dict]] = {}
CACHE_SECONDS = 15 * 60


def parse_content_range(value: str | None):
    if not value:
        return None
    m = re.match(r"^\s*bytes\s+(\d+)-(\d+)/(\d+|\*)\s*$", value, re.I)
    if not m:
        return None
    start = int(m.group(1))
    end = int(m.group(2))
    total = None if m.group(3) == "*" else int(m.group(3))
    if end < start:
        return None
    return start, end, total


def sniff_extension(data: bytes) -> str:
    head = bytes(data or b"")
    if head.startswith((b"Rar!\x1a\x07\x01\x00", b"Rar!\x1a\x07\x00")):
        return "rar"
    if head.startswith((b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")):
        return "zip"
    if head.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "7z"
    return "bin"


def make_client():
    timeout = httpx.Timeout(connect=30.0, read=None, write=30.0, pool=30.0)
    return httpx.Client(
        follow_redirects=True,
        timeout=timeout,
        headers=BASE_HEADERS,
        http2=False,
    )


def retry_delay(response: httpx.Response | None, attempt: int) -> float:
    if response is not None:
        try:
            ra = float(response.headers.get("Retry-After", ""))
            if ra >= 0:
                return min(max(ra, 0.25), 12.0)
        except Exception:
            pass
    return min(0.5 * (2 ** max(0, attempt)), 5.0)


def get_target(path: str) -> str | None:
    parsed = urlsplit(path)

    # Preferred JDownloader rewrite form: a short/safe local filename and the
    # original signed pieces carried as query parameters.
    if parsed.path == "/AnkerGames-download.bin":
        qs = parse_qs(parsed.query, keep_blank_values=True)
        host = (qs.get("host") or [""])[0]
        token = (qs.get("token") or [""])[0]
        sig = (qs.get("sig") or [""])[0]
        if not HOST_RE.fullmatch(host) or not token or not sig:
            return None
        if not re.fullmatch(r"[A-Za-z0-9_-]+", token):
            return None
        if not re.fullmatch(r"[A-Za-z0-9_-]+", sig):
            return None
        return f"https://{host}/download/{token}?sig={sig}"

    # Backward-compatible path form for manual tests.
    clean_path = parsed.path.lstrip("/")
    if "/" not in clean_path:
        return None
    host, rest = clean_path.split("/", 1)
    if not HOST_RE.fullmatch(host):
        return None
    if not rest.startswith("download/"):
        return None
    target = f"https://{host}/{rest}"
    if parsed.query:
        target += "?" + parsed.query
    return target


def probe_target(target: str) -> dict:
    now = time.monotonic()
    with _cache_lock:
        cached = _meta_cache.get(target)
        if cached and now - cached[0] < CACHE_SECONDS:
            return dict(cached[1])

    last_error = None
    with make_client() as client:
        for attempt in range(MAX_RETRIES):
            try:
                headers = {
                    "Range": f"bytes=0-{MIB - 1}",
                    "Accept-Encoding": "identity",
                }
                with client.stream("GET", target, headers=headers) as response:
                    status = int(response.status_code)
                    if status in RETRYABLE:
                        last_error = f"HTTP {status} {response.reason_phrase}"
                        time.sleep(retry_delay(response, attempt))
                        continue
                    if status >= 400:
                        body = b""
                        try:
                            body = next(response.iter_raw(chunk_size=4096), b"")[:512]
                        except Exception:
                            pass
                        detail = body.decode("utf-8", "replace").replace("\n", " ")[:300]
                        raise RuntimeError(f"upstream HTTP {status}: {detail}")

                    total = None
                    cr = parse_content_range(response.headers.get("Content-Range"))
                    if cr and cr[2]:
                        total = cr[2]
                    elif status == 200:
                        length = response.headers.get("Content-Length")
                        if (
                            response.headers.get("Accept-Ranges", "").lower() == "bytes"
                            and length
                            and length.isdigit()
                        ):
                            total = int(length)

                    first_chunk = b""
                    try:
                        first_chunk = next(response.iter_raw(chunk_size=4096), b"")
                    except Exception:
                        pass
                    upstream_cd = response.headers.get("Content-Disposition")
                    if not upstream_cd:
                        ext = sniff_extension(first_chunk)
                        upstream_cd = f'attachment; filename="AnkerGames-download.{ext}"'

                    meta = {
                        "total": total,
                        "content_type": response.headers.get("Content-Type") or "application/octet-stream",
                        "content_disposition": upstream_cd,
                        "last_modified": response.headers.get("Last-Modified"),
                        "etag": response.headers.get("ETag"),
                        "final_url": str(response.url),
                    }
                    with _cache_lock:
                        _meta_cache[target] = (time.monotonic(), dict(meta))
                    return meta
            except (httpx.RequestError, RuntimeError) as exc:
                last_error = str(exc)
                if isinstance(exc, RuntimeError) and "upstream HTTP 4" in str(exc):
                    raise
                if attempt + 1 < MAX_RETRIES:
                    time.sleep(min(0.5 * (2 ** attempt), 5.0))

    raise RuntimeError(last_error or "could not probe upstream file")


def parse_client_range(value: str | None, total: int):
    if not value:
        return 0, total - 1, False
    value = value.strip()
    m = re.fullmatch(r"bytes=(\d*)-(\d*)", value, re.I)
    if not m:
        raise ValueError("unsupported Range header")
    left, right = m.group(1), m.group(2)
    if not left and not right:
        raise ValueError("invalid Range header")
    if left:
        start = int(left)
        end = int(right) if right else total - 1
    else:
        suffix = int(right)
        if suffix <= 0:
            raise ValueError("invalid suffix range")
        start = max(0, total - suffix)
        end = total - 1
    if start < 0 or start >= total or end < start:
        raise ValueError("range outside file")
    end = min(end, total - 1)
    return start, end, True


def stream_exact(target: str, start: int, end: int, out) -> None:
    cursor = start
    continuations = 0
    no_progress = 0
    with make_client() as client:
        while cursor <= end:
            before = cursor
            opened = False
            for attempt in range(MAX_RETRIES):
                response_ctx = None
                try:
                    headers = {
                        "Range": f"bytes={cursor}-{end}",
                        "Accept-Encoding": "identity",
                    }
                    response_ctx = client.stream("GET", target, headers=headers)
                    response = response_ctx.__enter__()
                    status = int(response.status_code)
                    if status in RETRYABLE:
                        response_ctx.__exit__(None, None, None)
                        response_ctx = None
                        time.sleep(retry_delay(response, attempt))
                        continue
                    response.raise_for_status()
                    cr = parse_content_range(response.headers.get("Content-Range"))
                    if status != 206 or not cr or cr[0] != cursor:
                        if response_ctx is not None:
                            response_ctx.__exit__(None, None, None)
                        raise RuntimeError(
                            f"upstream did not honor byte range at {cursor} (HTTP {status})"
                        )
                    opened = True
                    try:
                        for chunk in response.iter_raw(chunk_size=CHUNK):
                            if not chunk:
                                continue
                            remaining = end - cursor + 1
                            if remaining <= 0:
                                break
                            if len(chunk) > remaining:
                                chunk = chunk[:remaining]
                            out.write(chunk)
                            cursor += len(chunk)
                            if cursor > end:
                                break
                    finally:
                        response_ctx.__exit__(None, None, None)
                    break
                except (BrokenPipeError, ConnectionResetError):
                    raise
                except httpx.RequestError:
                    if response_ctx is not None:
                        try:
                            response_ctx.__exit__(*sys.exc_info())
                        except Exception:
                            pass
                    if attempt + 1 >= MAX_RETRIES:
                        raise
                    time.sleep(min(0.25 * (attempt + 1), 1.0))
            if not opened and cursor == before:
                raise RuntimeError(f"could not open upstream range at byte {cursor}")
            if cursor == before:
                no_progress += 1
                if no_progress >= 4:
                    raise RuntimeError(f"upstream returned no data at byte {cursor}")
            else:
                no_progress = 0
            if cursor <= end:
                continuations += 1
                if continuations > 512:
                    raise RuntimeError("too many upstream continuation requests")


class BridgeHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "AnkerGamesJD-Bridge/1.1-ondemand"

    def setup(self):
        super().setup()
        self.server.connection_opened()

    def finish(self):
        try:
            super().finish()
        finally:
            self.server.connection_closed()

    def log_message(self, fmt, *args):
        sys.stderr.write("[AnkerGamesJD] " + (fmt % args) + "\n")

    def _send_text(self, status: int, text: str):
        data = text.encode("utf-8", "replace")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Connection", "close")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def _send_common_headers(self, meta: dict):
        self.send_header("Content-Type", meta.get("content_type") or "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        if meta.get("content_disposition"):
            self.send_header("Content-Disposition", meta["content_disposition"])
        if meta.get("last_modified"):
            self.send_header("Last-Modified", meta["last_modified"])
        if meta.get("etag"):
            self.send_header("ETag", meta["etag"])
        self.send_header("Cache-Control", "no-store")

    def do_HEAD(self):
        if self.path == "/health":
            self._send_text(200, "OK")
            return
        target = get_target(self.path)
        if not target:
            self._send_text(404, "Invalid bridge URL")
            return
        try:
            meta = probe_target(target)
            total = meta.get("total")
            if not total:
                self._send_text(502, "Upstream did not expose the complete file size")
                return
            self.send_response(200)
            self._send_common_headers(meta)
            self.send_header("Content-Length", str(total))
            self.end_headers()
        except Exception as exc:
            self._send_text(502, f"Bridge upstream error: {exc}")

    def do_GET(self):
        if self.path == "/health":
            self._send_text(200, "OK")
            return
        target = get_target(self.path)
        if not target:
            self._send_text(404, "Invalid bridge URL")
            return
        try:
            meta = probe_target(target)
            total = meta.get("total")
            if not total:
                self._send_text(502, "Upstream did not expose the complete file size")
                return
            try:
                start, end, partial = parse_client_range(self.headers.get("Range"), int(total))
            except ValueError as exc:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{total}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return

            self.send_response(206 if partial else 200)
            self._send_common_headers(meta)
            if partial:
                self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
            self.send_header("Content-Length", str(end - start + 1))
            self.end_headers()
            try:
                stream_exact(target, start, end, self.wfile)
            except (BrokenPipeError, ConnectionResetError):
                return
            except Exception as exc:
                self.log_message("stream failed after response started: %s", exc)
                self.close_connection = True
                return
        except Exception as exc:
            try:
                self._send_text(502, f"Bridge upstream error: {exc}")
            except Exception:
                pass


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address, handler_class, inherited_socket=False):
        self._activity_lock = threading.Lock()
        self._active_connections = 0
        self._last_activity = time.monotonic()
        if inherited_socket:
            super().__init__(server_address, handler_class, bind_and_activate=False)
            try:
                self.socket.close()
            except Exception:
                pass
            self.socket = socket.fromfd(3, socket.AF_INET, socket.SOCK_STREAM)
            self.server_address = self.socket.getsockname()
            self.server_name = socket.getfqdn(self.server_address[0])
            self.server_port = int(self.server_address[1])
        else:
            super().__init__(server_address, handler_class)

    def connection_opened(self):
        with self._activity_lock:
            self._active_connections += 1
            self._last_activity = time.monotonic()

    def connection_closed(self):
        with self._activity_lock:
            self._active_connections = max(0, self._active_connections - 1)
            self._last_activity = time.monotonic()

    def idle_expired(self):
        with self._activity_lock:
            return (
                self._active_connections == 0
                and time.monotonic() - self._last_activity >= IDLE_SECONDS
            )


def socket_activated() -> bool:
    try:
        return (
            int(os.environ.get("LISTEN_PID", "0")) == os.getpid()
            and int(os.environ.get("LISTEN_FDS", "0")) >= 1
        )
    except ValueError:
        return False


def idle_watchdog(server: Server):
    while True:
        time.sleep(2.0)
        if server.idle_expired():
            print(
                f"AnkerGames JDownloader Bridge idle for {IDLE_SECONDS:.0f}s; exiting until the next JDownloader request.",
                flush=True,
            )
            server.shutdown()
            return


if __name__ == "__main__":
    inherited = socket_activated()
    server = Server(("127.0.0.1", PORT), BridgeHandler, inherited_socket=inherited)
    mode = "socket-activated" if inherited else "standalone"
    print(
        f"AnkerGames JDownloader Bridge ({mode}) listening on http://127.0.0.1:{PORT}",
        flush=True,
    )
    watchdog = threading.Thread(target=idle_watchdog, args=(server,), daemon=True)
    watchdog.start()
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

PYEOF

if [[ ! -x "$VENV_DIR/bin/python" ]]; then
  echo "Creating private Python environment..."
  rm -rf "$VENV_DIR"
  python3 -m venv "$VENV_DIR"
fi

if ! "$VENV_DIR/bin/python" -c 'import httpx' >/dev/null 2>&1; then
  echo "Installing httpx..."
  PIP_DISABLE_PIP_VERSION_CHECK=1 "$VENV_DIR/bin/python" -m pip install --upgrade pip
  PIP_DISABLE_PIP_VERSION_CHECK=1 "$VENV_DIR/bin/python" -m pip install 'httpx>=0.27,<1'
fi

"$VENV_DIR/bin/python" -m py_compile "$BRIDGE_PY"

cat > "$SERVICE_FILE" <<SERVICEEOF
[Unit]
Description=AnkerGames JDownloader on-demand compatibility bridge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$VENV_DIR/bin/python $BRIDGE_PY
Restart=no
SERVICEEOF

cat > "$SOCKET_FILE" <<SOCKETEOF
[Unit]
Description=AnkerGames JDownloader on-demand socket

[Socket]
ListenStream=127.0.0.1:$PORT
NoDelay=true
Service=ankergames-jd-bridge.service

[Install]
WantedBy=sockets.target
SOCKETEOF

systemctl --user daemon-reload
systemctl --user enable --now ankergames-jd-bridge.socket

configure_jdownloader_rules

# This health check wakes the bridge once to verify socket activation.
# It then exits automatically after 45 seconds of no active connection.
if command -v curl >/dev/null 2>&1 && curl -fsS "http://127.0.0.1:${PORT}/health" >/dev/null; then
  echo
  echo "On-demand bridge installed successfully."
  echo "The Python bridge starts only when JDownloader connects to 127.0.0.1:${PORT}."
  echo "After 45 seconds with no active connection, the Python bridge exits automatically."
  echo "Only the tiny systemd socket activation entry stays enabled so the next request can wake it."
else
  echo
  echo "On-demand bridge files were installed, but the activation test did not answer."
  echo "Check: systemctl --user status ankergames-jd-bridge.socket"
  echo "Logs:  journalctl --user -u ankergames-jd-bridge.service -n 50 --no-pager"
fi

echo
echo "JDownloader was configured automatically with the required AnkerGames LinkCrawler rules."
echo "Uninstall later with: bash "$0" --uninstall"
