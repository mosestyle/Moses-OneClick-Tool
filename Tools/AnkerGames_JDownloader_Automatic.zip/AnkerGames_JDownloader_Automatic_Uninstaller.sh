#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$HOME/.local/share/ankergames-jd-bridge"
SYSTEMD_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.service"
SOCKET_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.socket"
JD_RULES_FILENAME="jd.controlling.linkcrawler.LinkCrawlerConfig.linkcrawlerrules.json"
JD_MAIN_FILENAME="jd.controlling.linkcrawler.LinkCrawlerConfig.json"

find_jd_cfg_dir() {
  local candidate=""
  while IFS= read -r candidate; do
    [[ -n "$candidate" ]] || continue
    dirname "$candidate"
    return 0
  done < <(
    find "$HOME" -maxdepth 8 -type f -name "$JD_RULES_FILENAME" \
      -printf '%T@ %p\n' 2>/dev/null | sort -nr | cut -d' ' -f2-
  )
  while IFS= read -r candidate; do
    [[ -n "$candidate" ]] || continue
    dirname "$candidate"
    return 0
  done < <(
    find "$HOME" -maxdepth 8 -type f -name "$JD_MAIN_FILENAME" \
      -printf '%T@ %p\n' 2>/dev/null | sort -nr | cut -d' ' -f2-
  )
  return 1
}

remove_jdownloader_rules() {
  local cfg_dir rules_file
  if ! cfg_dir="$(find_jd_cfg_dir)"; then
    echo "JDownloader cfg folder not found; no rules needed removal."
    return 0
  fi
  rules_file="$cfg_dir/$JD_RULES_FILENAME"
  [[ -f "$rules_file" ]] || return 0

  JD_RULES_FILE="$rules_file" python3 <<'PY'
import json
import os
from pathlib import Path

path = Path(os.environ["JD_RULES_FILE"])
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(data, list):
    raise SystemExit(0)

names = {
    "AnkerGames to JD Bridge",
    "AnkerGames JD Bridge DirectHTTP",
}
cleaned = []
changed = False
for rule in data:
    if isinstance(rule, dict):
        name = str(rule.get("name") or "")
        pattern = str(rule.get("pattern") or "")
        if name in names or ("AnkerGames" in name and ("dlproxy" in pattern or "127\\.0\\.0\\.1:17892" in pattern)):
            changed = True
            continue
    cleaned.append(rule)

if changed:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(cleaned, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    print("Removed the AnkerGames LinkCrawler rules from JDownloader.")
else:
    print("No AnkerGames LinkCrawler rules were present.")
PY
}

echo "Removing AnkerGames JDownloader integration..."

systemctl --user disable --now ankergames-jd-bridge.socket >/dev/null 2>&1 || true
systemctl --user disable --now ankergames-jd-bridge.service >/dev/null 2>&1 || true
rm -f "$SOCKET_FILE" "$SERVICE_FILE"
systemctl --user daemon-reload >/dev/null 2>&1 || true
systemctl --user reset-failed ankergames-jd-bridge.service >/dev/null 2>&1 || true

remove_jdownloader_rules || true
rm -rf "$APP_DIR"

echo
echo "AnkerGames JDownloader integration has been completely removed."
echo "Other JDownloader LinkCrawler rules and settings were left untouched."
