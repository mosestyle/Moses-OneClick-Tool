AnkerGames JDownloader Automatic Setup

INSTALL:
  bash ~/Downloads/AnkerGames_JDownloader_Automatic_Setup.sh

The installer:
  * installs the on-demand local compatibility bridge
  * enables socket activation so the Python bridge runs only when needed
  * finds JDownloader's cfg directory
  * adds/updates the two required AnkerGames LinkCrawler rules automatically
  * enables LinkCrawler Rules
  * preserves unrelated existing JDownloader rules
  * creates a backup of the relevant JDownloader config files

After installation, restart JDownloader once if it was open during setup.

UNINSTALL:
  bash ~/Downloads/AnkerGames_JDownloader_Automatic_Uninstaller.sh

The uninstaller:
  * stops/removes the socket and bridge service
  * removes the bridge files and private Python environment
  * removes only the two AnkerGames LinkCrawler rules
  * leaves unrelated JDownloader rules/settings untouched
