#!/usr/bin/env bash
set -u
APP="steam-machine-fan-profiles"
CFG="$HOME/.config/$APP"
STATE="$HOME/.local/state/$APP"
USER_APP="$HOME/.local/share/$APP"
DESKTOP_FILE="$HOME/.local/share/applications/steam-machine-fan-profiles.desktop"
SERVICE_FILE="$HOME/.config/systemd/user/$APP.service"

echo "Emergency removal: killing Fan Profiles without running any fan-control helper..."
systemctl --user kill --kill-whom=all --signal=SIGKILL "$APP.service" >/dev/null 2>&1 || true
systemctl --user disable "$APP.service" >/dev/null 2>&1 || true
rm -f "$SERVICE_FILE"
systemctl --user daemon-reload >/dev/null 2>&1 || true
systemctl --user reset-failed "$APP.service" >/dev/null 2>&1 || true
rm -rf "$CFG" "$HOME/.cache/$APP" "$STATE" "$USER_APP"
rm -f "$DESKTOP_FILE"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
echo "Emergency removal complete. The fan setting was deliberately NOT changed."
