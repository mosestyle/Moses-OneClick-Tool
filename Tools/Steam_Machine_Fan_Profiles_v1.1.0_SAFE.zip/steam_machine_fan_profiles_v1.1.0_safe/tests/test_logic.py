import importlib.util
from pathlib import Path

P = Path(__file__).resolve().parents[1] / "payload" / "fan_profiles_daemon.py"
spec = importlib.util.spec_from_file_location("daemon", P)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def test_non_game_filters():
    hidden = [
        "Proton 11.0",
        "Proton Experimental",
        "Proton Hotfix",
        "Proton 99.1",
        "Steam Linux Runtime 4.0",
        "Steam Linux Runtime (sniper)",
        "Steam Runtime 3",
        "Steamworks Common Redistributables",
        "Steamworks SDK Redist",
        "Steam Deck Windows Resources",
    ]
    for name in hidden:
        assert mod.is_non_game_component(name), name
    for name in ["Portal 2", "Red Dead Redemption 2", "STAR WARS Jedi Survivor", "Outer Wilds"]:
        assert not mod.is_non_game_component(name), name


def test_desired_states():
    assert mod.desired_fan_state(True, set(), set()) is True
    assert mod.desired_fan_state(True, {"steam:1"}, set()) is False
    assert mod.desired_fan_state(True, {"steam:1"}, {"steam:1"}) is True
    assert mod.desired_fan_state(True, {"steam:1", "steam:2"}, {"steam:1"}) is False
    assert mod.desired_fan_state(False, {"steam:1"}, set()) is True


def test_future_proton_versions_are_hidden():
    for v in ("12", "13.5", "Experimental", "Next"):
        assert mod.is_non_game_component(f"Proton {v}")


if __name__ == "__main__":
    test_non_game_filters()
    test_desired_states()
    test_future_proton_versions_are_hidden()
    print("logic tests passed")
