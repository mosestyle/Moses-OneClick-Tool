#!/usr/bin/env bash
set -euo pipefail

APP="steam-machine-fan-profiles"
VERSION="1.1.0"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
HELPER="/usr/bin/steamos-polkit-helpers/jupiter-fan-control"
PKEXEC="/usr/bin/pkexec"
TIMEOUT_BIN="$(command -v timeout || true)"
CFG="$HOME/.config/$APP"
STATE="$HOME/.local/state/$APP"
USER_APP="$HOME/.local/share/$APP"
DESKTOP_DIR="$HOME/.local/share/applications"
USER_SYSTEMD="$HOME/.config/systemd/user"
SERVICE_FILE="$USER_SYSTEMD/$APP.service"

if [[ "$(id -u)" -eq 0 ]]; then
  echo "Please run Install.sh as your normal SteamOS user, not as root."
  exit 1
fi

for f in "$HELPER" "$PKEXEC"; do
  if [[ ! -x "$f" ]]; then
    echo "ERROR: Required SteamOS component was not found: $f"
    echo "Nothing was installed."
    exit 1
  fi
done
if [[ -z "$TIMEOUT_BIN" ]]; then
  echo "ERROR: The timeout command is required but was not found. Nothing was installed."
  exit 1
fi
for f in "$PAYLOAD/fan_profiles_daemon.py" "$PAYLOAD/fan_profiles_gui.py" "$PAYLOAD/fan-icon.svg"; do
  if [[ ! -f "$f" ]]; then
    echo "ERROR: Installer payload is incomplete: $f"
    echo "Keep the extracted ZIP contents together."
    exit 1
  fi
done

if [[ -e "/etc/systemd/system/$APP.service" ]]; then
  echo "ERROR: A root-level service from an older build exists at /etc/systemd/system/$APP.service"
  echo "v$VERSION will not install on top of it because this safe build never uses sudo."
  echo "Remove the old root-level build first, then run this installer again."
  exit 1
fi

echo
echo "Steam Machine Fan Profiles v$VERSION SAFE"
echo "Passwordless user-service install"
echo "No sudo password is used."
echo

# IMPORTANT: An older 1.0.x daemon performed fan work while receiving SIGTERM.
# Never gracefully stop an old unit here. Kill it first so its old shutdown path
# cannot run while we upgrade.
systemctl --user kill --kill-whom=all --signal=SIGKILL "$APP.service" >/dev/null 2>&1 || true
systemctl --user disable "$APP.service" >/dev/null 2>&1 || true
rm -f "$SERVICE_FILE"
systemctl --user daemon-reload >/dev/null 2>&1 || true
systemctl --user reset-failed "$APP.service" >/dev/null 2>&1 || true

# Record the first-install state before changing anything. Preserve it on upgrades.
ORIGINAL="off"
if systemctl is-active --quiet jupiter-fan-control.service; then ORIGINAL="on"; fi
if [[ -f "$STATE/original_fan_state" ]]; then
  SAVED="$(cat "$STATE/original_fan_state" 2>/dev/null || true)"
  if [[ "$SAVED" == "on" || "$SAVED" == "off" ]]; then ORIGINAL="$SAVED"; fi
fi

# The desired baseline is ON. If it is already ON, do not invoke pkexec at install.
# If it is OFF, make exactly one bounded request. There is no password fallback.
if ! systemctl is-active --quiet jupiter-fan-control.service; then
  echo "Updated Fan Control is currently OFF. Enabling the baseline once..."
  if ! "$TIMEOUT_BIN" --kill-after=1s 5s "$PKEXEC" --disable-internal-agent "$HELPER" --enable; then
    echo
    echo "ERROR: SteamOS did not complete Valve's fan-control helper request."
    echo "Installation was cancelled. No background service was installed."
    echo "No retry was attempted and no password prompt will be used."
    exit 1
  fi
  if ! systemctl is-active --quiet jupiter-fan-control.service; then
    echo "ERROR: Valve's helper returned but Updated Fan Control is still OFF."
    echo "Installation was cancelled."
    exit 1
  fi
else
  echo "Updated Fan Control is already ON. The installer will not touch it."
fi

mkdir -p "$CFG" "$STATE" "$USER_APP" "$DESKTOP_DIR" "$USER_SYSTEMD"
chmod 700 "$CFG" "$STATE" 2>/dev/null || true

if [[ ! -f "$STATE/original_fan_state" ]]; then
  printf '%s\n' "$ORIGINAL" > "$STATE/original_fan_state"
  chmod 600 "$STATE/original_fan_state"
fi

# Create or migrate config without discarding existing exception choices.
python3 - "$CFG/config.json" <<'PY'
import json, os, sys
from pathlib import Path
p=Path(sys.argv[1])
try:
    d=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
except Exception:
    d={}
out={
    'version': 2,
    'automatic': bool(d.get('automatic', True)),
    'exceptions': sorted({str(x) for x in d.get('exceptions', []) if isinstance(x,(str,int))}),
}
p.parent.mkdir(parents=True, exist_ok=True)
tmp=p.with_suffix('.json.tmp')
tmp.write_text(json.dumps(out, indent=2, sort_keys=True), encoding='utf-8')
os.chmod(tmp, 0o600)
os.replace(tmp,p)
PY

cp "$PAYLOAD/fan_profiles_daemon.py" "$USER_APP/fan_profiles_daemon.py"
cp "$PAYLOAD/fan_profiles_gui.py" "$USER_APP/fan_profiles_gui.py"
cp "$PAYLOAD/fan-icon.svg" "$USER_APP/fan-icon.svg"
chmod 755 "$USER_APP/fan_profiles_daemon.py" "$USER_APP/fan_profiles_gui.py"
chmod 644 "$USER_APP/fan-icon.svg"

cat > "$DESKTOP_DIR/steam-machine-fan-profiles.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Steam Machine Fan Profiles
Comment=Safe automatic per-game SteamOS fan-control switching
Exec=/usr/bin/python3 $USER_APP/fan_profiles_gui.py
Icon=$USER_APP/fan-icon.svg
Terminal=false
Categories=Utility;System;
StartupNotify=true
EOF
chmod 644 "$DESKTOP_DIR/steam-machine-fan-profiles.desktop"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Steam Machine Fan Profiles SAFE
After=default.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 $USER_APP/fan_profiles_daemon.py
Restart=no
KillMode=control-group
KillSignal=SIGTERM
TimeoutStopSec=1s
SendSIGKILL=yes
Nice=10
StandardOutput=null
StandardError=null

[Install]
WantedBy=default.target
EOF
chmod 644 "$SERVICE_FILE"

systemctl --user daemon-reload
systemctl --user enable "$APP.service" >/dev/null
systemctl --user start "$APP.service"
sleep 1
if ! systemctl --user is-active --quiet "$APP.service"; then
  echo
  echo "ERROR: The SAFE background service did not stay running."
  echo "It will not be restarted automatically."
  systemctl --user disable "$APP.service" >/dev/null 2>&1 || true
  exit 1
fi

command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESKTOP_DIR" >/dev/null 2>&1 || true

echo
echo "Installed successfully."
echo "Updated Fan Control baseline: ON"
echo "Background service: active, user-level, Restart=no"
echo "Shutdown behavior: immediate exit with NO fan-control command"
echo "Helper failure behavior: automation pauses after ONE failed request"
echo "Open 'Steam Machine Fan Profiles' from Desktop Mode."
