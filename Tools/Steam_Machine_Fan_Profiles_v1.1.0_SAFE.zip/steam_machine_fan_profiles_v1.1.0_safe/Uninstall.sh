#!/usr/bin/env bash
set -euo pipefail

APP="steam-machine-fan-profiles"
VERSION="1.1.0"
HELPER="/usr/bin/steamos-polkit-helpers/jupiter-fan-control"
PKEXEC="/usr/bin/pkexec"
TIMEOUT_BIN="$(command -v timeout || true)"
CFG="$HOME/.config/$APP"
STATE="$HOME/.local/state/$APP"
USER_APP="$HOME/.local/share/$APP"
DESKTOP_FILE="$HOME/.local/share/applications/steam-machine-fan-profiles.desktop"
SERVICE_FILE="$HOME/.config/systemd/user/$APP.service"
ORIGINAL="on"

if [[ "$(id -u)" -eq 0 ]]; then
  echo "Please run Uninstall.sh as your normal SteamOS user, not as root."
  exit 1
fi

if [[ -f "$STATE/original_fan_state" ]]; then
  SAVED="$(cat "$STATE/original_fan_state" 2>/dev/null || true)"
  if [[ "$SAVED" == "on" || "$SAVED" == "off" ]]; then ORIGINAL="$SAVED"; fi
fi

echo
echo "Steam Machine Fan Profiles v$VERSION COMPLETE NUKE UNINSTALL"
echo "No sudo password is used."
echo

# Kill first. This is deliberate and also makes uninstall safe if an old 1.0.x
# daemon is somehow still loaded, because the old SIGTERM restore path cannot run.
systemctl --user kill --kill-whom=all --signal=SIGKILL "$APP.service" >/dev/null 2>&1 || true
systemctl --user disable "$APP.service" >/dev/null 2>&1 || true
rm -f "$SERVICE_FILE"
systemctl --user daemon-reload >/dev/null 2>&1 || true
systemctl --user reset-failed "$APP.service" >/dev/null 2>&1 || true

RESTORE_RESULT="not needed"
CURRENT="off"
if systemctl is-active --quiet jupiter-fan-control.service; then CURRENT="on"; fi

# Restore only from a normal stable user/system session. Never try this during
# reboot, shutdown, logout, or a session transition. One bounded attempt only.
SYSTEM_STATE="$(systemctl is-system-running 2>/dev/null || true)"
USER_STATE="$(loginctl show-user "$(id -u)" -p State --value 2>/dev/null || true)"
if [[ "$CURRENT" != "$ORIGINAL" ]]; then
  if [[ ( "$SYSTEM_STATE" == "running" || "$SYSTEM_STATE" == "degraded" ) && ( "$USER_STATE" == "active" || "$USER_STATE" == "online" ) && -x "$HELPER" && -x "$PKEXEC" && -n "$TIMEOUT_BIN" ]]; then
    ARG="--enable"; [[ "$ORIGINAL" == "off" ]] && ARG="--disable"
    if "$TIMEOUT_BIN" --kill-after=1s 5s "$PKEXEC" --disable-internal-agent "$HELPER" "$ARG" >/dev/null 2>&1; then
      RESTORE_RESULT="restored to $ORIGINAL"
    else
      RESTORE_RESULT="could not restore automatically; set Updated Fan Control to $ORIGINAL manually in Steam Settings"
    fi
  else
    RESTORE_RESULT="skipped because the session was not stable; set Updated Fan Control to $ORIGINAL manually in Steam Settings"
  fi
fi

rm -rf "$CFG"
rm -rf "$HOME/.cache/$APP"
rm -rf "$STATE"
rm -rf "$USER_APP"
rm -f "$DESKTOP_FILE"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true

echo "Complete uninstall finished."
echo "Removed: service, GUI, daemon, launcher, config, exceptions, cache, status, and saved app state."
echo "Fan-control restore: $RESTORE_RESULT"

if [[ -e "/etc/systemd/system/$APP.service" || -d "/var/lib/$APP" ]]; then
  echo
  echo "WARNING: Root-owned files from the old v1.0.0 branch still exist."
  echo "This passwordless uninstaller intentionally does not use sudo and therefore cannot remove them."
fi
