STEAM MACHINE FAN PROFILES v1.1.0 SAFE
=======================================

THIS IS A FRESH SAFE BRANCH
---------------------------
v1.1.0 replaces the old 1.0.x daemon design. Do not reinstall v1.0.0, v1.0.1,
or v1.0.2.

The old branch could perform a fan-helper action while its user service was being
stopped and could repeatedly retry a failed state change. That design has been removed.

NORMAL BEHAVIOR
---------------
No game running:                 Updated Fan Control ON
Default game running:            Updated Fan Control OFF
Checked exception game running:  Updated Fan Control ON
Game closes normally:            Updated Fan Control returns ON
Automatic Fan Profiles OFF:      The tool stops game automation and restores ON once

The GUI is intended for Desktop Mode. The user-level background service continues
working in Gaming Mode.

SAFETY CHANGES IN v1.1.0
-------------------------
1. NO shutdown restore command
   SIGTERM/SIGINT immediately stop the daemon. It never calls the fan helper as part
   of service stop, logout, reboot, shutdown, or Return to Gaming Mode.

2. NO retry loop
   A fan-control helper failure pauses automation after that single failed request.
   The daemon does not keep retrying every second.

3. Bounded helper calls
   A Valve helper request has a short timeout. A stuck pkexec/helper process is killed
   as its own process group.

4. Stable-session gate
   Automatic game-triggered changes are deferred unless the system/user session is
   stable and the Steam client has remained present for 12 seconds. This is intended
   to keep fan commands away from Steam/session startup, logout, shutdown, and mode
   transitions.

5. Debounced game detection
   A game state must remain stable for 3 seconds before it can trigger a fan change.

6. Safety cooldown
   At least 10 seconds must pass between helper calls. Rapid state changes cannot
   rapidly toggle the Valve fan service.

7. No automatic service restart
   The systemd user service uses Restart=no. If the daemon unexpectedly exits, it stays
   stopped instead of entering a restart loop.

8. User service only
   No sudo password. No root-owned app files. No custom privileged helper.

9. Valve helper only
   The tool never writes fan RPM, custom curves, EC registers, hwmon values, voltages,
   clocks, or TDP settings. It only requests Valve's existing jupiter-fan-control
   --enable / --disable helper through SteamOS pkexec.

10. Safe failure behavior
    If a helper call fails, the config is switched to Automatic Fan Profiles OFF.
    The GUI shows that automation was paused for safety. No further helper calls are
    attempted until you explicitly turn Automatic Fan Profiles ON again.

INSTALL
-------
1. Extract the ZIP in Desktop Mode.
2. Open Konsole in the extracted folder.
3. Run:

     ./Install.sh

   If needed first run:

     chmod +x Install.sh Uninstall.sh Emergency_Remove.sh

4. No sudo password should be requested.
5. Open "Steam Machine Fan Profiles" from the application launcher.

The installer safely kills any loaded old user-service daemon BEFORE replacing it.
It never gracefully stops an old 1.0.x daemon, specifically so old shutdown code cannot run.

If Updated Fan Control is already ON, the installer does not invoke the fan helper at all.
If it is OFF, the installer makes one bounded request to enable the baseline and cancels
installation if that request does not complete.

GAME LIST
---------
The GUI automatically hides compatibility/system components including future versions of:
  * Proton
  * Proton Experimental / Hotfix
  * Steam Linux Runtime
  * Steam Runtime
  * Steamworks Common Redistributables / SDK redistributables
  * Steam Deck Windows Resources

Newly installed games do not require reopening the GUI. They automatically use the normal
Default OFF rule while playing. Open the GUI only if you want a game to be an exception
and keep Updated Fan Control ON.

GAME DETECTION
--------------
The service watches Steam's lifetime launch/reaper process containing:

  SteamLaunch AppId=<id>

It does not modify Steam Launch Options. Steam games and Non-Steam shortcuts are supported.

GUI
---
Automatic Fan Profiles ON:
  Automatic per-game behavior is active.

Automatic Fan Profiles OFF:
  Per-game automation is disabled. When you switch it OFF while the service is running,
  the daemon makes at most one safe request to restore Updated Fan Control ON.

Current Status intentionally shows only:
  Enable Updated Fan Control: ON/OFF
  Running game: <name or None>

There is no Desktop Mode / Gaming Mode field.

COMPLETE NUKE UNINSTALL
-----------------------
Run:

     ./Uninstall.sh

The uninstaller first SIGKILLs the service so no daemon shutdown path can run, then removes:
  * systemd user service
  * daemon and GUI
  * desktop launcher
  * config
  * game exceptions
  * status files
  * cache
  * recorded app state

It restores the fan setting that was recorded before the first v1.1.0 installation only
when the current system/user session is stable. It makes one bounded restore attempt and
never retries. If restoration is skipped or fails, it tells you which state to choose
manually in Steam Settings.

EMERGENCY REMOVE
----------------
Emergency_Remove.sh is also included. It kills and removes the tool without invoking the
fan helper at all. It deliberately leaves the current fan setting unchanged.

IMPORTANT TESTING NOTE
----------------------
This utility was code-tested in the authoring environment, but the authoring environment
cannot hardware-test your specific Steam Machine or SteamOS image. Treat v1.1.0 as the
first hardware test of this redesigned safe branch.

Recommended first test:
  1. Install while Updated Fan Control is ON.
  2. Confirm Steam, Return to Gaming Mode, Restart, and Shutdown still work normally.
  3. Only then launch one game and confirm the setting changes OFF.
  4. Exit the game and confirm it returns ON after the safety debounce/cooldown.

If Steam/session behavior ever becomes abnormal, run Emergency_Remove.sh and reboot.
