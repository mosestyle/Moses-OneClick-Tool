#!/usr/bin/env python3
"""Steam Machine Fan Profiles v1.1.0 SAFE background daemon.

Safety design:
* User-level service only.
* No fan action from SIGTERM/SIGINT, service stop, logout, reboot, or shutdown.
* No direct fan RPM, EC, hwmon, voltage, clock, or TDP writes.
* Valve's existing jupiter-fan-control helper is the only fan-control action.
* Helper calls are bounded by a short timeout and killed as a process group on timeout.
* A failed helper call disables automation instead of retrying.
* Fan changes are event-driven. The loop does not repeatedly enforce a state every second.
* Game/session transitions are debounced, and game-triggered changes require a stable Steam
  client plus a stable system/user session.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import signal
import struct
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

VERSION = "1.1.0"
HELPER = Path("/usr/bin/steamos-polkit-helpers/jupiter-fan-control")
PKEXEC = Path("/usr/bin/pkexec")
SYSTEMCTL = "/usr/bin/systemctl"
LOGINCTL = "/usr/bin/loginctl"
SERVICE = "jupiter-fan-control.service"
APP_RE = re.compile(rb"SteamLaunch\s+AppId=(\d+)")

# Future Proton/runtime releases are filtered by name pattern, not version number.
NON_GAME_COMPONENT_PATTERNS = (
    re.compile(r"^proton(?:\s|$)", re.I),
    re.compile(r"^steam linux runtime(?:\s|$|\()", re.I),
    re.compile(r"^steam runtime(?:\s|$|\()", re.I),
    re.compile(r"^steamworks common redistributables$", re.I),
    re.compile(r"^steamworks sdk redist(?:ributables)?(?:\s|$)", re.I),
    re.compile(r"^steam deck windows resources$", re.I),
)

# How long state must be stable before an automatic game transition can touch fan control.
GAME_DEBOUNCE_SECONDS = 3.0
STEAM_STABLE_SECONDS = 12.0
MIN_HELPER_INTERVAL_SECONDS = 10.0
HELPER_TIMEOUT_SECONDS = 4.0
VERIFY_TIMEOUT_SECONDS = 1.5
CATALOG_SCAN_SECONDS = 45.0
ENVIRONMENT_SCAN_SECONDS = 2.0

shutting_down = False
helper_proc: Optional[subprocess.Popen] = None


def is_non_game_component(name: str) -> bool:
    clean = (name or "").strip()
    return any(p.search(clean) for p in NON_GAME_COMPONENT_PATTERNS)


def atomic_json_write(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def read_config(path: Path) -> dict:
    default = {"version": 2, "automatic": True, "exceptions": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return default
        return {
            "version": 2,
            "automatic": bool(data.get("automatic", True)),
            "exceptions": sorted({str(x) for x in data.get("exceptions", []) if isinstance(x, (str, int))}),
        }
    except Exception:
        return default


def set_automatic_false(path: Path, cfg: dict) -> None:
    safe = {
        "version": 2,
        "automatic": False,
        "exceptions": sorted({str(x) for x in cfg.get("exceptions", [])}),
    }
    try:
        atomic_json_write(path, safe)
    except Exception:
        pass


def systemctl_active() -> bool:
    try:
        cp = subprocess.run(
            [SYSTEMCTL, "is-active", "--quiet", SERVICE],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=1.0,
            check=False,
        )
        return cp.returncode == 0
    except Exception:
        return False


def system_is_safe_for_helper(uid: int) -> tuple[bool, str]:
    """Refuse privileged helper calls while boot/session/system state is unstable."""
    if shutting_down:
        return False, "service is stopping"
    try:
        cp = subprocess.run(
            [SYSTEMCTL, "is-system-running"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=1.0,
            check=False,
        )
        sys_state = (cp.stdout or "").strip().lower()
    except Exception:
        return False, "system state could not be read"
    if sys_state not in {"running", "degraded"}:
        return False, f"system state is {sys_state or 'unknown'}"

    try:
        cp = subprocess.run(
            [LOGINCTL, "show-user", str(uid), "-p", "State", "--value"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=1.0,
            check=False,
        )
        user_state = (cp.stdout or "").strip().lower()
    except Exception:
        return False, "user session state could not be read"
    if user_state not in {"active", "online"}:
        return False, f"user session state is {user_state or 'unknown'}"
    return True, ""


def terminate_helper_now() -> None:
    global helper_proc
    proc = helper_proc
    if proc is None or proc.poll() is not None:
        return
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def hard_stop(_sig, _frame) -> None:
    """Stop immediately. Never run fan restore logic from a shutdown signal."""
    global shutting_down
    shutting_down = True
    terminate_helper_now()
    os._exit(0)


def apply_fan_state(enable: bool) -> tuple[bool, str]:
    """Perform one bounded Valve-helper action. Never retries internally."""
    global helper_proc
    if shutting_down:
        return False, "service is stopping"
    if not HELPER.exists() or not os.access(HELPER, os.X_OK):
        return False, f"SteamOS fan helper not found: {HELPER}"
    if not PKEXEC.exists() or not os.access(PKEXEC, os.X_OK):
        return False, f"SteamOS pkexec not found: {PKEXEC}"

    current = systemctl_active()
    if current == enable:
        return True, ""

    arg = "--enable" if enable else "--disable"
    try:
        helper_proc = subprocess.Popen(
            [str(PKEXEC), "--disable-internal-agent", str(HELPER), arg],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,
        )
        try:
            stdout, stderr = helper_proc.communicate(timeout=HELPER_TIMEOUT_SECONDS)
        except subprocess.TimeoutExpired:
            terminate_helper_now()
            try:
                stdout, stderr = helper_proc.communicate(timeout=0.5)
            except Exception:
                stdout, stderr = "", ""
            return False, "SteamOS fan helper timed out. Automation was paused for safety."
        rc = helper_proc.returncode
    except Exception as exc:
        return False, f"Could not run SteamOS fan helper: {exc}"
    finally:
        helper_proc = None

    if shutting_down:
        return False, "service stopped while fan helper was running"
    if rc != 0:
        msg = (stderr or stdout or "unknown error").strip().replace("\n", " ")
        return False, f"SteamOS fan helper failed ({rc}): {msg[:350]}"

    deadline = time.monotonic() + VERIFY_TIMEOUT_SECONDS
    while time.monotonic() < deadline and not shutting_down:
        if systemctl_active() == enable:
            return True, ""
        time.sleep(0.10)
    return False, "SteamOS helper returned success, but the fan-control service state did not change."


def read_proc_state(target_uid: int, proc_root: Path = Path("/proc")) -> tuple[set[str], bool]:
    """Return SteamLaunch IDs and whether the Steam client itself appears alive."""
    ids: set[str] = set()
    steam_present = False
    try:
        entries = list(proc_root.iterdir())
    except Exception:
        return ids, False

    for entry in entries:
        if not entry.name.isdigit():
            continue
        try:
            if entry.stat().st_uid != target_uid:
                continue
            raw = (entry / "cmdline").read_bytes()
            if not raw:
                continue
            normalized = raw.replace(b"\0", b" ")
            low = normalized.lower()
            # SteamOS uses the Steam client in both Gaming Mode and Desktop Mode.
            if b"steamwebhelper" in low or re.search(rb"(?:^|[/ ])steam(?: |$)", low):
                steam_present = True
            for match in APP_RE.finditer(normalized):
                value = match.group(1).decode("ascii", errors="ignore")
                if value and value != "0":
                    ids.add(value)
        except (FileNotFoundError, ProcessLookupError, PermissionError, OSError):
            continue
    return ids, steam_present


def parse_text_vdf_paths(text: str) -> list[str]:
    found = []
    for m in re.finditer(r'"path"\s+"([^"]+)"', text, flags=re.IGNORECASE):
        found.append(m.group(1).replace("\\\\", "\\"))
    return found


def steam_roots(home: Path) -> list[Path]:
    candidates = [home / ".local/share/Steam", home / ".steam/steam"]
    out: list[Path] = []
    seen: set[str] = set()
    for p in candidates:
        try:
            rp = p.resolve()
        except Exception:
            rp = p
        if rp.exists() and str(rp) not in seen:
            seen.add(str(rp))
            out.append(rp)
    return out


def library_paths(home: Path) -> list[Path]:
    libs: list[Path] = []
    seen: set[str] = set()
    for root in steam_roots(home):
        if str(root) not in seen:
            seen.add(str(root))
            libs.append(root)
        vdf = root / "steamapps/libraryfolders.vdf"
        try:
            text = vdf.read_text(encoding="utf-8", errors="replace")
            for raw in parse_text_vdf_paths(text):
                p = Path(raw)
                if p.exists() and str(p) not in seen:
                    seen.add(str(p))
                    libs.append(p)
        except Exception:
            pass
    return libs


def parse_manifest(path: Path) -> tuple[str, str] | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None
    mid = re.search(r'"appid"\s+"([0-9]+)"', text)
    mn = re.search(r'"name"\s+"([^"]+)"', text)
    if not mid:
        return None
    return mid.group(1), (mn.group(1) if mn else f"Steam App {mid.group(1)}")


def read_cstring(data: bytes, pos: int) -> tuple[str, int]:
    end = data.find(b"\x00", pos)
    if end < 0:
        raise ValueError("unterminated string")
    return data[pos:end].decode("utf-8", errors="replace"), end + 1


def parse_binary_vdf_object(data: bytes, pos: int = 0) -> tuple[dict, int]:
    obj: dict = {}
    while pos < len(data):
        typ = data[pos]
        pos += 1
        if typ in (0x08, 0x0B):
            return obj, pos
        key, pos = read_cstring(data, pos)
        if typ == 0x00:
            val, pos = parse_binary_vdf_object(data, pos)
        elif typ == 0x01:
            val, pos = read_cstring(data, pos)
        elif typ == 0x02:
            if pos + 4 > len(data):
                raise ValueError("truncated int32")
            val = struct.unpack_from("<i", data, pos)[0]
            pos += 4
        elif typ == 0x07:
            if pos + 8 > len(data):
                raise ValueError("truncated uint64")
            val = struct.unpack_from("<Q", data, pos)[0]
            pos += 8
        elif typ == 0x0A:
            if pos + 8 > len(data):
                raise ValueError("truncated int64")
            val = struct.unpack_from("<q", data, pos)[0]
            pos += 8
        else:
            raise ValueError(f"unsupported VDF type {typ:#x}")
        obj[key] = val
    return obj, pos


def shortcut_entries(home: Path) -> list[tuple[int, str]]:
    results: list[tuple[int, str]] = []
    seen: set[tuple[int, str]] = set()
    for root in steam_roots(home):
        udir = root / "userdata"
        if not udir.exists():
            continue
        for f in udir.glob("*/config/shortcuts.vdf"):
            try:
                data = f.read_bytes()
                parsed, _ = parse_binary_vdf_object(data, 0)
                shortcuts = parsed.get("shortcuts", parsed)
                if not isinstance(shortcuts, dict):
                    continue
                for val in shortcuts.values():
                    if not isinstance(val, dict):
                        continue
                    appid = val.get("appid")
                    name = val.get("appname")
                    if isinstance(appid, int) and isinstance(name, str):
                        u32 = appid & 0xFFFFFFFF
                        key = (u32, name)
                        if key not in seen:
                            seen.add(key)
                            results.append(key)
            except Exception:
                continue
    return results


def build_catalog(home: Path) -> tuple[dict[str, str], dict[str, str], set[str]]:
    names: dict[str, str] = {}
    aliases: dict[str, str] = {}
    ignored_runtime_ids: set[str] = set()

    for lib in library_paths(home):
        steamapps = lib / "steamapps"
        if not steamapps.exists():
            continue
        for mf in steamapps.glob("appmanifest_*.acf"):
            item = parse_manifest(mf)
            if not item:
                continue
            appid, name = item
            if is_non_game_component(name):
                ignored_runtime_ids.add(appid)
                continue
            canonical = f"steam:{appid}"
            names[canonical] = name
            aliases[appid] = canonical

    for appid, name in shortcut_entries(home):
        gameid64 = ((appid & 0xFFFFFFFF) << 32) | 0x02000000
        if is_non_game_component(name):
            ignored_runtime_ids.add(str(appid))
            ignored_runtime_ids.add(str(gameid64))
            continue
        canonical = f"shortcut:{appid}"
        names[canonical] = name
        aliases[str(appid)] = canonical
        aliases[str(gameid64)] = canonical

    return names, aliases, ignored_runtime_ids


def canonicalize_runtime_id(raw: str, aliases: dict[str, str]) -> str:
    if raw in aliases:
        return aliases[raw]
    try:
        n = int(raw)
        if n > 0xFFFFFFFF:
            hi = (n >> 32) & 0xFFFFFFFF
            c = f"shortcut:{hi}"
            if c in aliases.values():
                return c
        return f"steam:{n}"
    except Exception:
        return f"steam:{raw}"


def desired_fan_state(automatic: bool, active: set[str], exceptions: set[str]) -> bool:
    if not automatic:
        return True
    if not active:
        return True
    # Favor the cooler default if any active game is not an explicit exception.
    return all(key in exceptions for key in active)


def write_status(path: Path, *, automatic: bool, fan_on: bool, active_keys: list[str],
                 active_names: list[str], desired_on: bool, steam_stable: bool,
                 safe_paused: bool, error: str = "", note: str = "") -> None:
    atomic_json_write(path, {
        "version": VERSION,
        "automatic": automatic,
        "fan_control_on": fan_on,
        "desired_fan_control_on": desired_on,
        "active_games": active_keys,
        "active_game_names": active_names,
        "steam_stable": steam_stable,
        "safe_paused": safe_paused,
        "error": error,
        "note": note,
        "updated_at": int(time.time()),
    })


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--home", default=str(Path.home()))
    parser.add_argument("--uid", type=int, default=os.getuid())
    parser.add_argument("--interval", type=float, default=1.0)
    args = parser.parse_args()

    signal.signal(signal.SIGTERM, hard_stop)
    signal.signal(signal.SIGINT, hard_stop)

    home = Path(args.home)
    cfg_dir = home / ".config/steam-machine-fan-profiles"
    config_path = cfg_dir / "config.json"
    status_path = cfg_dir / "status.json"

    names: dict[str, str] = {}
    aliases: dict[str, str] = {}
    ignored_runtime_ids: set[str] = set()
    next_catalog_scan = 0.0
    next_env_scan = 0.0
    env_safe = False
    env_reason = "waiting for stable system session"

    candidate_active: set[str] = set()
    candidate_since = time.monotonic()
    stable_active: set[str] = set()
    stable_initialized = False

    steam_present_last = False
    steam_present_since: Optional[float] = None
    steam_stable = False

    cfg = read_config(config_path)
    previous_automatic = cfg["automatic"]
    previous_exceptions = set(cfg["exceptions"])

    # A pending decision is only marked complete after the desired state is already
    # true or one bounded helper call succeeds. Unsafe session moments defer it.
    processed_signature = None
    pending_reason = "startup"
    last_helper_time = 0.0
    safe_paused = False
    error = ""
    note = "Safe service started. No fan command is run during service shutdown."

    while True:
        now = time.monotonic()

        if now >= next_catalog_scan:
            try:
                names, aliases, ignored_runtime_ids = build_catalog(home)
            except Exception:
                names, aliases, ignored_runtime_ids = {}, {}, set()
            next_catalog_scan = now + CATALOG_SCAN_SECONDS

        raw_ids, steam_present = read_proc_state(args.uid)
        raw_ids = {x for x in raw_ids if x not in ignored_runtime_ids}
        observed = {canonicalize_runtime_id(x, aliases) for x in raw_ids}

        if steam_present != steam_present_last:
            steam_present_last = steam_present
            steam_present_since = now if steam_present else None
            steam_stable = False
        elif steam_present and steam_present_since is not None:
            steam_stable = (now - steam_present_since) >= STEAM_STABLE_SECONDS
        else:
            steam_stable = False

        if observed != candidate_active:
            candidate_active = set(observed)
            candidate_since = now
        elif (not stable_initialized or candidate_active != stable_active) and (now - candidate_since) >= GAME_DEBOUNCE_SECONDS:
            stable_active = set(candidate_active)
            stable_initialized = True
            pending_reason = "game"

        cfg = read_config(config_path)
        automatic = bool(cfg["automatic"])
        exceptions = set(cfg["exceptions"])

        if automatic != previous_automatic:
            pending_reason = "config"
            previous_automatic = automatic
            # Turning automation back on explicitly clears an old safety pause.
            if automatic:
                safe_paused = False
                error = ""
        if exceptions != previous_exceptions:
            pending_reason = "config"
            previous_exceptions = set(exceptions)

        desired_on = desired_fan_state(automatic, stable_active if stable_initialized else set(), exceptions)
        signature = (
            automatic,
            tuple(sorted(stable_active)) if stable_initialized else ("<initializing>",),
            tuple(sorted(k for k in stable_active if k in exceptions)) if stable_initialized else (),
        )

        if now >= next_env_scan:
            env_safe, env_reason = system_is_safe_for_helper(args.uid)
            next_env_scan = now + ENVIRONMENT_SCAN_SECONDS

        current = systemctl_active()

        # If automation was disabled because a helper failed, do not perform any fan
        # operation until the user explicitly switches automation back on.
        if safe_paused and automatic:
            # Config may not have been persisted yet, keep this loop passive.
            set_automatic_false(config_path, cfg)
            automatic = False
            desired_on = True
            signature = (False, signature[1], signature[2])

        # A safety pause is deliberately sticky. While paused, no fan helper is
        # called at all. The only way to clear it is for the user to explicitly
        # turn Automatic Fan Profiles back ON in the GUI.
        if safe_paused and not automatic:
            processed_signature = signature
            note = "Automation paused for safety. No further fan commands will be attempted."

        needs_decision = (signature != processed_signature) and not safe_paused
        if needs_decision and stable_initialized:
            # A user-driven config change may run without Steam, but game-triggered
            # transitions wait until Steam has been continuously healthy for 12 sec.
            session_ok = env_safe and (pending_reason == "config" or steam_stable)
            interval_ok = (now - last_helper_time) >= MIN_HELPER_INTERVAL_SECONDS

            if current == desired_on:
                processed_signature = signature
                note = "Ready"
            elif session_ok and interval_ok and automatic:
                ok, err = apply_fan_state(desired_on)
                last_helper_time = time.monotonic()
                current = systemctl_active()
                if ok:
                    processed_signature = signature
                    error = ""
                    note = "Applied one fan-control transition."
                else:
                    # No retry loop. Persistently pause automation until user opts in again.
                    safe_paused = True
                    error = err
                    note = "Automation paused after one failed fan-control request."
                    set_automatic_false(config_path, cfg)
                    automatic = False
                    desired_on = True
                    processed_signature = None
            elif session_ok and interval_ok and not automatic:
                # If the user has just turned automation OFF, restore baseline ON once.
                # This is config-driven, bounded, and only happens on that transition.
                if pending_reason == "config" and current is False:
                    ok, err = apply_fan_state(True)
                    last_helper_time = time.monotonic()
                    current = systemctl_active()
                    if ok:
                        processed_signature = signature
                        error = ""
                        note = "Automation off. Updated Fan Control restored to ON."
                    else:
                        # Automation is already OFF. Do not retry. Report only.
                        processed_signature = signature
                        error = err
                        note = "Automation is off. Baseline restore failed once and will not retry."
                else:
                    processed_signature = signature
                    note = "Automation is off."
            else:
                if not env_safe:
                    note = f"Fan transition deferred: {env_reason}."
                elif pending_reason == "game" and not steam_stable:
                    note = "Fan transition deferred while Steam/session state settles."
                elif not interval_ok:
                    note = "Fan transition deferred by safety cooldown."

        active_sorted = sorted(stable_active) if stable_initialized else []
        active_names = [
            names.get(k, k.replace("steam:", "Steam App ").replace("shortcut:", "Non-Steam "))
            for k in active_sorted
        ]
        try:
            write_status(
                status_path,
                automatic=automatic,
                fan_on=current,
                active_keys=active_sorted,
                active_names=active_names,
                desired_on=desired_on,
                steam_stable=steam_stable,
                safe_paused=safe_paused,
                error=error,
                note=note,
            )
        except Exception:
            pass

        time.sleep(max(0.5, args.interval))


if __name__ == "__main__":
    sys.exit(main())
