#!/usr/bin/env python3
"""Desktop GUI for Steam Machine Fan Profiles.

Prefers GTK 3 when available on SteamOS. Falls back to Tkinter, then KDialog.
"""
from __future__ import annotations

import json
import os
import re
import struct
import subprocess
import sys
import time
from pathlib import Path

VERSION = "1.1.0"
HOME = Path.home()
CFG_DIR = HOME / ".config/steam-machine-fan-profiles"
CONFIG = CFG_DIR / "config.json"
STATUS = CFG_DIR / "status.json"

# Steam installs compatibility layers and shared runtimes as Steam apps too.
# They belong in the Tools/compatibility side of Steam, not in this per-game list.
# Name-based matching intentionally covers future Proton/runtime versions as well.
NON_GAME_COMPONENT_PATTERNS = (
    re.compile(r"^proton(?:\s|$)", re.I),
    re.compile(r"^steam linux runtime(?:\s|$|\()", re.I),
    re.compile(r"^steam runtime(?:\s|$|\()", re.I),
    re.compile(r"^steamworks common redistributables$", re.I),
    re.compile(r"^steamworks sdk redist(?:ributables)?(?:\s|$)", re.I),
    re.compile(r"^steam deck windows resources$", re.I),
)


def is_non_game_component(name: str) -> bool:
    clean = (name or "").strip()
    return any(p.search(clean) for p in NON_GAME_COMPONENT_PATTERNS)


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def atomic_write(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    os.replace(tmp, path)


def load_config():
    d = read_json(CONFIG, {"version": 2, "automatic": True, "exceptions": []})
    return {"version": 2, "automatic": bool(d.get("automatic", True)),
            "exceptions": [str(x) for x in d.get("exceptions", [])]}


def save_config(cfg):
    atomic_write(CONFIG, cfg)


def parse_text_vdf_paths(text: str):
    return [m.group(1).replace("\\\\", "\\") for m in re.finditer(r'"path"\s+"([^"]+)"', text, re.I)]


def steam_roots():
    out=[]; seen=set()
    for p in [HOME / ".local/share/Steam", HOME / ".steam/steam"]:
        try: rp=p.resolve()
        except Exception: rp=p
        if rp.exists() and str(rp) not in seen:
            seen.add(str(rp)); out.append(rp)
    return out


def library_paths():
    out=[]; seen=set()
    for root in steam_roots():
        if str(root) not in seen: seen.add(str(root)); out.append(root)
        try:
            txt=(root/"steamapps/libraryfolders.vdf").read_text(encoding="utf-8",errors="replace")
            for raw in parse_text_vdf_paths(txt):
                p=Path(raw)
                if p.exists() and str(p) not in seen: seen.add(str(p)); out.append(p)
        except Exception: pass
    return out


def parse_manifest(path):
    try: text=path.read_text(encoding="utf-8",errors="replace")
    except Exception: return None
    mid=re.search(r'"appid"\s+"([0-9]+)"',text); mn=re.search(r'"name"\s+"([^"]+)"',text)
    if not mid: return None
    return f"steam:{mid.group(1)}", (mn.group(1) if mn else f"Steam App {mid.group(1)}")


def read_cstring(data,pos):
    end=data.find(b"\x00",pos)
    if end<0: raise ValueError
    return data[pos:end].decode("utf-8",errors="replace"),end+1


def parse_bvdf(data,pos=0):
    obj={}
    while pos<len(data):
        t=data[pos]; pos+=1
        if t in (0x08,0x0B): return obj,pos
        key,pos=read_cstring(data,pos)
        if t==0x00: val,pos=parse_bvdf(data,pos)
        elif t==0x01: val,pos=read_cstring(data,pos)
        elif t==0x02: val=struct.unpack_from("<i",data,pos)[0]; pos+=4
        elif t==0x07: val=struct.unpack_from("<Q",data,pos)[0]; pos+=8
        elif t==0x0A: val=struct.unpack_from("<q",data,pos)[0]; pos+=8
        else: raise ValueError
        obj[key]=val
    return obj,pos


def scan_games():
    games={}
    for lib in library_paths():
        d=lib/"steamapps"
        if d.exists():
            for f in d.glob("appmanifest_*.acf"):
                it=parse_manifest(f)
                if it and not is_non_game_component(it[1]):
                    games[it[0]]={"name":it[1],"kind":"Steam"}
    seen=set()
    for root in steam_roots():
        u=root/"userdata"
        if not u.exists(): continue
        for f in u.glob("*/config/shortcuts.vdf"):
            try:
                parsed,_=parse_bvdf(f.read_bytes(),0); shortcuts=parsed.get("shortcuts",parsed)
                for val in shortcuts.values():
                    if not isinstance(val,dict): continue
                    aid=val.get("appid"); name=val.get("appname")
                    if isinstance(aid,int) and isinstance(name,str) and not is_non_game_component(name):
                        u32=aid & 0xffffffff; key=f"shortcut:{u32}"
                        if key not in seen:
                            seen.add(key); games[key]={"name":name,"kind":"Non-Steam"}
            except Exception: pass
    return dict(sorted(games.items(), key=lambda kv: kv[1]["name"].lower()))



# ---------------- GTK GUI ----------------
def run_gtk():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib, Gdk

    css = b"""
    window { background: #101722; color: #eef4ff; }
    .title { font-size: 26px; font-weight: 700; color: #f4f7fb; }
    .subtitle { font-size: 13px; color: #9eacc1; }
    .card { background: #172130; border: 1px solid #2a394d; border-radius: 12px; padding: 16px; }
    .section { font-size: 17px; font-weight: 700; color: #f1f5fb; }
    .muted { color: #9aa9be; }
    .green { color: #55d989; font-weight: 700; }
    .red { color: #ff7078; font-weight: 700; }
    .blue { color: #5da6ff; font-weight: 700; }
    button { background: #223044; color: #eef4ff; border: 1px solid #3a4d67; border-radius: 8px; padding: 8px 14px; }
    button:hover { background: #2b3b52; }
    button.suggested-action { background: #1677ee; border-color: #2f91ff; }
    entry { background: #101824; color: #eef4ff; border: 1px solid #3a4a60; border-radius: 8px; padding: 9px; }
    row { background: #121b28; border-bottom: 1px solid #263548; }
    switch:checked { background: #1677ee; }
    """
    provider=Gtk.CssProvider(); provider.load_from_data(css)
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    class App(Gtk.Window):
        def __init__(self):
            super().__init__(title="Steam Machine Fan Profiles")
            self.set_default_size(900, 650); self.set_border_width(18)
            self.cfg=load_config(); self.games={}; self.rows={}; self.syncing_auto=False
            self.connect("destroy", Gtk.main_quit)
            outer=Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14); self.add(outer)

            head=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            titles=Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
            t=Gtk.Label(label="Steam Machine Fan Profiles"); t.set_xalign(0); t.get_style_context().add_class("title")
            s=Gtk.Label(label=f"Automatic SteamOS fan switching   •   v{VERSION}"); s.set_xalign(0); s.get_style_context().add_class("subtitle")
            titles.pack_start(t,False,False,0); titles.pack_start(s,False,False,0); head.pack_start(titles,True,True,0)
            outer.pack_start(head,False,False,0)

            auto=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12); auto.get_style_context().add_class("card")
            at=Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            l=Gtk.Label(label="Automatic Fan Profiles"); l.set_xalign(0); l.get_style_context().add_class("section")
            sub=Gtk.Label(label="ON normally. OFF while games run, except games selected below."); sub.set_xalign(0); sub.get_style_context().add_class("muted")
            at.pack_start(l,False,False,0); at.pack_start(sub,False,False,0); auto.pack_start(at,True,True,0)
            self.auto_switch=Gtk.Switch(); self.auto_switch.set_active(self.cfg["automatic"]); self.auto_switch.set_valign(Gtk.Align.CENTER)
            self.auto_switch.connect("notify::active", self.on_auto); auto.pack_end(self.auto_switch,False,False,0)
            outer.pack_start(auto,False,False,0)

            status=Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=9); status.get_style_context().add_class("card")
            st=Gtk.Label(label="Current Status"); st.set_xalign(0); st.get_style_context().add_class("section"); status.pack_start(st,False,False,0)
            grid=Gtk.Grid(column_spacing=18,row_spacing=9)
            a=Gtk.Label(label="Enable Updated Fan Control:"); a.set_xalign(0); grid.attach(a,0,0,1,1)
            self.fan=Gtk.Label(label="Checking..."); self.fan.set_xalign(0); grid.attach(self.fan,1,0,1,1)
            b=Gtk.Label(label="Running game:"); b.set_xalign(0); grid.attach(b,0,1,1,1)
            self.running=Gtk.Label(label="None"); self.running.set_xalign(0); grid.attach(self.running,1,1,1,1)
            status.pack_start(grid,False,False,0)
            self.err=Gtk.Label(label=""); self.err.set_xalign(0); self.err.set_line_wrap(True); self.err.get_style_context().add_class("red"); status.pack_start(self.err,False,False,0)
            outer.pack_start(status,False,False,0)

            games_card=Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10); games_card.get_style_context().add_class("card")
            gl=Gtk.Label(label="Keep Enable Updated Fan Control ON for these games"); gl.set_xalign(0); gl.get_style_context().add_class("section"); games_card.pack_start(gl,False,False,0)
            gs=Gtk.Label(label="Checked games are exceptions. Unchecked games use the cooler default rule and turn Updated Fan Control OFF while playing."); gs.set_xalign(0); gs.set_line_wrap(True); gs.get_style_context().add_class("muted"); games_card.pack_start(gs,False,False,0)
            searchbox=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8)
            self.search=Gtk.SearchEntry(); self.search.set_placeholder_text("Search games..."); self.search.connect("search-changed",lambda *_: self.render_games()); searchbox.pack_start(self.search,True,True,0)
            rs=Gtk.Button(label="Rescan games"); rs.connect("clicked",lambda *_: self.rescan()); searchbox.pack_end(rs,False,False,0); games_card.pack_start(searchbox,False,False,0)
            sw=Gtk.ScrolledWindow(); sw.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC); sw.set_min_content_height(260)
            self.list=Gtk.ListBox(); self.list.set_selection_mode(Gtk.SelectionMode.NONE); sw.add(self.list); games_card.pack_start(sw,True,True,0)
            self.count=Gtk.Label(label=""); self.count.set_xalign(0); self.count.get_style_context().add_class("muted"); games_card.pack_start(self.count,False,False,0)
            outer.pack_start(games_card,True,True,0)

            footer=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8)
            save=Gtk.Button(label="Save"); save.get_style_context().add_class("suggested-action"); save.connect("clicked",lambda *_: self.do_save()); footer.pack_end(save,False,False,0)
            outer.pack_start(footer,False,False,0)
            self.rescan(); self.update_status(); GLib.timeout_add(1000,self.update_status)

        def on_auto(self, sw, _pspec):
            if self.syncing_auto:
                return
            self.cfg["automatic"]=sw.get_active(); save_config(self.cfg)

        def rescan(self):
            self.games=scan_games(); self.render_games()

        def clear_list(self):
            for child in self.list.get_children(): self.list.remove(child)
            self.rows={}

        def render_games(self):
            self.clear_list(); q=self.search.get_text().strip().lower(); ex=set(self.cfg["exceptions"])
            for key,meta in self.games.items():
                if q and q not in meta["name"].lower(): continue
                row=Gtk.ListBoxRow(); box=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=12); box.set_border_width(8)
                cb=Gtk.CheckButton(); cb.set_active(key in ex); cb.connect("toggled",self.on_toggle,key); box.pack_start(cb,False,False,0)
                name=Gtk.Label(label=meta["name"]); name.set_xalign(0); box.pack_start(name,True,True,0)
                kind=Gtk.Label(label=meta["kind"]); kind.get_style_context().add_class("muted"); box.pack_start(kind,False,False,0)
                status=Gtk.Label(label=("Keep ON" if key in ex else "Default OFF")); status.get_style_context().add_class("blue" if key in ex else "muted"); box.pack_end(status,False,False,0)
                row.add(box); self.list.add(row); self.rows[key]=(cb,status)
            self.list.show_all(); self.update_count()

        def on_toggle(self, cb, key):
            ex=set(self.cfg["exceptions"])
            if cb.get_active(): ex.add(key)
            else: ex.discard(key)
            self.cfg["exceptions"]=sorted(ex); self.update_count()
            st=self.rows.get(key,(None,None))[1]
            if st:
                st.set_text("Keep ON" if cb.get_active() else "Default OFF")

        def update_count(self):
            self.count.set_text(f"{len(self.cfg['exceptions'])} game exception(s) selected   •   New games automatically use Default OFF")

        def do_save(self):
            save_config(self.cfg)
            dlg=Gtk.MessageDialog(self,0,Gtk.MessageType.INFO,Gtk.ButtonsType.OK,"Saved")
            dlg.format_secondary_text("Your per-game fan-control exceptions have been saved."); dlg.run(); dlg.destroy()

        def update_status(self):
            st=read_json(STATUS,{})
            if st:
                on=bool(st.get("fan_control_on",False)); self.fan.set_text("ON" if on else "OFF")
                ctx=self.fan.get_style_context(); ctx.remove_class("green"); ctx.remove_class("red"); ctx.add_class("green" if on else "red")
                names=st.get("active_game_names") or []; self.running.set_text(", ".join(names) if names else "None")
                status_auto=bool(st.get("automatic", self.cfg.get("automatic", True)))
                if self.auto_switch.get_active() != status_auto:
                    self.syncing_auto=True
                    self.auto_switch.set_active(status_auto)
                    self.syncing_auto=False
                    self.cfg["automatic"]=status_auto
                err=st.get("error") or ""
                if st.get("safe_paused"):
                    self.err.set_text("Automation paused for safety. " + (err or "Turn Automatic Fan Profiles ON when you want to try again."))
                else:
                    self.err.set_text(err)
            else:
                self.fan.set_text("Service not responding"); self.running.set_text("None")
            return True

    w=App(); w.show_all(); Gtk.main(); return 0


# ---------------- Tk fallback ----------------
def run_tk():
    import tkinter as tk
    from tkinter import ttk, messagebox
    cfg=load_config(); games=scan_games(); filtered=list(games.keys())
    root=tk.Tk(); root.title("Steam Machine Fan Profiles"); root.geometry("880x650"); root.configure(bg="#101722")
    style=ttk.Style();
    try: style.theme_use("clam")
    except Exception: pass
    style.configure("TFrame",background="#101722"); style.configure("Card.TFrame",background="#172130")
    style.configure("TLabel",background="#101722",foreground="#eef4ff"); style.configure("Card.TLabel",background="#172130",foreground="#eef4ff")
    style.configure("TCheckbutton",background="#172130",foreground="#eef4ff")
    style.configure("TButton",padding=8)
    top=ttk.Frame(root); top.pack(fill="x",padx=18,pady=(16,8))
    ttk.Label(top,text="Steam Machine Fan Profiles",font=("Sans",20,"bold")).pack(anchor="w")
    ttk.Label(top,text=f"Automatic SteamOS fan switching   •   v{VERSION}").pack(anchor="w")
    card=ttk.Frame(root,style="Card.TFrame",padding=14); card.pack(fill="x",padx=18,pady=8)
    av=tk.BooleanVar(value=cfg["automatic"])
    def auto_changed(): cfg["automatic"]=av.get(); save_config(cfg)
    ttk.Checkbutton(card,text="Automatic Fan Profiles",variable=av,command=auto_changed).pack(side="left")
    ttk.Label(card,text="ON normally, OFF while games run unless selected below",style="Card.TLabel").pack(side="left",padx=20)
    stat=ttk.Frame(root,style="Card.TFrame",padding=14); stat.pack(fill="x",padx=18,pady=8)
    ttk.Label(stat,text="Current Status",style="Card.TLabel",font=("Sans",12,"bold")).grid(row=0,column=0,columnspan=2,sticky="w",pady=(0,8))
    ttk.Label(stat,text="Enable Updated Fan Control:",style="Card.TLabel").grid(row=1,column=0,sticky="w")
    fan=ttk.Label(stat,text="Checking...",style="Card.TLabel"); fan.grid(row=1,column=1,sticky="w",padx=12)
    ttk.Label(stat,text="Running game:",style="Card.TLabel").grid(row=2,column=0,sticky="w")
    run=ttk.Label(stat,text="None",style="Card.TLabel"); run.grid(row=2,column=1,sticky="w",padx=12)
    safety=ttk.Label(stat,text="",style="Card.TLabel"); safety.grid(row=3,column=0,columnspan=2,sticky="w",pady=(6,0))
    main=ttk.Frame(root,style="Card.TFrame",padding=14); main.pack(fill="both",expand=True,padx=18,pady=8)
    ttk.Label(main,text="Keep Enable Updated Fan Control ON for these games",style="Card.TLabel",font=("Sans",12,"bold")).pack(anchor="w")
    ttk.Label(main,text="Checked = Keep ON. Unchecked = Default OFF while playing.",style="Card.TLabel").pack(anchor="w",pady=(2,8))
    search=tk.StringVar(); ent=ttk.Entry(main,textvariable=search); ent.pack(fill="x",pady=(0,8))
    canvas=tk.Canvas(main,bg="#121b28",highlightthickness=0); scroll=ttk.Scrollbar(main,orient="vertical",command=canvas.yview); inner=ttk.Frame(canvas,style="Card.TFrame")
    inner_id=canvas.create_window((0,0),window=inner,anchor="nw"); canvas.configure(yscrollcommand=scroll.set)
    canvas.pack(side="left",fill="both",expand=True); scroll.pack(side="right",fill="y")
    vars={}
    def render(*_):
        for w in inner.winfo_children(): w.destroy()
        q=search.get().lower().strip(); ex=set(cfg["exceptions"])
        for key,meta in games.items():
            if q and q not in meta["name"].lower(): continue
            v=tk.BooleanVar(value=key in ex); vars[key]=v
            row=ttk.Frame(inner,style="Card.TFrame",padding=4); row.pack(fill="x")
            ttk.Checkbutton(row,variable=v).pack(side="left")
            ttk.Label(row,text=meta["name"],style="Card.TLabel").pack(side="left",fill="x",expand=True)
            ttk.Label(row,text=meta["kind"],style="Card.TLabel").pack(side="right",padx=10)
        inner.update_idletasks(); canvas.configure(scrollregion=canvas.bbox("all"))
    search.trace_add("write",render); render()
    def save():
        ex=set(cfg["exceptions"])
        for key,v in vars.items():
            if v.get(): ex.add(key)
            else: ex.discard(key)
        cfg["exceptions"]=sorted(ex); save_config(cfg); messagebox.showinfo("Saved","Your per-game exceptions have been saved.")
    bottom=ttk.Frame(root); bottom.pack(fill="x",padx=18,pady=(0,16)); ttk.Button(bottom,text="Save",command=save).pack(side="right")
    def poll():
        st=read_json(STATUS,{})
        if st:
            fan.configure(text="ON" if st.get("fan_control_on") else "OFF"); names=st.get("active_game_names") or []; run.configure(text=", ".join(names) if names else "None")
            status_auto=bool(st.get("automatic", av.get()))
            if av.get() != status_auto:
                av.set(status_auto); cfg["automatic"]=status_auto
            err=st.get("error") or ""
            safety.configure(text=(("Automation paused for safety. " + (err or "Turn Automatic Fan Profiles ON to try again.")) if st.get("safe_paused") else err))
        else:
            fan.configure(text="Service not responding"); safety.configure(text="")
        root.after(1000,poll)
    poll(); root.mainloop(); return 0


def run_kdialog():
    cfg=load_config(); games=scan_games(); args=[]; ex=set(cfg["exceptions"])
    for key,meta in games.items(): args += [key, meta["name"], "on" if key in ex else "off"]
    if not args:
        subprocess.run(["kdialog","--msgbox","No Steam games were found. The background service will still automatically handle games when launched."])
        return 0
    cp=subprocess.run(["kdialog","--title","Steam Machine Fan Profiles","--checklist","Keep Updated Fan Control ON for these games:"]+args,
                      stdout=subprocess.PIPE,text=True,check=False)
    if cp.returncode==0:
        # kdialog returns quoted item IDs separated by spaces.
        import shlex
        cfg["exceptions"]=sorted(shlex.split(cp.stdout.strip())); save_config(cfg)
        subprocess.run(["kdialog","--msgbox","Saved."])
    return 0


def main():
    try:
        import gi
        gi.require_version("Gtk","3.0")
        return run_gtk()
    except Exception as gtk_exc:
        try:
            import tkinter
            return run_tk()
        except Exception as tk_exc:
            if shutil_which("kdialog"):
                return run_kdialog()
            print("Could not start GUI. GTK error:",gtk_exc,"Tk error:",tk_exc,file=sys.stderr)
            return 1


def shutil_which(name):
    from shutil import which
    return which(name)

if __name__=="__main__":
    raise SystemExit(main())
