#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# AnkerGames -> JDownloader 2 FULL setup for SteamOS/Linux
# Version: 2.2 - native JDownloader extraction + Create Subfolder
#
# One complete installer:
#   * On-demand localhost bridge (no permanent Python process)
#   * Automatic JDownloader LinkCrawler rules
#   * Downloads archives directly into ~/Downloads
#   * Extraction is performed ONLY by JDownloader's Archive Extractor
#   * JDownloader controls the archive-deletion preference
#   * No independent extraction helper is started after download
#   * Removes old experimental AnkerGames Event Scripter rules
#
# Uninstall everything installed by this script:
#   bash AnkerGames_JDownloader_v2.2_Full_Uninstaller.sh
# ============================================================

APP_DIR="$HOME/.local/share/ankergames-jd-bridge"
VENV_DIR="$APP_DIR/.venv"
BRIDGE_PY="$APP_DIR/bridge.py"
STATE_FILE="$APP_DIR/full-setup-state.json"
BACKUP_DIR="$APP_DIR/config-backups"

SYSTEMD_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.service"
SOCKET_FILE="$SYSTEMD_DIR/ankergames-jd-bridge.socket"
SERVICE_NAME="ankergames-jd-bridge.service"
SOCKET_NAME="ankergames-jd-bridge.socket"
PORT="17892"

JD_LINK_RULES_NAME="jd.controlling.linkcrawler.LinkCrawlerConfig.linkcrawlerrules.json"
JD_LINK_MAIN_NAME="jd.controlling.linkcrawler.LinkCrawlerConfig.json"
JD_PACK_RULES_NAME="org.jdownloader.controlling.packagizer.PackagizerSettings.rulelist.json"
JD_EVENT_SCRIPTS_NAME="org.jdownloader.extensions.eventscripter.EventScripterExtension.scripts.json"
JD_LINKGRABBER_SETTINGS_NAME="org.jdownloader.gui.views.linkgrabber.addlinksdialog.LinkgrabberSettings.json"
JD_EXTRACTION_SETTINGS_NAME="org.jdownloader.extensions.extraction.ExtractionExtension.json"

RULE_NAME_REWRITE="AnkerGames to JD Bridge"
RULE_NAME_DIRECT="AnkerGames JD Bridge DirectHTTP"

echo
echo "============================================================"
echo " AnkerGames JDownloader v2.2 - Full Setup"
echo "============================================================"
echo

find_jd_cfg_dir() {
    local f=""

    # Prefer the config folder which already contains our known JD files.
    for filename in \
        "$JD_LINK_RULES_NAME" \
        "$JD_PACK_RULES_NAME" \
        "$JD_EVENT_SCRIPTS_NAME"
    do
        while IFS= read -r f; do
            [[ -n "$f" ]] || continue
            dirname "$f"
            return 0
        done < <(
            find "$HOME" -maxdepth 10 -type f -name "$filename" \
                -printf '%T@ %p\n' 2>/dev/null | sort -nr | cut -d' ' -f2-
        )
    done

    # Common Linux / SteamOS paths.
    local d
    for d in \
        "$HOME/.var/app/org.jdownloader.JDownloader/data/jdownloader/cfg" \
        "$HOME/.var/app/org.jdownloader.JDownloader/data/JDownloader/cfg" \
        "$HOME/.jd/cfg" \
        "$HOME/JDownloader/cfg" \
        "$HOME/JDownloader2/cfg" \
        "$HOME/.local/share/JDownloader/cfg"
    do
        if [[ -d "$d" ]]; then
            printf '%s\n' "$d"
            return 0
        fi
    done

    return 1
}

jdownloader_is_running() {
    pgrep -af \
        'java.*JDownloader|JDownloader\.jar|org\.jdownloader\.update|org\.jdownloader\.launcher' \
        >/dev/null 2>&1
}

restore_packagizer_state() {
    local cfg_dir="$1"
    local pack_rules="$cfg_dir/$JD_PACK_RULES_NAME"

    [[ -f "$STATE_FILE" && -f "$pack_rules" ]] || return 0

    STATE_FILE="$STATE_FILE" PACK_RULES="$pack_rules" python3 <<'PY'
import json
import os
from pathlib import Path

state_path = Path(os.environ["STATE_FILE"])
pack_path = Path(os.environ["PACK_RULES"])

try:
    state = json.loads(state_path.read_text(encoding="utf-8"))
    rules = json.loads(pack_path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(rules, list):
    raise SystemExit(0)

if state.get("subfolder_rule_found"):
    old_enabled = bool(state.get("subfolder_rule_original_enabled"))
    changed = False
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        rid = str(rule.get("id") or "")
        name = str(rule.get("name") or "")
        if rid == "SubFolderByPackageRule" or name == "Create Subfolder by Packagename":
            rule["enabled"] = old_enabled
            changed = True

    if changed:
        tmp = pack_path.with_suffix(pack_path.suffix + ".tmp")
        tmp.write_text(
            json.dumps(rules, ensure_ascii=False, separators=(",", ":")) + "\n",
            encoding="utf-8",
        )
        os.replace(tmp, pack_path)
        print("Restored JDownloader's original package-subfolder setting.")
PY
}

restore_linkgrabber_various_setting() {
    local cfg_dir="$1"
    local linkgrabber_settings="$cfg_dir/$JD_LINKGRABBER_SETTINGS_NAME"

    [[ -f "$STATE_FILE" ]] || return 0

    STATE_FILE="$STATE_FILE" LINKGRABBER_SETTINGS="$linkgrabber_settings" python3 <<'PY_LG_RESTORE'
import json
import os
from pathlib import Path

state_path = Path(os.environ["STATE_FILE"])
p = Path(os.environ["LINKGRABBER_SETTINGS"])

try:
    state = json.loads(state_path.read_text(encoding="utf-8"))
except (OSError, UnicodeError, json.JSONDecodeError):
    raise SystemExit("WARNING: Could not read original LinkGrabber state; leaving the setting unchanged.")

# Older v1.9 setups did not track this setting.
if state.get("variouspackage_previous_value_captured") is not True:
    raise SystemExit(0)

try:
    data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
except (OSError, UnicodeError, json.JSONDecodeError):
    raise SystemExit("WARNING: Current LinkGrabber settings are invalid; leaving the file unchanged.")

if not isinstance(data, dict):
    raise SystemExit("WARNING: Current LinkGrabber settings are not an object; leaving unchanged.")

# Restore just the original value or remove the key if it did not exist.
if state.get("variouspackage_key_existed_before_install"):
    data["variouspackageenabled"] = state["variouspackage_previous_value"]
else:
    data.pop("variouspackageenabled", None)

# A file generated solely by this installer can be deleted if it is now
# empty; never delete a file that contains any other JD preferences.
if not data and not state.get("linkgrabber_settings_file_existed_before_install"):
    p.unlink(missing_ok=True)
else:
    p.parent.mkdir(parents=True, exist_ok=True)
    temp = p.with_suffix(p.suffix + ".tmp")
    temp.write_text(
        json.dumps(data, ensure_ascii=False, indent=1) + "\n",
        encoding="utf-8",
    )
    os.replace(temp, p)

print("Restored native JDownloader 'Various Files' setting to its previous value.")
PY_LG_RESTORE
}

restore_archive_extractor_subfolder_setting() {
    local cfg_dir="$1"
    local extraction_settings="$cfg_dir/$JD_EXTRACTION_SETTINGS_NAME"

    [[ -f "$STATE_FILE" ]] || return 0

    STATE_FILE="$STATE_FILE" EXTRACTION_SETTINGS="$extraction_settings" python3 <<'PY_EXTRACT_RESTORE'
import json
import os
from pathlib import Path

state_path = Path(os.environ["STATE_FILE"])
p = Path(os.environ["EXTRACTION_SETTINGS"])

try:
    state = json.loads(state_path.read_text(encoding="utf-8"))
except (OSError, UnicodeError, json.JSONDecodeError):
    raise SystemExit("WARNING: Cannot read original Archive Extractor state; leaving it unchanged.")

# No prior captured state = do not change the user's own extractor settings.
if state.get("extractor_subpath_original_captured") is not True:
    raise SystemExit(0)

try:
    data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
except (OSError, UnicodeError, json.JSONDecodeError):
    raise SystemExit("WARNING: Archive Extractor settings are invalid; leaving them unchanged.")

if not isinstance(data, dict):
    raise SystemExit("WARNING: Archive Extractor settings are not a JSON object; leaving them unchanged.")

# Restore only this one switch and keep every unrelated JD preference.
if state.get("extractor_subpath_key_existed_before_install"):
    data["subpathenabled"] = state["extractor_subpath_previous_value"]
else:
    data.pop("subpathenabled", None)

if not data and not state.get("extractor_settings_file_existed_before_install"):
    p.unlink(missing_ok=True)
else:
    p.parent.mkdir(parents=True, exist_ok=True)
    temp = p.with_suffix(p.suffix + ".tmp")
    temp.write_text(
        json.dumps(data, ensure_ascii=False, indent=1) + "\n",
        encoding="utf-8",
    )
    os.replace(temp, p)

print("Restored JDownloader Archive Extractor 'Create Subfolder' to its previous value.")
PY_EXTRACT_RESTORE
}

remove_our_jd_rules() {
    local cfg_dir="$1"
    local link_rules="$cfg_dir/$JD_LINK_RULES_NAME"
    local event_scripts="$cfg_dir/$JD_EVENT_SCRIPTS_NAME"

    if [[ -f "$link_rules" ]]; then
        LINK_RULES="$link_rules" python3 <<'PY'
import json
import os
from pathlib import Path

p = Path(os.environ["LINK_RULES"])
try:
    data = json.loads(p.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(data, list):
    raise SystemExit(0)

names = {
    "AnkerGames to JD Bridge",
    "AnkerGames to JD Bridge - Current Format",
    "AnkerGames to JD Bridge - New Format",
    "AnkerGames to JD Bridge - Legacy Format",
    "AnkerGames JD Bridge DirectHTTP",
}

cleaned = []
for item in data:
    if isinstance(item, dict):
        name = str(item.get("name") or "")
        pattern = str(item.get("pattern") or "")
        if name in names:
            continue
        if "AnkerGames" in name and (
            "dlproxy" in pattern or "127\\.0\\.0\\.1:17892" in pattern
        ):
            continue
    cleaned.append(item)

tmp = p.with_suffix(p.suffix + ".tmp")
tmp.write_text(
    json.dumps(cleaned, ensure_ascii=False, indent=1) + "\n",
    encoding="utf-8",
)
os.replace(tmp, p)
PY
    fi

    # Remove only our old experimental Event Scripter entries.
    if [[ -f "$event_scripts" ]]; then
        EVENT_SCRIPTS="$event_scripts" python3 <<'PY'
import json
import os
from pathlib import Path

p = Path(os.environ["EVENT_SCRIPTS"])
try:
    data = json.loads(p.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

if not isinstance(data, list):
    raise SystemExit(0)

names = {
    "AnkerGames Download Folder",
    "AnkerGames Force Extract",
    "AnkerGames Actual Package Folder",
    "AnkerGames Archive Fallback",
    "AnkerGames Package Name = Archive Name",
    "AnkerGames REAL Package Name = Archive Name",
    "AnkerGames LinkGrabber Package = Archive Name",
    "AnkerGames Downloads Package = Archive Name",
}

cleaned = [
    item for item in data
    if not (
        isinstance(item, dict)
        and str(item.get("name") or "") in names
    )
]

tmp = p.with_suffix(p.suffix + ".tmp")
tmp.write_text(
    json.dumps(cleaned, ensure_ascii=False, indent=1) + "\n",
    encoding="utf-8",
)
os.replace(tmp, p)
PY
    fi
}

uninstall_all() {
    if jdownloader_is_running; then
        echo "JDownloader 2 is still running."
        echo "Close JDownloader completely, then run:"
        echo "  bash \"$0\" --uninstall"
        exit 1
    fi

    local cfg_dir=""
    cfg_dir="$(find_jd_cfg_dir || true)"

    if [[ -n "$cfg_dir" ]]; then
        restore_packagizer_state "$cfg_dir" || true
        restore_linkgrabber_various_setting "$cfg_dir" || true
        restore_archive_extractor_subfolder_setting "$cfg_dir" || true
        remove_our_jd_rules "$cfg_dir" || true
    fi

    systemctl --user disable --now "$SOCKET_NAME" >/dev/null 2>&1 || true
    systemctl --user disable --now "$SERVICE_NAME" >/dev/null 2>&1 || true
    rm -f "$SOCKET_FILE" "$SERVICE_FILE"
    systemctl --user daemon-reload >/dev/null 2>&1 || true
    systemctl --user reset-failed "$SERVICE_NAME" >/dev/null 2>&1 || true

    rm -rf "$APP_DIR"

    echo
    echo "AnkerGames JDownloader integration removed."
    echo "Unrelated JDownloader settings/rules were preserved."
    exit 0
}

if [[ "${1:-}" == "--uninstall" ]]; then
    uninstall_all
fi

if jdownloader_is_running; then
    echo "JDownloader 2 is still running."
    echo
    echo "CLOSE JDownloader completely before installing."
    echo "JDownloader keeps configuration in memory and may overwrite changes on exit."
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "ERROR: python3 was not found."
    exit 1
fi

if ! python3 -m venv --help >/dev/null 2>&1; then
    echo "ERROR: Python venv support was not found."
    exit 1
fi

CFG_DIR="$(find_jd_cfg_dir || true)"
if [[ -z "$CFG_DIR" ]]; then
    echo "ERROR: Could not find JDownloader's cfg folder."
    echo
    echo "Open JDownloader once, then close it completely and run this script again."
    exit 1
fi

LINK_RULES="$CFG_DIR/$JD_LINK_RULES_NAME"
LINK_MAIN="$CFG_DIR/$JD_LINK_MAIN_NAME"
PACK_RULES="$CFG_DIR/$JD_PACK_RULES_NAME"
EVENT_SCRIPTS="$CFG_DIR/$JD_EVENT_SCRIPTS_NAME"
LINKGRABBER_SETTINGS="$CFG_DIR/$JD_LINKGRABBER_SETTINGS_NAME"
EXTRACTION_SETTINGS="$CFG_DIR/$JD_EXTRACTION_SETTINGS_NAME"

mkdir -p "$APP_DIR" "$SYSTEMD_DIR" "$BACKUP_DIR"

STAMP="$(date +%Y%m%d-%H%M%S)"
THIS_BACKUP="$BACKUP_DIR/$STAMP"
mkdir -p "$THIS_BACKUP"

for f in "$LINK_RULES" "$LINK_MAIN" "$PACK_RULES" "$EVENT_SCRIPTS" "$LINKGRABBER_SETTINGS" "$EXTRACTION_SETTINGS"; do
    if [[ -f "$f" ]]; then
        cp -a "$f" "$THIS_BACKUP/$(basename "$f")"
    fi
done

echo "JDownloader cfg:"
echo "  $CFG_DIR"
echo
echo "Backup:"
echo "  $THIS_BACKUP"
echo
# Confirm the native LinkGrabber settings can be safely modified without
# discarding other JDownloader preferences.
LINKGRABBER_SETTINGS="$LINKGRABBER_SETTINGS" python3 <<'PY_LG_PRECHECK'
import json
import os
from pathlib import Path
p = Path(os.environ["LINKGRABBER_SETTINGS"])
if p.exists():
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise SystemExit(f"ERROR: Refusing to overwrite invalid LinkGrabber settings: {exc}")
    if not isinstance(data, dict):
        raise SystemExit("ERROR: LinkGrabber settings file is not a JSON object; refusing overwrite.")
PY_LG_PRECHECK

# Validate Archive Extractor JSON before stopping the existing bridge or
# writing configuration. Never silently overwrite unreadable JD preferences.
EXTRACTION_SETTINGS="$EXTRACTION_SETTINGS" python3 <<'PY_EXTRACT_PRECHECK'
import json
import os
from pathlib import Path
p = Path(os.environ["EXTRACTION_SETTINGS"])
if p.exists():
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise SystemExit(f"ERROR: Refusing to overwrite invalid Archive Extractor settings: {exc}")
    if not isinstance(data, dict):
        raise SystemExit("ERROR: Archive Extractor settings are not a JSON object; refusing overwrite.")
PY_EXTRACT_PRECHECK


# Stop all old variants before replacing them.
systemctl --user disable --now "$SERVICE_NAME" >/dev/null 2>&1 || true
systemctl --user disable --now "$SOCKET_NAME" >/dev/null 2>&1 || true

# ------------------------------------------------------------
# Private Python environment
# ------------------------------------------------------------
# SteamOS can update its system Python while an older virtual environment
# remains on disk. In that case bin/python may still exist while pip inside
# the venv is gone/broken. Older installers only checked for bin/python, which
# is exactly what caused the v1.2 installer to stop with "No module named pip".
VENV_REBUILD=0

if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    VENV_REBUILD=1
elif ! "$VENV_DIR/bin/python" -c 'import sys, ssl; print(sys.version)' >/dev/null 2>&1; then
    VENV_REBUILD=1
elif ! "$VENV_DIR/bin/python" -m pip --version >/dev/null 2>&1; then
    echo "Existing private Python environment has no working pip; rebuilding it..."
    VENV_REBUILD=1
fi

if [[ "$VENV_REBUILD" -eq 1 ]]; then
    echo "Creating a fresh private Python environment..."
    rm -rf "$VENV_DIR"
    python3 -m venv "$VENV_DIR"
fi

# venv normally installs pip automatically. If the distro left it out, try
# CPython's bundled ensurepip before giving a clear error.
if ! "$VENV_DIR/bin/python" -m pip --version >/dev/null 2>&1; then
    echo "pip is missing inside the new environment; trying ensurepip..."
    "$VENV_DIR/bin/python" -m ensurepip --upgrade >/dev/null 2>&1 || true
fi

if ! "$VENV_DIR/bin/python" -m pip --version >/dev/null 2>&1; then
    echo
    echo "ERROR: Could not create a private Python environment with pip."
    echo "Nothing further was installed."
    echo "Python in use: $(python3 --version 2>&1)"
    echo
    exit 1
fi

echo "Private Python environment: OK"
echo "Installing/updating bridge dependencies..."

PIP_DISABLE_PIP_VERSION_CHECK=1 "$VENV_DIR/bin/python" -m pip install -q --upgrade \
    'pip>=23'

PIP_DISABLE_PIP_VERSION_CHECK=1 "$VENV_DIR/bin/python" -m pip install -q \
    'httpx>=0.27,<1'

# Only httpx is needed. JDownloader itself handles archives and extraction.
"$VENV_DIR/bin/python" - <<'PY'
import httpx
print("Bridge dependencies: OK")
PY

# Remove the previous version's Python extraction helper (if installed).
# No future archive extraction can be started by this setup.
rm -f "$APP_DIR/postprocess_after_jd.py"

# ------------------------------------------------------------
# On-demand bridge
# ------------------------------------------------------------
cat > "$BRIDGE_PY" <<'PYBRIDGE'
from __future__ import annotations

import os
import re
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlsplit

import httpx

HOST_RE = re.compile(r"^tunnel\d+\.dlproxy\.uk$", re.I)

PORT = 17892
MIB = 1024 * 1024
CHUNK = 1024 * 1024
MAX_RETRIES = 6
IDLE_SECONDS = 45.0
CACHE_SECONDS = 15 * 60

RETRYABLE = {
    408, 425, 429,
    500, 502, 503, 504,
    520, 521, 522, 523, 524,
}

BASE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/128.0 Safari/537.36"
    ),
    "Accept": "*/*",
    "Accept-Encoding": "identity",
}

_cache_lock = threading.Lock()
_meta_cache: dict[str, tuple[float, dict]] = {}


def parse_content_range(value: str | None):
    if not value:
        return None

    m = re.match(
        r"^\s*bytes\s+(\d+)-(\d+)/(\d+|\*)\s*$",
        value,
        re.I,
    )

    if not m:
        return None

    start = int(m.group(1))
    end = int(m.group(2))
    total = None if m.group(3) == "*" else int(m.group(3))

    if end < start:
        return None

    return start, end, total


def sniff_extension(data: bytes) -> str:
    head = bytes(data or b"")

    if head.startswith((
        b"Rar!\x1a\x07\x01\x00",
        b"Rar!\x1a\x07\x00",
    )):
        return "rar"

    if head.startswith((
        b"PK\x03\x04",
        b"PK\x05\x06",
        b"PK\x07\x08",
    )):
        return "zip"

    if head.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "7z"

    return "bin"


def clean_filename(value: str | None, fallback: str) -> str:
    name = unquote(str(value or "")).strip().strip("\"'")
    name = name.replace("\\", "/").split("/")[-1].strip()
    name = re.sub(r"[\x00-\x1f\x7f/\\]+", "_", name).strip(" .")

    if not name or name in (".", ".."):
        return fallback

    return name[:220]


def filename_from_content_disposition(value: str | None) -> str | None:
    if not value:
        return None

    m = re.search(
        r"(?i)(?:^|;)\s*filename\*\s*=\s*"
        r"(?:UTF-8''|utf-8'[^']*')?([^;]+)",
        value,
    )

    if m:
        name = clean_filename(m.group(1).strip().strip("\"'"), "")
        if name:
            return name

    m = re.search(
        r'(?i)(?:^|;)\s*filename\s*=\s*"([^"]+)"',
        value,
    )

    if not m:
        m = re.search(
            r"(?i)(?:^|;)\s*filename\s*=\s*([^;]+)",
            value,
        )

    if m:
        name = clean_filename(m.group(1).strip(), "")
        if name:
            return name

    return None


def make_client():
    timeout = httpx.Timeout(
        connect=30.0,
        read=None,
        write=30.0,
        pool=30.0,
    )

    return httpx.Client(
        follow_redirects=True,
        timeout=timeout,
        headers=BASE_HEADERS,
        http2=False,
    )


def retry_delay(response: httpx.Response | None, attempt: int) -> float:
    if response is not None:
        try:
            retry_after = float(
                response.headers.get("Retry-After", "")
            )
            if retry_after >= 0:
                return min(max(retry_after, 0.25), 12.0)
        except Exception:
            pass

    return min(
        0.5 * (2 ** max(0, attempt)),
        5.0,
    )


def get_target(path: str) -> str | None:
    parsed = urlsplit(path)

    # JDownloader rewrite form.
    #
    # Legacy:
    #   /download/<token>?sig=<signature>
    #
    # Current:
    #   /download/ag1.<payload>.<signature>
    #
    # Current links carry the signature inside the path and therefore do not
    # have a separate ?sig= query parameter.
    if parsed.path == "/AnkerGames-download.bin":
        qs = parse_qs(parsed.query, keep_blank_values=True)

        host = (qs.get("host") or [""])[0]
        token = (qs.get("token") or [""])[0]
        sig = (qs.get("sig") or [""])[0]

        if not HOST_RE.fullmatch(host):
            return None

        # Dots are needed for the current ag1.<payload>.<signature> token.
        if not re.fullmatch(r"[A-Za-z0-9._-]+", token):
            return None

        if sig:
            if not re.fullmatch(r"[A-Za-z0-9_-]+", sig):
                return None
            return f"https://{host}/download/{token}?sig={sig}"

        return f"https://{host}/download/{token}"

    # Backward-compatible local bridge path form.
    clean_path = parsed.path.lstrip("/")

    if "/" not in clean_path:
        return None

    host, rest = clean_path.split("/", 1)

    if not HOST_RE.fullmatch(host):
        return None

    if not rest.startswith("download/"):
        return None

    target = f"https://{host}/{rest}"

    if parsed.query:
        target += "?" + parsed.query

    return target

def probe_target(target: str) -> dict:
    now = time.monotonic()

    with _cache_lock:
        cached = _meta_cache.get(target)

        if cached and now - cached[0] < CACHE_SECONDS:
            return dict(cached[1])

    last_error = None

    with make_client() as client:
        for attempt in range(MAX_RETRIES):
            try:
                headers = {
                    "Range": f"bytes=0-{MIB - 1}",
                    "Accept-Encoding": "identity",
                }

                with client.stream(
                    "GET",
                    target,
                    headers=headers,
                ) as response:
                    status = int(response.status_code)

                    if status in RETRYABLE:
                        last_error = (
                            f"HTTP {status} "
                            f"{response.reason_phrase}"
                        )
                        time.sleep(
                            retry_delay(response, attempt)
                        )
                        continue

                    if status >= 400:
                        body = b""

                        try:
                            body = next(
                                response.iter_raw(
                                    chunk_size=4096
                                ),
                                b"",
                            )[:512]
                        except Exception:
                            pass

                        detail = (
                            body.decode(
                                "utf-8",
                                "replace",
                            )
                            .replace("\n", " ")
                            [:300]
                        )

                        raise RuntimeError(
                            f"upstream HTTP {status}: "
                            f"{detail}"
                        )

                    total = None
                    content_range = parse_content_range(
                        response.headers.get(
                            "Content-Range"
                        )
                    )

                    if content_range and content_range[2]:
                        total = content_range[2]

                    elif status == 200:
                        length = response.headers.get(
                            "Content-Length"
                        )

                        if (
                            response.headers
                            .get("Accept-Ranges", "")
                            .lower()
                            == "bytes"
                            and length
                            and length.isdigit()
                        ):
                            total = int(length)

                    first_chunk = b""

                    try:
                        first_chunk = next(
                            response.iter_raw(
                                chunk_size=4096
                            ),
                            b"",
                        )
                    except Exception:
                        pass

                    extension = sniff_extension(first_chunk)

                    upstream_cd = response.headers.get(
                        "Content-Disposition"
                    )

                    filename = (
                        filename_from_content_disposition(
                            upstream_cd
                        )
                    )

                    if filename:
                        if (
                            "." not in filename
                            and extension != "bin"
                        ):
                            filename = (
                                f"{filename}.{extension}"
                            )
                    else:
                        filename = (
                            f"AnkerGames-download."
                            f"{extension}"
                        )

                    filename = clean_filename(
                        filename,
                        f"AnkerGames-download."
                        f"{extension}",
                    )

                    safe_cd_name = filename.replace(
                        '"',
                        "_",
                    )

                    meta = {
                        "total": total,
                        "filename": filename,
                        "content_type": (
                            response.headers.get(
                                "Content-Type"
                            )
                            or "application/octet-stream"
                        ),
                        "content_disposition": (
                            f'attachment; '
                            f'filename="{safe_cd_name}"'
                        ),
                        "last_modified": (
                            response.headers.get(
                                "Last-Modified"
                            )
                        ),
                        "etag": response.headers.get(
                            "ETag"
                        ),
                        "final_url": str(response.url),
                    }

                    with _cache_lock:
                        _meta_cache[target] = (
                            time.monotonic(),
                            dict(meta),
                        )

                    return meta

            except (
                httpx.RequestError,
                RuntimeError,
            ) as exc:
                last_error = str(exc)

                if (
                    isinstance(exc, RuntimeError)
                    and "upstream HTTP 4"
                    in str(exc)
                ):
                    raise

                if attempt + 1 < MAX_RETRIES:
                    time.sleep(
                        min(
                            0.5 * (2 ** attempt),
                            5.0,
                        )
                    )

    raise RuntimeError(
        last_error
        or "could not probe upstream file"
    )


def parse_client_range(
    value: str | None,
    total: int,
):
    if not value:
        return 0, total - 1, False

    value = value.strip()

    m = re.fullmatch(
        r"bytes=(\d*)-(\d*)",
        value,
        re.I,
    )

    if not m:
        raise ValueError(
            "unsupported Range header"
        )

    left, right = m.group(1), m.group(2)

    if not left and not right:
        raise ValueError("invalid Range header")

    if left:
        start = int(left)
        end = int(right) if right else total - 1
    else:
        suffix = int(right)

        if suffix <= 0:
            raise ValueError(
                "invalid suffix range"
            )

        start = max(
            0,
            total - suffix,
        )
        end = total - 1

    if (
        start < 0
        or start >= total
        or end < start
    ):
        raise ValueError(
            "range outside file"
        )

    end = min(
        end,
        total - 1,
    )

    return start, end, True


def stream_exact(
    target: str,
    start: int,
    end: int,
    out,
) -> None:
    cursor = start
    continuations = 0
    no_progress = 0

    with make_client() as client:
        while cursor <= end:
            before = cursor
            opened = False

            for attempt in range(MAX_RETRIES):
                response_ctx = None

                try:
                    headers = {
                        "Range": (
                            f"bytes={cursor}-{end}"
                        ),
                        "Accept-Encoding": "identity",
                    }

                    response_ctx = client.stream(
                        "GET",
                        target,
                        headers=headers,
                    )

                    response = (
                        response_ctx.__enter__()
                    )

                    status = int(
                        response.status_code
                    )

                    if status in RETRYABLE:
                        response_ctx.__exit__(
                            None,
                            None,
                            None,
                        )
                        response_ctx = None

                        time.sleep(
                            retry_delay(
                                response,
                                attempt,
                            )
                        )
                        continue

                    response.raise_for_status()

                    content_range = parse_content_range(
                        response.headers.get(
                            "Content-Range"
                        )
                    )

                    if (
                        status != 206
                        or not content_range
                        or content_range[0]
                        != cursor
                    ):
                        if response_ctx is not None:
                            response_ctx.__exit__(
                                None,
                                None,
                                None,
                            )

                        raise RuntimeError(
                            "upstream did not honor "
                            f"byte range at {cursor} "
                            f"(HTTP {status})"
                        )

                    opened = True

                    try:
                        for chunk in response.iter_raw(
                            chunk_size=CHUNK
                        ):
                            if not chunk:
                                continue

                            remaining = (
                                end - cursor + 1
                            )

                            if remaining <= 0:
                                break

                            if len(chunk) > remaining:
                                chunk = chunk[
                                    :remaining
                                ]

                            out.write(chunk)
                            cursor += len(chunk)

                            if cursor > end:
                                break
                    finally:
                        response_ctx.__exit__(
                            None,
                            None,
                            None,
                        )

                    break

                except (
                    BrokenPipeError,
                    ConnectionResetError,
                ):
                    raise

                except httpx.RequestError:
                    if response_ctx is not None:
                        try:
                            response_ctx.__exit__(
                                *sys.exc_info()
                            )
                        except Exception:
                            pass

                    if attempt + 1 >= MAX_RETRIES:
                        raise

                    time.sleep(
                        min(
                            0.25 * (attempt + 1),
                            1.0,
                        )
                    )

            if not opened and cursor == before:
                raise RuntimeError(
                    "could not open upstream "
                    f"range at byte {cursor}"
                )

            if cursor == before:
                no_progress += 1

                if no_progress >= 4:
                    raise RuntimeError(
                        "upstream returned no "
                        f"data at byte {cursor}"
                    )
            else:
                no_progress = 0

            if cursor <= end:
                continuations += 1

                if continuations > 512:
                    raise RuntimeError(
                        "too many upstream "
                        "continuation requests"
                    )


class BridgeHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = (
        "AnkerGamesJD-Bridge/2.2-jd-native"
    )

    def setup(self):
        super().setup()
        self.server.connection_opened()

    def finish(self):
        try:
            super().finish()
        finally:
            self.server.connection_closed()

    def log_message(self, fmt, *args):
        sys.stderr.write(
            "[AnkerGamesJD] "
            + (fmt % args)
            + "\n"
        )

    def _send_text(
        self,
        status: int,
        text: str,
    ):
        data = text.encode(
            "utf-8",
            "replace",
        )

        self.send_response(status)
        self.send_header(
            "Content-Type",
            "text/plain; charset=utf-8",
        )
        self.send_header(
            "Content-Length",
            str(len(data)),
        )
        self.send_header(
            "Connection",
            "close",
        )
        self.end_headers()

        if self.command != "HEAD":
            self.wfile.write(data)

    def _send_common_headers(
        self,
        meta: dict,
    ):
        self.send_header(
            "Content-Type",
            meta.get("content_type")
            or "application/octet-stream",
        )

        self.send_header(
            "Accept-Ranges",
            "bytes",
        )

        if meta.get(
            "content_disposition"
        ):
            self.send_header(
                "Content-Disposition",
                meta[
                    "content_disposition"
                ],
            )

        if meta.get("last_modified"):
            self.send_header(
                "Last-Modified",
                meta["last_modified"],
            )

        if meta.get("etag"):
            self.send_header(
                "ETag",
                meta["etag"],
            )

        self.send_header(
            "Cache-Control",
            "no-store",
        )

    def do_HEAD(self):
        if self.path == "/health":
            self._send_text(
                200,
                "OK",
            )
            return

        target = get_target(self.path)

        if not target:
            self._send_text(
                404,
                "Invalid bridge URL",
            )
            return

        try:
            meta = probe_target(target)
            total = meta.get("total")

            if not total:
                self._send_text(
                    502,
                    "Upstream did not expose "
                    "the complete file size",
                )
                return

            self.send_response(200)
            self._send_common_headers(meta)
            self.send_header(
                "Content-Length",
                str(total),
            )
            self.end_headers()

        except Exception as exc:
            self._send_text(
                502,
                f"Bridge upstream error: {exc}",
            )

    def do_GET(self):
        if self.path == "/health":
            self._send_text(
                200,
                "OK",
            )
            return

        target = get_target(self.path)

        if not target:
            self._send_text(
                404,
                "Invalid bridge URL",
            )
            return

        try:
            meta = probe_target(target)
            total = meta.get("total")

            if not total:
                self._send_text(
                    502,
                    "Upstream did not expose "
                    "the complete file size",
                )
                return

            try:
                start, end, partial = (
                    parse_client_range(
                        self.headers.get("Range"),
                        int(total),
                    )
                )
            except ValueError:
                self.send_response(416)
                self.send_header(
                    "Content-Range",
                    f"bytes */{total}",
                )
                self.send_header(
                    "Content-Length",
                    "0",
                )
                self.end_headers()
                return

            self.send_response(
                206 if partial else 200
            )

            self._send_common_headers(meta)

            if partial:
                self.send_header(
                    "Content-Range",
                    (
                        f"bytes {start}-{end}/"
                        f"{total}"
                    ),
                )

            self.send_header(
                "Content-Length",
                str(end - start + 1),
            )

            self.end_headers()

            try:
                stream_exact(
                    target,
                    start,
                    end,
                    self.wfile,
                )

                # JDownloader owns the completed download, extraction, and
                # archive cleanup. Never launch our own postprocessor.

            except (
                BrokenPipeError,
                ConnectionResetError,
            ):
                return

            except Exception as exc:
                self.log_message(
                    "stream failed after "
                    "response started: %s",
                    exc,
                )
                self.close_connection = True
                return

        except Exception as exc:
            try:
                self._send_text(
                    502,
                    f"Bridge upstream error: {exc}",
                )
            except Exception:
                pass


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(
        self,
        server_address,
        handler_class,
        inherited_socket=False,
    ):
        self._activity_lock = (
            threading.Lock()
        )
        self._active_connections = 0
        self._last_activity = (
            time.monotonic()
        )

        if inherited_socket:
            super().__init__(
                server_address,
                handler_class,
                bind_and_activate=False,
            )

            try:
                self.socket.close()
            except Exception:
                pass

            self.socket = socket.fromfd(
                3,
                socket.AF_INET,
                socket.SOCK_STREAM,
            )

            self.server_address = (
                self.socket.getsockname()
            )
            self.server_name = socket.getfqdn(
                self.server_address[0]
            )
            self.server_port = int(
                self.server_address[1]
            )

        else:
            super().__init__(
                server_address,
                handler_class,
            )

    def connection_opened(self):
        with self._activity_lock:
            self._active_connections += 1
            self._last_activity = (
                time.monotonic()
            )

    def connection_closed(self):
        with self._activity_lock:
            self._active_connections = max(
                0,
                self._active_connections - 1,
            )
            self._last_activity = (
                time.monotonic()
            )

    def idle_expired(self):
        with self._activity_lock:
            return (
                self._active_connections == 0
                and (
                    time.monotonic()
                    - self._last_activity
                )
                >= IDLE_SECONDS
            )


def socket_activated() -> bool:
    try:
        return (
            int(
                os.environ.get(
                    "LISTEN_PID",
                    "0",
                )
            )
            == os.getpid()
            and int(
                os.environ.get(
                    "LISTEN_FDS",
                    "0",
                )
            )
            >= 1
        )
    except ValueError:
        return False


def idle_watchdog(server: Server):
    while True:
        time.sleep(2.0)

        if server.idle_expired():
            print(
                "AnkerGames JDownloader "
                f"Bridge idle for "
                f"{IDLE_SECONDS:.0f}s; "
                "exiting until next request.",
                flush=True,
            )
            server.shutdown()
            return


if __name__ == "__main__":
    inherited = socket_activated()

    server = Server(
        ("127.0.0.1", PORT),
        BridgeHandler,
        inherited_socket=inherited,
    )

    mode = (
        "socket-activated"
        if inherited
        else "standalone"
    )

    print(
        "AnkerGames JDownloader Bridge "
        f"({mode}) listening on "
        f"http://127.0.0.1:{PORT}",
        flush=True,
    )

    watchdog = threading.Thread(
        target=idle_watchdog,
        args=(server,),
        daemon=True,
    )
    watchdog.start()

    try:
        server.serve_forever(
            poll_interval=0.5
        )
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
PYBRIDGE

chmod +x "$BRIDGE_PY"
"$VENV_DIR/bin/python" -m py_compile "$BRIDGE_PY"

# ------------------------------------------------------------
# systemd user socket activation
# ------------------------------------------------------------
cat > "$SERVICE_FILE" <<SERVICEEOF
[Unit]
Description=AnkerGames JDownloader on-demand compatibility bridge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$VENV_DIR/bin/python $BRIDGE_PY
Restart=no
SERVICEEOF

cat > "$SOCKET_FILE" <<SOCKETEOF
[Unit]
Description=AnkerGames JDownloader on-demand socket

[Socket]
ListenStream=127.0.0.1:$PORT
NoDelay=true
Service=$SERVICE_NAME

[Install]
WantedBy=sockets.target
SOCKETEOF

systemctl --user daemon-reload

systemctl --user import-environment \
    DISPLAY WAYLAND_DISPLAY XDG_RUNTIME_DIR DBUS_SESSION_BUS_ADDRESS \
    >/dev/null 2>&1 || true

systemctl --user enable --now "$SOCKET_NAME"

# ------------------------------------------------------------
# JDownloader configuration
# ------------------------------------------------------------
echo "Configuring JDownloader automatically..."

LINK_RULES="$LINK_RULES" \
LINK_MAIN="$LINK_MAIN" \
PACK_RULES="$PACK_RULES" \
EVENT_SCRIPTS="$EVENT_SCRIPTS" \
LINKGRABBER_SETTINGS="$LINKGRABBER_SETTINGS" \
EXTRACTION_SETTINGS="$EXTRACTION_SETTINGS" \
STATE_FILE="$STATE_FILE" \
python3 <<'PYCFG'
import json
import os
import time
from pathlib import Path

link_rules_path = Path(os.environ["LINK_RULES"])
link_main_path = Path(os.environ["LINK_MAIN"])
pack_rules_path = Path(os.environ["PACK_RULES"])
event_scripts_path = Path(os.environ["EVENT_SCRIPTS"])
linkgrabber_settings_path = Path(os.environ["LINKGRABBER_SETTINGS"])
extraction_settings_path = Path(os.environ["EXTRACTION_SETTINGS"])
state_path = Path(os.environ["STATE_FILE"])

rewrite_name_new = "AnkerGames to JD Bridge - Current Format"
rewrite_name_old = "AnkerGames to JD Bridge - Legacy Format"
direct_name = "AnkerGames JD Bridge DirectHTTP"

# CURRENT format:
#   https://tunnel5.dlproxy.uk/download/ag1.<payload>.<signature>
# Requiring two dots prevents this rule from swallowing legacy ?sig= links.
rewrite_pattern_new = (
    r"https://(?<host>tunnel[0-9]+\.dlproxy\.uk)"
    r"/download/(?<token>[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)$"
)

# LEGACY format:
#   https://tunnel5.dlproxy.uk/download/<token>?sig=<signature>
rewrite_pattern_old = (
    r"https://(?<host>tunnel[0-9]+\.dlproxy\.uk)"
    r"/download/(?<token>[A-Za-z0-9_-]+)"
    r"\?sig=(?<sig>[A-Za-z0-9_-]+)$"
)

direct_pattern = (
    r"http://127\.0\.0\.1:17892/"
    r"AnkerGames-download\.bin\?.+"
)

rewrite_target_new = (
    "http://127.0.0.1:17892/"
    "AnkerGames-download.bin"
    "?host=${host}&token=${token}"
)

rewrite_target_old = (
    "http://127.0.0.1:17892/"
    "AnkerGames-download.bin"
    "?host=${host}&token=${token}&sig=${sig}"
)

now = int(time.time() * 1000)

# ---- LinkCrawler rules ----
link_rules = []

if link_rules_path.exists():
    try:
        loaded = json.loads(
            link_rules_path.read_text(
                encoding="utf-8"
            )
        )
        if isinstance(loaded, list):
            link_rules = loaded
    except Exception:
        pass

cleaned_link_rules = []

for rule in link_rules:
    if not isinstance(rule, dict):
        cleaned_link_rules.append(rule)
        continue

    name = str(rule.get("name") or "")
    pattern = str(rule.get("pattern") or "")

    if name in {
        rewrite_name_new,
        rewrite_name_old,
        direct_name,
        "AnkerGames to JD Bridge",
    }:
        continue

    if "AnkerGames" in name and (
        "dlproxy" in pattern
        or "127\\.0\\.0\\.1:17892"
        in pattern
    ):
        continue

    cleaned_link_rules.append(rule)

wanted_rules = [
    {
        "enabled": True,
        "logging": True,
        "maxDecryptDepth": 1,
        "name": rewrite_name_new,
        "pattern": rewrite_pattern_new,
        "rule": "REWRITE",
        "rewriteReplaceWith": rewrite_target_new,
        "id": now,
    },
    {
        "enabled": True,
        "logging": True,
        "maxDecryptDepth": 1,
        "name": rewrite_name_old,
        "pattern": rewrite_pattern_old,
        "rule": "REWRITE",
        "rewriteReplaceWith": rewrite_target_old,
        "id": now + 1,
    },
    {
        "enabled": True,
        "logging": True,
        "maxDecryptDepth": 1,
        "name": direct_name,
        "pattern": direct_pattern,
        "rule": "DIRECTHTTP",
        "id": now + 2,
    },
]

link_rules_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

tmp = link_rules_path.with_suffix(
    link_rules_path.suffix + ".tmp"
)

tmp.write_text(
    json.dumps(
        cleaned_link_rules + wanted_rules,
        ensure_ascii=False,
        indent=1,
    ) + "\n",
    encoding="utf-8",
)

os.replace(
    tmp,
    link_rules_path,
)

# ---- Ensure LinkCrawler rules are enabled ----
link_main = {}

if link_main_path.exists():
    try:
        loaded = json.loads(
            link_main_path.read_text(
                encoding="utf-8"
            )
        )
        if isinstance(loaded, dict):
            link_main = loaded
    except Exception:
        pass

found = False

for key in list(link_main):
    normalized = "".join(
        c for c in str(key).lower()
        if c.isalnum()
    )

    if normalized == "linkcrawlerrulesenabled":
        link_main[key] = True
        found = True
        break

if not found:
    link_main[
        "linkcrawlerrulesenabled"
    ] = True

tmp = link_main_path.with_suffix(
    link_main_path.suffix + ".tmp"
)

tmp.write_text(
    json.dumps(
        link_main,
        ensure_ascii=False,
        separators=(",", ":"),
    ) + "\n",
    encoding="utf-8",
)

os.replace(
    tmp,
    link_main_path,
)

# ---- Disable JDownloader's built-in package-name subfolder rule ----
state = {
    "subfolder_rule_found": False,
    "subfolder_rule_original_enabled": None,
}

pack_rules = []

if pack_rules_path.exists():
    try:
        loaded = json.loads(
            pack_rules_path.read_text(
                encoding="utf-8"
            )
        )
        if isinstance(loaded, list):
            pack_rules = loaded
    except Exception:
        pass

# Remove our old custom Packagizer experiment if present.
pack_rules = [
    rule for rule in pack_rules
    if not (
        isinstance(rule, dict)
        and str(rule.get("name") or "")
        == "AnkerGames Direct Downloads + Extract"
    )
]

for rule in pack_rules:
    if not isinstance(rule, dict):
        continue

    rid = str(rule.get("id") or "")
    name = str(rule.get("name") or "")

    if (
        rid == "SubFolderByPackageRule"
        or name
        == "Create Subfolder by Packagename"
    ):
        state["subfolder_rule_found"] = True
        state[
            "subfolder_rule_original_enabled"
        ] = bool(
            rule.get("enabled", True)
        )
        rule["enabled"] = False

if pack_rules_path.exists() or pack_rules:
    tmp = pack_rules_path.with_suffix(
        pack_rules_path.suffix + ".tmp"
    )

    tmp.write_text(
        json.dumps(
            pack_rules,
            ensure_ascii=False,
            separators=(",", ":"),
        ) + "\n",
        encoding="utf-8",
    )

    os.replace(
        tmp,
        pack_rules_path,
    )

# ---- Event Scripter cleanup + REAL AnkerGames package rename ----
try:
    events = json.loads(
        event_scripts_path.read_text(
            encoding="utf-8"
        )
    ) if event_scripts_path.exists() else []
except Exception:
    events = []

if not isinstance(events, list):
    events = []

old_names = {
    "AnkerGames Download Folder",
    "AnkerGames Force Extract",
    "AnkerGames Actual Package Folder",
    "AnkerGames Archive Fallback",
    "AnkerGames Package Name = Archive Name",
    "AnkerGames REAL Package Name = Archive Name",
    "AnkerGames LinkGrabber Package = Archive Name",
    "AnkerGames Downloads Package = Archive Name",
}

events = [
    entry for entry in events
    if not (
        isinstance(entry, dict)
        and str(entry.get("name") or "")
        in old_names
    )
]

linkgrabber_package_js = r'''// AnkerGames v2.2 - rename the REAL LinkGrabber package immediately.
//
// Before:
//   Various Files
//      Core-Keeper-AnkerGames.zip
//
// After:
//   Core-Keeper-AnkerGames.zip
//      Core-Keeper-AnkerGames.zip

if (crawledLink != null) {
    var name = String(crawledLink.getName() || "");
    var url = String(crawledLink.getUrl() || "");
    var isArchive = /\.(zip|rar|7z)$/i.test(name);

    var isAnker =
        /AnkerGames?/i.test(name) ||
        url.indexOf("127.0.0.1:17892/") !== -1 ||
        url.indexOf("dlproxy.uk/download/") !== -1;

    if (isAnker && isArchive) {
        var pkg = crawledLink.getPackage();

        if (pkg != null) {
            pkg.setName(name);
        }
    }
}
'''

downloads_package_js = r'''// AnkerGames v2.2 - keep the REAL Downloads package name identical.
//
// Trigger: A Download started
//
// package is the actual FilePackage shown in the Downloads tab.

if (link != null && package != null) {
    var name = String(link.getName() || "");
    var url = String(link.getUrl() || "");
    var pluginUrl = String(link.getPluginURL() || "");
    var contentUrl = String(link.getContentURL() || "");
    var originUrl = String(link.getOriginURL() || "");

    var isAnker =
        /AnkerGames?/i.test(name) ||
        url.indexOf("127.0.0.1:17892/") !== -1 ||
        pluginUrl.indexOf("127.0.0.1:17892/") !== -1 ||
        contentUrl.indexOf("127.0.0.1:17892/") !== -1 ||
        originUrl.indexOf("dlproxy.uk/download/") !== -1;

    var isArchive = /\.(zip|rar|7z)$/i.test(name);

    if (isAnker && isArchive) {
        package.setName(name);
    }
}
'''

events.extend([
    {
        "eventTrigger": "ON_NEW_LINK",
        "enabled": True,
        "name": "AnkerGames LinkGrabber Package = Archive Name",
        "script": linkgrabber_package_js,
        "eventTriggerSettings": {
            "isSynchronous": True
        },
        "id": now + 400,
    },
    {
        "eventTrigger": "ON_DOWNLOAD_CONTROLLER_START",
        "enabled": True,
        "name": "AnkerGames Downloads Package = Archive Name",
        "script": downloads_package_js,
        "eventTriggerSettings": {
            "isSynchronous": True
        },
        "id": now + 401,
    },
])

event_scripts_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

tmp = event_scripts_path.with_suffix(
    event_scripts_path.suffix + ".tmp"
)

tmp.write_text(
    json.dumps(
        events,
        ensure_ascii=False,
        indent=1,
    ) + "\n",
    encoding="utf-8",
)

os.replace(
    tmp,
    event_scripts_path,
)
# ---- Native JDownloader 'Various Files' single-file grouping ----
# This setting is independent of Event Scripter and Packagizer rules.
# We intentionally edit just one JSON key while retaining every other key.
linkgrabber_settings = {}
if linkgrabber_settings_path.exists():
    linkgrabber_settings = json.loads(
        linkgrabber_settings_path.read_text(encoding="utf-8")
    )
    if not isinstance(linkgrabber_settings, dict):
        raise ValueError("Invalid LinkGrabber settings object")

previous_install_state = {}
if state_path.exists():
    try:
        previous = json.loads(state_path.read_text(encoding="utf-8"))
        if isinstance(previous, dict):
            previous_install_state = previous
    except (OSError, UnicodeError, json.JSONDecodeError):
        pass

# Keep the pre-existing v1.9 Packagizer original state on reinstall too.
# Otherwise a second install snapshots the already-disabled subfolder rule.
if previous_install_state.get("subfolder_rule_found") is True:
    state["subfolder_rule_found"] = True
    state["subfolder_rule_original_enabled"] = previous_install_state.get(
        "subfolder_rule_original_enabled"
    )

# Do not lose the ORIGINAL value if the installer is run again.
if previous_install_state.get("variouspackage_previous_value_captured") is True:
    for field in (
        "variouspackage_previous_value_captured",
        "linkgrabber_settings_file_existed_before_install",
        "variouspackage_key_existed_before_install",
        "variouspackage_previous_value",
    ):
        state[field] = previous_install_state.get(field)
else:
    state["variouspackage_previous_value_captured"] = True
    state["linkgrabber_settings_file_existed_before_install"] = linkgrabber_settings_path.exists()
    state["variouspackage_key_existed_before_install"] = (
        "variouspackageenabled" in linkgrabber_settings
    )
    state["variouspackage_previous_value"] = linkgrabber_settings.get("variouspackageenabled")

# Disables Settings > General > 'Group single files in a various package'.
linkgrabber_settings["variouspackageenabled"] = False
linkgrabber_settings_path.parent.mkdir(parents=True, exist_ok=True)
tmp_lg = linkgrabber_settings_path.with_suffix(linkgrabber_settings_path.suffix + ".tmp")
tmp_lg.write_text(
    json.dumps(linkgrabber_settings, ensure_ascii=False, indent=1) + "\n",
    encoding="utf-8",
)
os.replace(tmp_lg, linkgrabber_settings_path)

# ---- Native JDownloader Archive Extractor: "Create Subfolder" ----
# Verified in JDownloader's ExtractionConfig.isSubpathEnabled(), persisted in:
#   org.jdownloader.extensions.extraction.ExtractionExtension.json
#   {"subpathenabled": true}
# This changes the extraction destination behavior, NOT the Packagizer
# download directory rule. Keep the existing "subpath" pattern untouched.
extraction_settings = {}
if extraction_settings_path.exists():
    extraction_settings = json.loads(
        extraction_settings_path.read_text(encoding="utf-8")
    )
    if not isinstance(extraction_settings, dict):
        raise ValueError("Invalid Archive Extractor settings object")

# Keep the real pre-v2.2 value over reinstalls, even if already enabled by us.
if previous_install_state.get("extractor_subpath_original_captured") is True:
    for field in (
        "extractor_subpath_original_captured",
        "extractor_settings_file_existed_before_install",
        "extractor_subpath_key_existed_before_install",
        "extractor_subpath_previous_value",
    ):
        state[field] = previous_install_state.get(field)
else:
    state["extractor_subpath_original_captured"] = True
    state["extractor_settings_file_existed_before_install"] = extraction_settings_path.exists()
    state["extractor_subpath_key_existed_before_install"] = "subpathenabled" in extraction_settings
    state["extractor_subpath_previous_value"] = extraction_settings.get("subpathenabled")

extraction_settings["subpathenabled"] = True
extraction_settings_path.parent.mkdir(parents=True, exist_ok=True)
tmp_extraction = extraction_settings_path.with_suffix(extraction_settings_path.suffix + ".tmp")
tmp_extraction.write_text(
    json.dumps(extraction_settings, ensure_ascii=False, indent=1) + "\n",
    encoding="utf-8",
)
os.replace(tmp_extraction, extraction_settings_path)

state_path.write_text(
    json.dumps(
        state,
        indent=2,
    ) + "\n",
    encoding="utf-8",
)

print("JDownloader configuration: OK")
print("JDownloader native Various Files grouping: OFF (persists across restarts)")
print("JDownloader Archive Extractor Create Subfolder: ON")
PYCFG

# ------------------------------------------------------------
# Test socket activation
# ------------------------------------------------------------
echo
echo "Testing on-demand bridge..."

if command -v curl >/dev/null 2>&1; then
    if curl -fsS \
        --max-time 5 \
        "http://127.0.0.1:${PORT}/health" \
        >/dev/null
    then
        echo "Bridge health check: OK"
    else
        echo "WARNING: Bridge health check did not answer."
        echo "Check:"
        echo "  systemctl --user status $SOCKET_NAME"
        echo "  journalctl --user -u $SERVICE_NAME -n 50 --no-pager"
    fi
else
    echo "curl is not installed; skipped health check."
fi

echo
echo "============================================================"
echo " FULL SETUP COMPLETE"
echo "============================================================"
echo
echo "Start JDownloader 2 and add a FRESH AnkerGames link."
echo "Native JDownloader Various Files grouping is OFF; existing packages will not be renamed."
echo "Current ag1.<payload>.<signature> and legacy ?sig= links are supported."
echo
echo "What happens now:"
echo "  1. Archive downloads through the on-demand compatibility bridge."
echo "  2. JDownloader finishes the download and runs its OWN Archive Extractor."
echo "  3. JDownloader alone controls post-extraction archive deletion."
echo "  4. No Python extraction helper is installed or launched."
echo
echo "The native JDownloader 'Various Files' grouping setting stays OFF."
echo "JDownloader Archive Extractor > Create Subfolder is ON (original subfolder pattern unchanged)."
echo "JDownloader's Archive Extractor must be enabled in its settings."
echo "To delete ZIPs after success, use JDownloader's own extraction cleanup preference."
echo
echo "The bridge exits after 45 seconds of inactivity."
echo "Bridge log: journalctl --user -u $SERVICE_NAME -n 100 --no-pager"
echo
echo echo "Uninstall everything from this setup:"
echo "  bash \"$0\" --uninstall"
echo
