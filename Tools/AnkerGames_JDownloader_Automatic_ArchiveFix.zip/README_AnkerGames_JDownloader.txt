AnkerGames JDownloader Automatic Setup — Archive Aware

INSTALL:
  bash ~/Downloads/AnkerGames_JDownloader_Automatic_Setup.sh

What this version does:
  * installs the on-demand local compatibility bridge
  * keeps the Python bridge stopped when it is not needed
  * adds/updates the required AnkerGames LinkCrawler rules automatically
  * preserves unrelated JDownloader LinkCrawler rules
  * resolves the real archive filename/extension before JDownloader downloads it
  * avoids the old synthetic AnkerGames-download.bin classification
  * allows JDownloader Archive Extractor to recognize ZIP/RAR/7Z links normally
  * keeps Content-Disposition with the real archive filename
  * creates backups of the relevant JDownloader config files

IMPORTANT:
  Restart JDownloader once after running the installer if JDownloader was open.

Your existing Archive Extractor settings remain in control. If you have:
  "Extract archives after download" enabled
and
  "Delete archive files after successful extraction" enabled
JDownloader should now treat AnkerGames archives like normal archive downloads.

UNINSTALL:
  bash ~/Downloads/AnkerGames_JDownloader_Automatic_Uninstaller.sh

The uninstaller:
  * stops/removes the socket and bridge service
  * removes the bridge files and private Python environment
  * removes only the AnkerGames LinkCrawler rules
  * leaves unrelated JDownloader rules/settings untouched
