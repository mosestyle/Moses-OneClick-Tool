# Moses OneClick Tool V7.4.110

## One-time MangoHud preset 2 setup

On the first install of V7.4.110 **or the first upgrade to it** from an older
Moses version, the installer creates or updates `$HOME/.config/MangoHud/presets.conf`
with the exact SteamOS Level 2 HUD settings requested (horizontal, FPS, CPU,
GPU, RAM, VRAM, GPU memory temperature, and `fan`). It keeps other pre-existing
MangoHud preset sections and backs up `presets.conf` before modifying it.

Once applied (or confirmed already matching), Moses creates
`$HOME/.local/share/lutris-oneclick/.mangohud-preset2-initialized`.
Subsequent Moses updates **do not touch** `presets.conf`, even if you later
customize it yourself. A full uninstall removes Moses' own marker but leaves
the MangoHud config intact.

Install over the previous version using
`bash Moses_OneClick_Tool_Setup_V7.4.110.sh`. No uninstall is required.
The installer was syntax-checked and the one-time function tested in a
temporary user home; a real SteamOS installation has not been tested here.

---

# Moses OneClick Tool V7.4.108

## Fix: "Use selected game" artwork matching preserves the new game name

When a Moses-managed Steam game is renamed from the manual artwork match while
Steam is still running, the old Steam shortcut name must **not** overwrite the
new name in Moses' registry during the subsequent GUI refresh. V7.4.107 could
lose the new title and reset its queued `pending_steam` status before the Steam
restart. V7.4.108 prevents that recovery race.

Artwork fetching, editable game names, Steam restart prompt, all game installation,
external-drive moves, and complete game removal remain unchanged.

Install over the previous version with `bash Moses_OneClick_Tool_Setup_V7.4.108.sh`.
No uninstall needed. Actual SteamOS GUI operation needs confirmation on-device.

---

# Moses OneClick Tool V7.4.107

Small fix based directly on V7.4.105.

- Fixed Complete Game Removal erroneously applying its external-drive UUID recheck to games stored in the **internal** Moses Game Folder. This caused the misleading message "External drive or game folder changed since confirmation", leaving the actual internal game folder behind after Steam registration was removed.
- The external-drive safety recheck remains enabled for **external** games. No changes to copying, installing, artwork, progress dialogs or Steam restart.
- Already orphaned game folders from older removal attempts are NOT automatically removed by installing this update. Verify their ownership and saved-game contents before manually deleting them.

Install: `bash Moses_OneClick_Tool_Setup_V7.4.107.sh`. Do not uninstall the earlier version first.

---

# Moses OneClick Tool V7.4.104

## One change from V7.4.103

After a successful **Move to External Drive + Add to Steam**, once the original folder has been deleted, Moses now displays the same short non-modal KDialog passive notification used when adding games to Steam. The notification says the game was moved to the external drive and added to Steam successfully and that artwork is downloading in the background. It disappears after approximately 8 seconds; no OK button is needed. Failed transfers or failed deletion never show this success notification.

The progress indicator, elapsed time, removal behavior, artwork implementation, external drive selection, and all other functions are unchanged.

### Installation

Extract the ZIP and run `bash Moses_OneClick_Tool_Setup_V7.4.104.sh` inside the extracted version folder, over the previous version. No uninstall is required.

---

# Moses OneClick Tool V7.4.103

## Only packaging cleanup from V7.4.102

Removed `bat_launcher_source.c` from the ZIP. The compiled `.exe` launcher remains embedded in the installer, and is installed as before. No functional changes were made. All behavior from V7.4.102, including automatic removal of the original folder after a successful external move, remains unchanged.

### Installation

Extract and run `bash Moses_OneClick_Tool_Setup_V7.4.103.sh` over your installed Moses OneClick Tool. Do not uninstall first. Close/reopen Dolphin afterward.

---

# Moses OneClick Tool V7.4.100

## Focused fix, built directly on V7.4.97

Only these functional changes were made to the V7.4.97 code:

1. **Complete Game Removal** also recognizes the real game directory for UUID-based external moves (`OneClick Games/Steam-Proton/<Game>/Files`). It verifies the connected drive UUID, registered game path, and EXE before including the exact game-owned folder in the existing file-deletion confirmation. If validation fails, removal stops rather than silently removing Steam metadata and leaving game files behind. The UUID/path is rechecked before deleting the external folder.
2. **Move to External Drive + Add to Steam** now displays `Elapsed: HH:MM:SS` alongside copy speed and estimated remaining time.

This is NOT based on V7.4.98/7.4.99. V7.4.97's size/symlink verification (not the later byte-for-byte integrity check), artwork behavior, and the final optional original-folder deletion confirmation are unchanged. This build does NOT clean up already orphaned folders automatically; check them manually before deleting.

### Installation

Extract the ZIP and run `bash Moses_OneClick_Tool_Setup_V7.4.100.sh` over the existing install. Do not uninstall first; close/reopen Dolphin after setup.

### Verification limits

Source syntax and simulated UUID/path tests are possible here; actual SteamOS hardware, drive unplug/replug and live Steam/Proton gameplay require testing on-device. Back up saves and first test removal on a disposable game.

---

# Moses OneClick Tool V7.4.97

## V7.4.97 — External-drive copy progress and formatting stability

- **Move to External Drive + Add to Steam** now uses a live KDialog progress bar showing copied bytes, percentage, transfer speed and estimated time remaining. The progress also shows verification and Steam shortcut registration as separate stages. Large files stream in 4 MiB chunks instead of waiting for a whole file to finish before showing progress.
- Existing safety checks are preserved: copying is staged, symlinks and file sizes are verified, UUID path stability is checked, and the original is never removed automatically or after an error.
- **Format External Drive** now uses `udisksctl unmount` instead of a separate privileged `umount` and performs formatting plus Linux filesystem ownership setup in **one** PolicyKit authorization request. After that, SteamOS remounts it with `udisksctl`. It also verifies the selected volume UUID immediately before erasing, and keeps the Settings GUI responsive while the helper works.
- Clearer errors for a busy/unmountable drive, missing formatter, cancelled authorization and permissions problems. Formatting still requires explicit selection, confirmations and typing `FORMAT`, and erases the selected volume. Do not disconnect the drive during a move or format.
- Existing V7.4.96 functions and Steam integration are retained.

### Install

Extract and run `bash Moses_OneClick_Tool_Setup_V7.4.97.sh` over the existing installation **without uninstalling first**. Close and reopen Dolphin after setup.

### Testing notes

Shell/Python source syntax checked and the transfer and format orchestration were tested with simulated drives/processes; formatting an actual disk, PolicyKit behavior and SteamOS live USB/Steam launches could not be tested in this container. Try on a noncritical external drive and verify the game launches before deleting your original files.

# Moses OneClick Tool V7.4.96

## V7.4.96 — Move to External Drive + Add to Steam

- Dolphin folder right-click menu adds **Move to External Drive + Add to Steam** alongside all previous options.
- Pick the destination drive from a list of currently connected, writable removable volumes. The picker shows drive name, filesystem, free space and mount point.
- Transfers full game directory into `OneClick Games/Steam-Proton/<Game>/Files`. If the source folder **is** an AppID-matched Moses-owned Proton prefix, moves it as the game-named external prefix instead and atomically retargets the existing Steam `compatdata` symlink. Existing saves/configuration are preserved.
- Existing Proton prefixes stored separately on the internal SSD stay there unchanged. The game-file-only mode explicitly prevents drive reconnection migration code from rewriting a saved internal prefix into an empty external one.
- Uses UUID-based internal aliases for the Steam EXE/start directory and the existing external-game Steam launch wrapper. Reconnects can change `/run/media/...` mount paths without changing Steam shortcuts. The existing Moses user-session drive monitor reconnects known volumes, and launch-time logic mounts/resolves them when possible.
- Requires a writable **ext4/Btrfs/XFS/F2FS** external filesystem; never formats storage. NTFS/exFAT/FAT are deliberately excluded because the selected folder might contain symlinks or a Proton prefix.
- First copies game files to a temporary folder, verifies file sizes and symbolic links, then publishes the destination and commits/verifies the Steam shortcut. It never deletes source data if transfer/registration fails. The old folder is deleted only after asking explicitly; choose **No** to keep a backup until the game has been tested.
- Reuses the game's unchanged AppID when its name matches the original, retaining the Steam/Proton identity and game saves. Titles already registered from a different folder are protected against accidental overwrite.

### Upgrade / use

1. Extract this ZIP and run `bash Moses_OneClick_Tool_Setup_V7.4.96.sh`. **Do not uninstall first**, because that also removes Moses application data.
2. Close and reopen Dolphin. Right-click the whole game folder and choose **Move to External Drive + Add to Steam**.
3. Choose your external hard drive, then game EXE/BAT and title. Confirm copying and shortcut registration.
4. First test launching the game from Steam. At the final cleanup question, **No** keeps the old folder as a safety backup. If you are certain the copy runs, delete the old folder yourself later. Never disconnect a drive while its games are running; safely eject it first.

**Reconnection requirements:** same formatted volume (same filesystem UUID), drive recognized/mounted by SteamOS, Moses helper/service installed, drive available before launch. If unplugged, the Steam shortcut remains but the game cannot launch until the drive reconnects. Reformats/new UUIDs require moving or registering the shortcut again. A Steam-native game in an official Steam Library is a different workflow and should be moved with Steam Storage instead.

**Validation note:** shell/Python source syntax and simulated file-copy/registry/path tests were performed in a Linux container. Actual SteamOS Gaming Mode, Steam/Proton and USB reconnects cannot be exercised here and should be tested on the user's hardware before deleting original game files.

# Moses OneClick Tool V7.4.95

## V7.4.95 — BAT game launchers through Proton

- Dolphin folder menu **Find Game EXE / BAT + Add to Steam** now lists `.bat` scripts alongside `.exe` executables. **Move to Game Folder + Add to Steam** also accepts `.bat` selections.
- BAT selections create a normal Steam non-Steam shortcut pointing at the bundled 64-bit Windows BAT launcher (source included). Steam runs that EXE through the selected compatibility tool; it invokes the script using Wine/Proton `cmd.exe /D /S /C`, sets the script directory as its Windows working directory, and waits for the batch process to finish.
- The registry continues to store the **original game BAT file path**, not the shared launcher EXE, for folder opening, re-selection and Complete Game Removal.
- The pencil editor can switch an existing Moses-managed Steam shortcut between EXE and BAT without changing the Steam AppID, game files, Proton prefix or artwork.
- Installer detection remains **EXE only** and Steam Library official-game EXE overrides remain unchanged. No automatic BAT execution during installation.
- This feature does **not** make scripts native Linux executables. BAT files requiring unsupported Windows commands or software may still fail. Wine's usual `Z:` root mapping is required to find Linux-side scripts.
- The small launcher EXE is embedded in the setup script, checked against SHA256 before installation, and stored in Moses' application data directory. It does not alter any game files. It is removed by the existing uninstall that clears the application data directory.
- Preserves V7.4.94 GOG/shortcut recovery and V7.4.93 Complete Game Removal logic.

### Use

1. Extract the ZIP and run `bash Moses_OneClick_Tool_Setup_V7.4.95.sh`. Do not uninstall first.
2. In Dolphin, right-click your game folder and choose **Find Game EXE / BAT + Add to Steam**.
3. Select the desired `.bat`, choose/confirm the game name, and create the Steam shortcut.
4. If a shortcut must be refreshed, restart Steam. For an existing managed game, use the pencil editor to change from an EXE to BAT.

**Validation note:** source/installer syntax and simulated file/Steam-shortcut tests were performed in a Linux container. Actual SteamOS/Proton launching cannot be exercised here. If a BAT shortcut fails, check the script's commands and selected compatibility tool. 

# Moses OneClick Tool V7.4.94

## V7.4.94 — Restore installed GOG games and Steam shortcuts

- **Fix Steam/Proton EXE detection:** Installer completion now searches the real registered Moses Proton prefix (including `game-prefixes/Steam-Proton/<game>/pfx/drive_c`), rather than relying only on Steam's numeric `steamapps/compatdata/<appid>` shortcut. This handles GOG-installed games such as Cyberpunk 2077 even when Steam's link is missing.
- **Repair Steam Shortcut** can rediscover a missing/stale launch EXE inside the game's registered Proton prefix before writing the Steam shortcut. It reuses the installed game files; no reinstallation is necessary if a single strong EXE candidate is found.
- **Automatic startup recovery** attempts to restore a missing shortcut for a previously installed Moses game only when its saved EXE is also broken. Games deliberately detached from Steam are not restored.
- If Steam is running, pending shortcut writes continue through the existing deferred writer and finalize on a clean Steam exit or Gaming Mode transition. The game may not be visible until Steam reloads its shortcuts.
- **Protect existing Proton data:** restore a missing numeric Steam compatdata symlink only when a private Moses prefix has an AppID-matching ownership marker. Do not replace real directories, conflicting links, or external-drive paths.
- **Preserves V7.4.93 Complete Game Removal changes** and all other V7.4.92 behavior and UI.

**Cyberpunk 2077 already installed:** Install this update over V7.4.93 without uninstalling. Then exit and reopen Steam (or return to Gaming Mode) so the recovered shortcut can appear. If it does not, select Cyberpunk 2077 in Moses and use **Repair Steam Shortcut** once. For an ambiguous executable, choose `Cyberpunk2077.exe` in the pencil editor instead of reinstalling.

# Moses OneClick Tool V7.4.93

## V7.4.93 — Fix Complete Game Removal for moved game folders

- Complete Game Removal now detects the **real game folder** under `~/.local/share/oneclick-exe/game-prefixes/Steam-Proton/<game>` when a game was imported through **Move to Game Folder + Add to Steam**, even if it has no separate Proton prefix yet.
- The permanent deletion dialog lists **both** the real game files and any separate Proton compatdata directory. It never treats links in the `game-folders` view as the game files.
- The second, destructive confirmation remains mandatory, and cancelling it preserves all game files as before.
- Protects the shared Steam-Proton storage root, refuses untrusted symbolic links and won't delete a game folder still referenced by another Moses game.
- Removes stale Dolphin `game-folders` shortcuts pointing into physically deleted directories, without deleting anything extra.
- Compatible with the existing V7.4.92 installation. All other features and installer flows are unchanged.

**Previously removed games:** If an old removal already erased the Steam entry, the existing orphaned physical folder will not be automatically erased by an upgrade. You can delete that specific leftover game folder manually after verifying it is no longer used.

# Moses OneClick Tool V7.4.92


## V7.4.92 — Manual Steam artwork search + remembered match

- Added a **magnifying-glass button** beside **Download + Apply All Artworks**. With one game selected, it opens a Steam artwork search instead of requiring the local Moses game name to exactly match Steam's title.
- Search Steam using any title, choose the correct result from a list showing the Steam AppID, and Moses immediately retries the artwork download using that exact Steam game.
- The selected Steam artwork match is **remembered per game**, so a friendly/custom Moses name such as `The Witcher 3 Wild Hunt GOTY` can permanently use artwork from Steam's differently-named store entry.
- **Use automatic match** clears the saved choice and returns that game to the normal automatic matcher.
- Choosing a new match invalidates only Moses' artwork cache metadata; the currently visible Steam artwork is left in place until replacement files download successfully.
- When a single-game artwork download fails, Moses now points directly to the new magnifying-glass search instead of only reporting a generic failure.
- Built directly from the stable **V7.4.90** baseline. V7.4.91 remains intentionally ignored.


## V7.4.90 — launcher-style installs finalize correctly

- Fixes applications such as **GOG Galaxy** that open themselves at the end of installation and keep client/service processes alive. Moses no longer waits for the newly-installed launcher to be closed before it can finish the installation record.
- When a strong main EXE is already running from the new Proton prefix, Moses registers it immediately and keeps the application running. For GOG Galaxy this selects `Program Files (x86)/GOG Galaxy/GalaxyClient.exe`, not `GalaxyClientService.exe`, the updater, overlay, helper or communication process.
- GOG Galaxy installations completed with older builds but left stuck in `installing` are recovered automatically when the game list is refreshed. No reinstall is required as long as the existing Galaxy prefix/client is still present.
- The recovered/new launcher uses the **same Proton prefix that the installer created**, so its Moses Steam shortcut points back to the logged-in Galaxy installation instead of creating a fresh empty prefix.
- V7.4.89 Steam Library EXE picker behavior and all existing installer/update flows are preserved.

## V7.4.89 — Steam Library EXE drop-down

- Normal Steam Library games now get the same launch-EXE picker style as Moses-managed games.
- The pencil editor scans the selected Steam game’s real folder recursively and lists the discovered `.exe` files in a drop-down.
- The current Moses override is marked `(current)`, while `Steam default executable` remains selectable to remove the override.
- `Browse…` remains available as a fallback. Steam’s own Play configuration is still never modified.


## V7.4.88 — Steam Library launch EXE override + exact VC++ 2005 prerequisites

- The pencil button is now available for normal **STEAM LIBRARY** games too. Steam still owns the official installation, but Moses can save a **Moses-only launch EXE override** inside the real Steam game folder. This is useful when a patch installs a new launcher or replacement EXE.
- **Play Game** in Moses uses the saved override when present. **Use Steam default** removes it. Steam's own Play button and appmanifest are deliberately left untouched.
- The override is stored per Steam AppID and survives Moses upgrades. EXEs outside the real game folder still belong in **Game Tools**.
- Opening **Game Tools** now also rescans the selected Steam game for obvious newly-created launchers such as `CnCNetYRLauncher.exe`, so a patch launcher is recovered even if the original installer process finished before Moses could notice it.
- CnCNet prerequisite preparation now uses the exact Visual C++ 2005 SP1 **8.0.61000** x86/x64 packages checked by the Inno dependency installer, fixing the two remaining VC++ 2005 prerequisite downloads that could still fail inside Proton.





## V7.4.87 — quieter existing-game installs, CnCNet prerequisites, automatic Game Tools

- Removed the **Game folder ready** KDialog. Moses still creates `C:\MosesGame`, `M:\` when available, and the Red Alert 2 `C:\Westwood\RA2` compatibility link silently.
- For **CnCNet Yuri's Revenge targeting Steam AppID 2229850**, Moses now downloads the legacy Visual C++ 2005/2008/2010/2012/2013 redistributables on the Linux host and installs them silently into Red Alert 2's **existing** Proton prefix before CnCNet starts. This avoids relying on CnCNet's Windows HTTPS prerequisite downloader, which can fail under Proton with `0x80090305`. Cached files are reused on later runs.
- **Install into an existing game** snapshots user-facing EXEs before the installer starts. After it finishes, Moses scans for newly created launchers/tools and automatically adds strong matches such as `CnCNetYRLauncher.exe`, Mod Organizer, launchers and client executables to that game's **Game Tools** list. Installer/uninstaller and redistributable EXEs are excluded.
- The proven V7.4.85 Proton Experimental existing-prefix launch method is unchanged.


## V7.4.86 — Easy Windows path to the real Steam game folder

**Install into an existing game** keeps the working V7.4.85 Proton Experimental launch path, but normal Steam Library games now expose their real Steam install folder inside the existing Proton prefix as `C:\MosesGame`. When drive `M:` is free, the same folder is also available as `M:\`. These are links to the real Steam folder; no game files are copied or moved.

Before the installer opens, Moses shows the easy Windows path in a KDialog so users never need to discover a Linux path such as `Z:\home\deck\.local\share\Steam\steamapps\common\...`. Game Tools creates/reuses the same aliases without showing the extra message.

For Steam AppID `2229850` (Command & Conquer: Red Alert II and Yuri's Revenge), Moses additionally maps `C:\Westwood\RA2` directly to the real Steam game folder. This matches CnCNet Yuri's Revenge's default destination, so the installer can use its normal default path instead of requiring manual browsing. Existing real Windows folders or unrelated drive mappings are never overwritten.


## V7.4.85 — Existing Steam installers now use the exact working new-game launcher

For normal Steam Library games, **Install into an existing game** now deliberately uses Proton Experimental and the same `proton run <installer.exe>` launch path as **Install as a new game**. The difference is only the compatdata target: Moses reuses Steam's real existing prefix and never creates, moves or replaces it. This removes the previous mismatch where existing-game installs could silently use the game's selected Proton version while new-game installs used Proton Experimental.


## V7.4.81 — Install patches, mods and launchers into existing games

The old **Update an installed game** action is now the more general **Install into an existing game** action. It can run a patch, update, DLC installer, mod installer, launcher installer or similar EXE inside the target game's existing prefix.

Normal Steam-installed games are supported too. Moses reads the Steam AppID, game folder and existing compatdata, but Steam remains the owner of the game. Moses will never create, move or replace the Proton prefix for an official Steam Library game. If Steam has not created a prefix yet, launch the game once through Steam first.

Example: double-click `CnCNet5_YR_Installer.exe`, choose **Install into an existing game**, then choose **Command & Conquer: Red Alert 2 and Yuri's Revenge**. The installer runs in Red Alert 2's real Steam Proton prefix instead of creating a separate game.

## V7.4.80 — Steam Library games in Game Tools

- Moses now discovers normal games installed directly by Steam from Steam's local `appmanifest_*.acf` files. They appear in a separate **STEAM LIBRARY** group beneath the existing **MOSES GAMES** group.
- Steam Library entries are deliberately **read-only** in Moses. Steam still owns installation, updates, verification, removal, the normal launch shortcut and official artwork. **Repair Steam Shortcut**, **Download + Apply All Artworks** and **Complete Game Removal** stay disabled for those entries. From V7.4.88 onward, the pencil is available only for a Moses launch-EXE override; it does not edit Steam's official installation.
- **Play Game** launches a Steam Library title with its real Steam AppID. Moses-managed non-Steam shortcuts keep their existing Big Picture shortcut AppID behavior.
- **Game Tools** now works with Steam-installed Windows games. Launchers, patches, configuration utilities, mod managers and other `.exe` files run in the game's **existing Steam Proton prefix** without changing the game or importing it into Moses.
- Moses tries to reuse the Proton build recorded by the existing prefix. If that cannot be resolved, it falls back to Steam's configured compatibility tool / Proton Experimental.
- Safety rule: Moses will **never create, move or replace a Proton prefix for an official Steam Library game**. If Steam has not created `compatdata/<AppID>` yet, Game Tools asks you to launch the game once through Steam first.
- Double-click / right-click **Run as game tool** also includes installed Steam Library games in the target chooser, so a patch installer such as CnCNet can be launched directly into the existing Red Alert 2 prefix and remembered in that game's Game Tools list.
- Steam compatibility runtimes such as Proton, Steam Linux Runtime and Steamworks Common Redistributables are filtered out of the Steam Library game list.
- V7.4.79 Game Tools history, V7.4.77 sidebar icon repair, V7.4.76 StreamExtract KDialog completion and all existing installer/update behavior are preserved.


## V7.4.79 — reliable Steam sidebar icons

- Moses now repairs the **small non-Steam library/sidebar icons** during its own **Restart Steam** action, while Steam is fully closed and `shortcuts.vdf` is safe to edit.
- Every Moses Steam-native game with a downloaded `<AppID>_icon.*` file is matched to the exact AppID in `shortcuts.vdf`, and that shortcut's `icon` field is set to the real absolute artwork path.
- The repair updates all matching Moses games in **one atomic VDF write**, preserves the rest of each shortcut record, creates a pre-repair backup, and reads the file back to verify the icon paths before Steam is started again.
- If artwork was already bound correctly, Moses still rewrites one clean closed-Steam snapshot so Steam gets a deterministic file to read on startup.
- Existing artwork downloads are reused. There is no need to redownload capsules, heroes, logos, or icons just to run the repair.
- **Download + Apply All Artworks** continues to save/queue the icon path as before; the next Moses **Restart Steam** now deterministically applies all queued/existing icons.
- V7.4.76 StreamExtract KDialog behavior and all V7.4.75 folder-root handling are unchanged.


## V7.4.76 — native KDialog for StreamExtract completion

- When a portable/already-complete game finishes in StreamExtract and is added to Steam, the final **Game ready** confirmation now uses KDE **KDialog** instead of the PySide/Qt message box embedded in StreamExtract.
- The completion text and Steam shortcut/artwork behavior are unchanged. This is a UI-only change to make StreamExtract match the normal Moses install flow more closely.

## V7.4.75 — remember the real game root

This release is based directly on V7.4.74 and keeps the separate **Game Folders** / **Proton Prefixes** views, but stops treating the selected launch EXE's parent folder as the game folder.

- Moses now stores a separate **`game_root`** for each Steam / Proton game. This is the original/root folder containing the game's files, independent of the launch EXE and independent of `pfx/drive_c`.
- **Open Selected Game Folder** opens `game_root`. A nested EXE such as `Game/Binaries/Win64/Game.exe` therefore opens `Game/`, not `Win64/`.
- **Open All Game Folders** points every game name at that same stored root. The presentation view still uses safe symlinks only; no game files are moved or duplicated.
- Older V7.4.x registry rows are migrated automatically. Complete-game imports recover their original folder; StreamExtract portable games recover their `Files`/top-level archive folder; normal installer games infer the best matching install directory inside Proton.
- The pencil **Edit Game** window now also shows **Game Folder** with **Change folder…** as a manual fallback when automatic detection is not ideal. Moses only accepts a folder that contains the game's current launch EXE.
- Changing the game folder does not reinstall anything and does not change the Steam AppID, Proton prefix, artwork, saves, dependencies, or launch EXE.
- **Open All Proton Prefixes**, Documents, Save Folder, StreamExtract, dependency handling and all V7.4.74 behavior remain unchanged.


## V7.4.74 — separate game folders from Proton prefixes

This release is based directly on V7.4.73 and changes only folder browsing/navigation.

- **Open All Game Folders** now opens a clean game-name list whose entries point to the actual game files instead of the Proton prefix root.
- **Open Selected Game Folder** remains available for one selected game.
- **Open All Proton Prefixes** is now a separate Storage action for technical access to `pfx`, `drive_c`, registry files and Windows user folders.
- The compact folder button beside the game selector now opens **All Game Folders**; Proton-prefix browsing stays in Settings.
- No game files or Proton prefixes are moved by the new game-folder view; it is presentation-only symlinks and can be rebuilt safely.


## V7.4.73 — one VC++ v14 x86/x64 pair

This release is based directly on V7.4.72 and only cleans up the Visual C++ v14 dependency inventory.

- **Download official dependency set already downloads both architectures** from Microsoft: `vc_redist.x86.exe` and `vc_redist.x64.exe`. V7.4.72 could hide the cached x64 row when a game shipped another `VC_redist.x64.exe` with the same logical dependency name.
- Moses now shows **one current VC++ v14 x86 row and one current VC++ v14 x64 row** when the Official Pack is present.
- Older/redundant `2015-2019` or generic `2015+ (v14 family)` copies are kept safely in the cache/game folder but hidden from the chooser when the current official package for that architecture is available.
- The official-download completion message explicitly confirms when **VC++ v14 x86 + x64 are ready**.
- Legacy VC++ 2013/2012/2010/2008 entries remain separate because those runtimes are side-by-side generations.

## V7.4.72 — clearer Visual C++ dependency labels

This release is based directly on V7.4.71 and changes only dependency identification/display text. Existing install, update, StreamExtract, artwork, save-folder, prefix, and optional-Lutris behavior is unchanged.

- Explicit packages such as `vcredist_2015-2019_x86.exe` now clearly show **Microsoft Visual C++ 2015–2019 Redistributable (x86)**.
- The official current v14 pack clearly shows **Microsoft Visual C++ 2015–2026 (Latest v14) Redistributable** for x86/x64 and notes that it includes VC++ 2015–2019 support.
- Generic `vc_redist.x86.exe` / `vc_redist.x64.exe` files whose exact package year cannot be proven from their location are shown as **2015+ (v14 family)** instead of a vague generic Visual C++ label.
- Older packages keep their detected generation such as **2013**, **2012**, **2010**, and **2008**.
- Truly ambiguous legacy `vcredist_*.exe` files now say **version not identified** instead of implying the wrong generation.

## V7.4.71 — existing-prefix dependency/update fix

This release is based directly on V7.4.70. It fixes existing-game dependency and update actions when Steam already has a normal real numeric `compatdata/<AppID>` prefix. Moses now reuses that exact existing prefix instead of trying to migrate it into a Moses-owned named prefix. This preserves saves/configuration and avoids the “Steam already has a real compatdata folder” error. New-game installation behavior is unchanged.


## V7.4.70 — live update-chain progress

This release is based directly on V7.4.68. It keeps the existing local batch-update engine and adds only a small live progress window for multi-selected update chains.

- Shows the selected game name in the window title.
- Shows every ordered update as **completed**, **currently installing**, or **pending**.
- Shows **Update N of M** while the normal updater window is open.
- Advances only after Moses confirms that updater has finished, then the next normal installer appears exactly as before.
- Marks a failed step and stops the chain; later updates are not launched.
- Closes automatically when the chain is finished.
- Update-only batches still do **not** download or apply artwork.
- Single-update behavior remains unchanged.

## V7.4.68 — sequential local update batches

This release is based directly on V7.4.67. It adds multi-selected local updater chaining in Dolphin and deliberately does not change the base-game install, StreamExtract, artwork, dependency, UI, or optional-Lutris behavior.

## V7.4.67 — cleanup without feature changes

This release is based directly on V7.4.66 and deliberately keeps the same GTK interface and game-management behavior. The change is limited to process/runtime cleanup after StreamExtract/installer work.

Lutris remains optional. Moses keeps V7.4.66's proven runtime selection: if Lutris is installed it may provide the GTK runtime; if it is absent, the same GTK interface runs on SteamOS' host GTK3 runtime. Steam/Proton features do not require Lutris.

A small SteamOS/KDE helper for standalone Windows `.exe` games using **Steam / Proton by default**, with **Smart Automatic / Lutris** available for games that need extra compatibility help.

<img width="663" height="630" alt="image" src="https://github.com/user-attachments/assets/49f695dc-24c1-4582-91dc-03bf8364a71a" />   <img width="548" height="427" alt="image" src="https://github.com/user-attachments/assets/286f9ebf-d08a-466c-81e3-f8fd4580f71d" />


## Features

- **Double-click a Windows `.exe`** → opens the Moses OneClick installer with four choices:
  - **Install as a new game**
  - **Install into an existing game**
  - **Run as game tool**
  - **Add existing game to Steam (no install)**
- **Double-click an installer `.iso`** → Moses mounts it **read-only**, finds the installer inside, and opens the same Game Installer used for `.exe` files. No manual ISO extraction is needed.
- Standalone ISO installs can optionally **delete the ISO after a successful installation**. The ISO is kept by default.
- **Steam / Proton is the default backend.** New games are installed into their own Proton prefix and become normal non-Steam shortcuts that can later use Proton Experimental, GE-Proton or another compatibility tool from Steam Properties.
- **Smart Automatic / Lutris** is available for older or troublesome games. It can use Lutris install recipes, resolve known dependencies/runtimes and apply compatibility fixes automatically.
- The installer window has its own **Steam / Proton ↔ Smart Automatic / Lutris selector**, so you can change backend for one installation without changing your saved default.
- Choose between **internal storage or a supported external drive** when installing a game.
- External games are tracked by the drive's **filesystem UUID**, allowing Moses OneClick to reconnect them after unplugging/replugging the drive and keep them usable from both Desktop Mode and Gaming Mode.
- External-drive preparation supports:
  - **Btrfs** — recommended for SteamOS-only game drives and compatible with Space Saver
  - **ext4** — simple and reliable for SteamOS-only use
  - **NTFS** — useful for drives shared between SteamOS and Windows
- External drives can be given a custom name/label during formatting. Destructive formatting always requires explicit confirmation.
- **Btrfs Space Saver** can deduplicate matching data in approved Proton/Wine prefix locations to reduce duplicate storage use.
- Automatically creates and verifies the final **Steam / Gaming Mode shortcut** after installation.
- Smart update detection recognizes common updater/patch names and can run updates inside an installed game's existing Steam Proton or Lutris Wine prefix.
- **Dependency Library + per-game dependency manager** — **Install / Repair Dependencies is always available**, even when no game is installed. With no game selected it opens Library mode so you can download/import dependency packs and inspect the shared cache. With exactly one game selected it also lets you install chosen redistributables inside that exact Steam Proton or Lutris Wine prefix. **Nothing is installed automatically** and all choices start unchecked.
- Recognizes common dependency installers such as **Microsoft Visual C++ Redistributables (x86/x64), DirectX Legacy Runtime, PhysX, OpenAL, XNA, .NET and VulkanRT**. Dependency scanning/installation supports both `.exe` and `.msi` packages, including XNA MSI installers.
- **Shared runtime installer cache** at `~/.local/share/oneclick-exe/runtime-cache/` automatically collects known redistributable installer sources found with installed/added games, deduplicates identical files by **SHA-256**, and reuses them later while keeping actual dependency installation isolated per game prefix. You can also place your own known redistributable `.exe`, `.msi`, and supported component `.zip` files anywhere inside this folder.
- **Portable Vulkan component bundles** are supported for files named like `VulkanRT-...-Components.zip` placed in the runtime cache. They appear as an advanced/manual dependency; Moses detects whether the selected game EXE is x86 or x64 and copies the matching `vulkan-1.dll` **and** `vulkaninfo.exe` beside that game EXE. Existing different files are preserved beside the game as visible `.backup` copies before replacement. PDB debug files are not copied. The ZIP remains cached for reuse.
- Dependency inventory is content-deduplicated, so the same redistributable no longer appears twice if an older build or a manual cache layout left duplicate copies in different folders.
- **Dependency pack import/download** — use **Import dependency ZIP…** to safely import a local `.zip` pack into its own folder under `runtime-cache/Imported Packs`, or **Download dependency pack from GitHub** for a normal GitHub `.zip` file page, GitHub Release asset, raw URL, or other direct HTTPS ZIP. Each GitHub ZIP gets its own visible folder under `runtime-cache/GitHub Packs/<pack-name>/`, so different packs can coexist and refreshing one does not replace the others.
- **Re-added Steam shortcut dependency repair** — dependency scanning/installation can use the selected game’s current EXE/start-folder snapshot if an older removal tombstone left the Steam shortcut valid but the old registry row hidden. Deliberately re-adding an existing game now resets that stale tombstone correctly.
- **Stable Steam metadata recovery** — if an older/experimental Moses build damaged the local game registry, the manager can rebuild entries from active Steam shortcuts that point into Moses game folders. This also covers complete games added with **Find Game EXE + Add to Steam**, which do not necessarily have a Proton-prefix ownership marker. The exact selected shortcut EXE (including a launcher EXE) is preserved.
- **One-click dependency set** — **Download official dependency set** fills `runtime-cache/Official Pack` without installing anything into a game. It includes the current **VC++ v14 runtime for Visual Studio 2015–2026** (x86+x64), legacy VC++ 2013/2012/2010/2008 packages, DirectX June 2010 offline runtime, NVIDIA PhysX, **.NET Framework 4, XNA Framework 4.0 Refresh, OpenAL 1.1**, plus the Moses-hosted **VulkanRT-1.3.290.0 Components** ZIP used for game-folder Vulkan fixes. The vendor redistributables come from their official HTTPS sources; the Vulkan Components ZIP comes from the Moses OneClick GitHub repository. When 7-Zip is available Moses expands DirectX into a reusable `DXSETUP.exe` + CAB bundle; OpenAL’s official ZIP is unpacked to its reusable `oalinst.exe`.
- If a game already launches correctly with its chosen Proton/Wine version, Moses leaves the prefix alone — redistributables are a **manual troubleshooting option**, not a default installation step.
- Right-click any Windows redistributable `.exe` in Dolphin → **Run as game dependency** → choose the target game. This is useful for special cases such as a game-specific `VulkanRT-...-Installer.exe`.
- **Sequential update chains** are supported. If a follow-up package contains several updates such as `1.12.0 → 1.16.0`, `1.16.0 → 1.16.1`, and `1.16.1 → 1.17.0`, Moses automatically runs them in the correct version order before final Steam shortcut/artwork completion.
- **Move to Game Folder + Add to Steam** — right-click an already-complete game folder in Dolphin to move the whole folder into `~/.local/share/oneclick-exe/game-prefixes/Steam-Proton/`, open the same EXE/name chooser used by **Find Game EXE + Add to Steam**, then create/verify the Steam shortcut and fetch artwork through the normal existing-game workflow. The chooser appears before the move, so cancelling leaves the source folder untouched. Existing destination names are never overwritten; Moses offers a safe numbered folder instead.
- Folder scanning can recursively find likely installers or game executables while filtering obvious uninstallers, redistributables and helper files.
- Smart game-name detection cleans common version, update, build, platform and release-folder noise while keeping the name editable before continuing.
- When several possible main game executables are found, Moses OneClick lets you choose the correct one. The pencil editor can later rescan and switch the launch EXE for any managed Steam game without reinstalling it, including a manual Browse option for alternate EXEs inside the game folder.
- Automatic artwork support:
  - **Both — Steam + SteamGridDB** is the default artwork source
  - **Steam only** and **SteamGridDB only** are also available
  - Official Steam artwork is preferred first in Both mode; SteamGridDB is used only as fallback for artwork types Steam cannot provide
  - Downloads and applies **Capsule, Wide Capsule, Hero, Logo and Icon** artwork
  - Artwork is cached so unchanged images are not downloaded again
- GitHub dependency downloads accept normal GitHub file-page links (`.../blob/...`) as well as raw/release URLs; Vulkan component ZIPs are preserved intact in their own cache folder.
- **Game Tools** — run launchers, configuration utilities, Mod Organizer 2, and other Windows EXEs inside an installed game's existing Steam Proton or Lutris Wine prefix without changing the main game shortcut. V7.4.79 automatically remembers EXEs you run with **Run as game tool** or **Run + Remember EXE…**, so they appear in that game's Game Tools list next time. Existing V7.4.78 Steam game-tool launches are recovered from the Moses launch log when possible.
- **Moses OneClick Tool** provides one clean GUI with:
  - Install Game
  - **Play Game**
  - Repair Steam Shortcut
- Edit an existing Steam game name/main EXE from the pencil button; renaming keeps the same AppID/prefix and updates future artwork searches.
  - **Install / Repair Dependencies**
  - Download + Apply All Artworks
  - Complete Game Removal
  - **StreamExtract**
  - **TempOverlay**
  - **Restart Steam**
- **StreamExtract** can download and extract direct ZIP/RAR links straight into Moses OneClick without first saving the complete source archive when the archive format/server supports streaming.
- Direct-stream **RAR4/RAR5 completion is hardened** against SteamOS/libarchive's harmless end-of-stream `(null)` quirk. Moses recognizes successful `x path` member lines structurally even when SteamOS bsdtar emits them on stderr, keeps them out of the real diagnostic list, and verifies extracted RAR output against header metadata when available.
- StreamExtract supports **single links and multi-link jobs**:
  - Split RAR sets such as `Game.part1.rar`, `Game.part2.rar`, etc.
  - `.7z.001`, `.zip.001`, `.z01 + .zip`, and classic `.rar + .r00` multipart sets
  - Mixed batches containing a multipart base game plus separate update/patch archives, including **multipart update/patch sets**
- **Multi-link downloads can be changed live from 1 to 10 simultaneous downloads** while a job is running. Increasing the value starts more queued files; lowering it safely takes effect as active downloads finish.
- StreamExtract's normal performance/thermal limit applies to the **combined download traffic**, not separately to each link.
- After a multipart archive is extracted successfully, the temporary downloaded compressed parts are removed automatically.
- **Keep extracted installer files after installation** applies to installer sources such as ISO/setup/update files. For an already-complete game archive with no installer, the extracted game itself is always kept after success whether this option is on or off. When the option is on, a failed extraction also preserves completed output in a visible **StreamExtract Recovery** folder. Temporary downloaded RAR/ZIP/7z parts are still removed after successful extraction.
- If StreamExtract produces an installer ISO, Moses automatically:
  - mounts the ISO read-only
  - finds the installer
  - opens the normal Game Installer
  - keeps the ISO mounted while setup is running
  - safely unmounts it afterward
  - continues with detected follow-up updates/patches
  - finalizes the Steam shortcut and artwork only after the installation/update chain is complete
- Recognized follow-up **updates / patches / hotfixes** are opened automatically after the base game installation. Non-update companion/DLC/redist files are not blindly auto-run.
- Failed or cancelled follow-up updates are preserved instead of being silently deleted.
- **TempOverlay** provides a lightweight always-on-top temperature monitor, with a compact thermometer icon in the main Moses OneClick window.
- **Restart Steam** cleanly restarts Steam and restores the main Steam window without the unwanted KDE Screen Sharing chooser seen with some SteamOS restart paths.
- Multiple games can be selected for batch repair, artwork and removal. **Play Game** is available when exactly one game is selected.
- Complete Removal can clean the managed game entry, Steam shortcut, artwork, OneClick metadata, compatibility data and reachable game/prefix files. External games are detected first so disconnected drives are not silently treated like local storage.
- Game prefixes use readable **game-name folders** in the Moses OneClick prefix view. External prefixes remain on their external drive and are linked into the same clean named view when available.
- **Settings** includes:
  - Default installer backend
  - Artwork source
  - Saved SteamGridDB API key
  - Internal/external storage tools
  - External-drive formatting
  - Btrfs Space Saver
  - Failed-install cleanup
  - **Language: English (default) or Svenska**
  - Current Moses OneClick Tool version
- Failed Steam-native installs are tracked so incomplete OneClick Proton prefixes can be cleaned without blindly deleting unrelated Steam data.
- Uses normal KDE/GTK window frames and a consistent Moses OneClick interface.

## Requirements

- SteamOS / KDE Plasma
- Steam
- Lutris installed from **Discover / Flatpak** for Smart Automatic / Lutris installs
- Proton Experimental available in Steam for the default Steam-native install workflow
- Python 3 with the `venv` module for the integrated StreamExtract / TempOverlay tools
- Internet access during the first integrated StreamExtract / TempOverlay setup so their Python dependencies can be installed
- A free SteamGridDB API key is optional but recommended for higher-quality community artwork

## Install

### Option 1 — Konsole

```bash
bash "$HOME/Downloads/Moses_OneClick_Tool_V7.4.95/Moses_OneClick_Tool_Setup_V7.4.95.sh"
```

### Option 2 — Right-click → Run in Konsole

1. Right-click `Moses_OneClick_Tool_Setup_V7.4.95.sh`
2. **Properties → Permissions**
3. Enable **Is executable**
4. Right-click again → **Run in Konsole**

Then close and reopen Dolphin once so KDE refreshes the Moses OneClick context-menu actions and file associations.


## Usage

<img width="398" height="548" alt="image" src="https://github.com/user-attachments/assets/23746d3d-26be-47d8-93bc-556ba6efc248" />

**Install a new game:** double-click its installer `.exe`, double-click an installer `.iso`, or open **Moses OneClick Tool → Install Game**. Choose Steam / Proton or Smart Automatic / Lutris and select internal or external storage if needed.

**Install from ISO:** double-click the `.iso`. Moses mounts it read-only, finds the installer and opens the normal Game Installer. The image stays mounted until setup is finished and is then safely unmounted.

**Install into an existing game:** open a patch, update, DLC, mod or launcher installer and choose **Install into an existing game**, then select the game whose existing prefix should be used. StreamExtract follow-up updates can be detected and chained automatically.

**Dependencies / redistributables:** open **Install / Repair Dependencies** at any time. With no game selected, Moses opens **Dependency Library** mode so you can download the official pack, download your GitHub ZIP, import a local ZIP, or open the cache even on a fresh installation with zero games. With exactly one managed game selected, Moses also scans that game and can install selected dependencies into its prefix. The shared cache is at `~/.local/share/oneclick-exe/runtime-cache/`. **Every dependency starts unchecked**: if the game already works, install nothing. If it does not launch, explicitly select only the VC++/DirectX/PhysX/OpenAL/XNA/.NET/VulkanRT installer(s) you want to try; normal `.exe`/`.msi` installers run only inside that game’s existing Proton/Wine prefix. Use **Import dependency ZIP…** for a pack you downloaded manually, **Download official dependency set** for the one-click curated set (including the reusable Vulkan Components ZIP), or **Download dependency pack from GitHub** for your own reusable HTTPS ZIP. You can also right-click a local redistributable `.exe` → **Run as game dependency** and choose the target game. A cached `VulkanRT-...-Components.zip` is handled differently: Moses detects the target game EXE architecture, copies the matching `vulkan-1.dll` and `vulkaninfo.exe` beside the game EXE, and makes visible `.backup` copies of different existing files before replacement.

**StreamExtract — single link:** paste a direct ZIP/RAR link, choose storage/performance options, then use **Download & Extract**. After extraction Moses continues into the normal game/ISO installer workflow.

**StreamExtract — multiple links:** paste multiple direct links one per line. Moses detects supported multipart sets and separate follow-up archives automatically. Use **Multi-link downloads** to choose between **1 and 10 simultaneous downloads**, and you can change that value while downloading.

**Keep installer sources:** enable **Keep extracted installer files after installation** if you want to keep the resulting ISO/extracted installer source after a successful installation. Temporary compressed multipart files are still cleaned after successful extraction.

**Already have a complete game folder:** right-click the folder → **Move to Game Folder + Add to Steam** if you want Moses to physically move the whole folder into its internal Steam-Proton game folder first, then choose the EXE/name and continue with the normal Steam shortcut + artwork flow. Use **Find Game EXE + Add to Steam** when you want the game to stay exactly where it already is. You can also open the game's `.exe` and choose **Add existing game to Steam (no install)**.

**Manage games:** Application Launcher → **Moses OneClick Tool**.

**Play a game:** select one game in Moses OneClick Tool → **Play Game**.

**Artwork:** select one or more games → **Download + Apply All Artworks**. Configure the artwork source and optional SteamGridDB API key under **Settings**.

**Restart Steam:** use the small **Restart Steam** button at the bottom-left of the main window whenever you want Moses OneClick to close and reopen Steam automatically.

**External game drive:** connect the drive before launching an external game. Moses OneClick tracks prepared drives by UUID so reconnecting the same drive does not depend on its temporary mount-folder name.

**Language:** Settings → About → Language → choose **English** or **Svenska**. English is the default.

## Uninstall this integration

```bash
bash "$HOME/Downloads/Moses_OneClick_Tool_V7.4.95/Moses_OneClick_Tool_Uninstall_V7.4.95.sh"
```

This removes the Moses OneClick helper, integration files, settings and OneClick caches. It does **not** automatically delete your installed games or existing Steam/Lutris game data unless you explicitly remove those games through the tool first.

## V7.4.68

- **Batch local updates from Dolphin:** select two or more Windows updater `.exe` files, right-click, then use the existing **Run as game update / patch** action. Dolphin now passes the entire selection to Moses.
- **StreamExtract-style sequential installer chain:** Moses chooses the target game/prefix once, opens the first normal updater window, waits for it to finish, then opens the next updater automatically until the chain is complete.
- **Version-range ordering:** selected filenames such as `1.130.1 - 1.526`, `1.526 - 2.629`, `2.629 - 2.727`, `2.727 - 2.810` are connected by matching destination-to-source versions, so Dolphin selection order does not matter. Single dotted-version updater names are sorted lowest to highest. Ambiguous/unconnected selections stop before installation rather than guessing.
- **Same prefix throughout:** every selected updater uses the one Steam/Proton or optional Lutris game selected at the start.
- **Stop-on-failure:** if an updater cannot launch or does not finish successfully, later selected updates are not started.
- **No artwork on update-only batches:** this workflow never downloads, applies, replaces, or finalizes Steam artwork. Existing artwork from the separately installed base game is left untouched.
- **Single-file behavior preserved:** right-clicking one updater still behaves like the existing one-at-a-time update action.
- Based directly on V7.4.67; no StreamExtract extraction logic, main UI, TempOverlay, dependencies, game editor, removal, folder buttons, Steam shortcut artwork flow for base installs, or optional-Lutris behavior was otherwise changed.

## V7.4.67

- **Post-install application cleanup:** StreamExtract direct-installer and ISO lifecycle managers now run outside KDE's visible Moses application cgroup. Closing StreamExtract and the main tool no longer leaves the Moses application row alive just because a detached install finalizer is winding down.
- **DLC/update Wine cleanup:** follow-up Steam/Proton installers use the same payload-aware completion cleanup as normal installs. Once the real updater has exited and only Wine infrastructure remains, Moses stops that prefix's idle Wine services instead of waiting for `wineserver -w` for hours.
- **Background workers detached:** automatic artwork and dependency-cache workers run in their own transient user services instead of keeping the closed Moses application group alive.
- **StreamExtract close cleanup:** closing a finished StreamExtract window stops its UI timers and explicitly exits the Qt application. Installer lifecycle work remains safe because it is already detached.
- **No UI/feature rewrite:** V7.4.66's UI, StreamExtract extraction logic, base→DLC ordering, TempOverlay, artwork controls, game editor, dependencies, folder buttons, Steam/Proton behavior and optional Lutris backend are otherwise preserved.

## V7.4.62

- **Game Documents shortcut:** Settings → Storage now includes **Open Selected Game Documents**, which opens the selected Steam/Proton game's Windows Documents folder (normally `C:\users\steamuser\Documents`) for quick access to `.ini` and other config files.
- **Prefix-aware Documents lookup:** works with Moses' internal and external Proton prefixes and falls back across Wine user-folder names for older/imported prefixes. If Proton has not created the Windows user folders yet, Moses tells you to launch the game once first.
- **Main-window folder shortcuts:** two compact folder icons now sit beside the game selector: one opens the selected game's folder and one opens the clean **All Game Prefixes** view.
- Existing Settings folder buttons now use the same shared folder-opening logic as the new main-window shortcuts.

## V7.4.61

- **Installer process cleanup:** Proton/Wine installer processes now run in their own transient user scope when SteamOS systemd support is available, so closing the visible Game Installer no longer leaves its application group alive in KDE System Monitor.
- **Watcher lifecycle cleanup:** Steam/Proton/Lutris post-install watchers run as separate transient user services instead of remaining descendants of the desktop Game Installer.
- **Idle Wine cleanup:** after a real installer payload has finished, Moses waits briefly and stops only that prefix's leftover Wine infrastructure (`wineserver`, `services.exe`, `explorer.exe`, etc.). It does not terminate active setup/MSI/command/game payload processes.
- **Fallback preserved:** systems where the transient user-systemd path is unavailable automatically fall back to the V7.4.60 detached-process behavior rather than failing installation.

## V7.4.60

- **Always-available Steam game editor:** with exactly one managed Steam game selected, the pencil button is available even when Moses originally auto-selected the EXE.
- **Change launch EXE without reinstalling:** the editor re-scans the managed game folder/prefix for alternate `.exe` files every time it opens.
- **Manual EXE browse restored:** use **Browse…** to choose another `.exe` inside that game's managed folder when the automatic list does not contain the one you want.
- Changing the EXE keeps the existing **Steam AppID, Proton prefix, game files, artwork and compatibility settings**; only the shortcut target/start directory are updated.
- Game renaming remains in the same pencil editor and no longer depends on install-time EXE chooser history.

## V7.4.55

- **StreamExtract direct installer chains:** extracted Windows setup packages are now detected before the portable-game finalizer. Moses installs the base setup first, then applies detected DLC/update EXEs in order.
- **Numbered DLC ordering:** filenames such as `dlc1`, `dlc2`, `dlc3` are explicitly sorted numerically, so archive extraction order no longer matters.
- Base + DLC/update chains reuse the same Proton/Lutris target; Steam shortcut/artwork finalization waits until the follow-up chain is finished.
- If a DLC/update is cancelled or fails, later installers are not run and the extracted source is kept for safety.

- **Both artwork mode is now Steam-first.** Moses tries official Steam artwork first for each capsule/hero/logo/icon slot and only uses SteamGridDB when Steam has no usable asset for that slot. Steam-only and SteamGridDB-only modes are unchanged.
- SteamGridDB selection still preserves SteamGridDB's own result order: choice #1 first and choice #2 only if #1 cannot be downloaded.
- Includes the V7.4.51 **Move to Game Folder + Add to Steam** workflow and the stable immediate-stream RAR behavior.

## V7.4.64 stability recovery

V7.4.64 intentionally restores the V7.4.62 GTK/Lutris-runtime implementation after the standalone V7.4.63 Qt migration caused UI and feature regressions. No game/prefix format is changed. This build prioritizes restoring the previously working UI and behavior; Lutris is again required for the GUI runtime in this recovery release.


## V7.4.66
- Fixes KDE/Dolphin theme inheritance when folders are opened from Moses in standalone mode.
- Folder launch actions now strip Moses' private XDG/GTK/Qt environment before starting the host file manager.
- Applies to selected game folder, all prefixes, Documents, artwork, and dependency cache folder launch paths.
- No game-management, installer, StreamExtract, TempOverlay, artwork, dependency, or shortcut logic was otherwise changed from V7.4.65.

### V7.4.70
- Added **Open Selected Game Save Folder** under Settings → Storage.
- Save discovery resolves the real Steam Proton compatdata prefix, including portable/Moses installs whose visible game folder does not contain `pfx`.
- Searches common Windows save locations: Saved Games, Documents/My Games, Documents, AppData/Local, AppData/LocalLow and AppData/Roaming.
- Opens a single clear match directly; if several likely save folders are found, Moses shows a chooser.
- Removed the explanatory paragraph below the Game Folders buttons in the Storage tab, as requested.


Update in V7.4.102:
- Removed the start confirmation popup for "Move to External Drive + Add to Steam".
- Removed the final Yes/No popup asking whether to delete the original folder.
- After a successful copy, verification, and Steam registration, the original game folder is now deleted automatically.
- If that automatic deletion fails, Moses shows an error instead of silently keeping the folder.


## V7.4.105
- Both Dolphin **Move to Game Folder + Add to Steam** and **Move to External Drive + Add to Steam** trigger the same clean restart procedure used by the **Restart Steam** button when their move is successful.
- Complete Removal also offers to delete a leftover game-named internal Proton directory when Moses' own marker establishes that it belongs to the same AppID; all existing deletion confirmations and checks remain in place. Unmarked/unknown directories are never removed automatically.
- No changes to transfer verification, artwork downloader, or progress display.


## V7.4.107 — Apply Steam artwork match title

- **Search artwork match → Use selected game** now changes the displayed title of Moses-managed Steam/Proton games to the selected official Steam game title (for example, `Sekiro™: Shadows Die Twice - GOTY Edition`).
- Uses the same existing `rename-steam-game` helper and, if Steam is running, offers the existing safe close/finalize/reopen workflow (or defers the visible Steam title update to the next normal restart). Non-Steam shortcut AppIDs, save/Proton folders, and artwork IDs remain stable.
- Keeps both the original-name and new-name artwork-match aliases so artwork continues to resolve after the name change.
- Automatic artwork matching and the Lutris artwork-only workflow remain unchanged.
- All other functionality remains as in V7.4.106.


### V7.4.110: Revert or reapply MangoHud Level 2 in Settings -> General
- Added **Restore Stock Preset** and **Apply Moses Preset** buttons at the bottom of General.
- Restore removes just `[preset 2]` from `~/.config/MangoHud/presets.conf` (and deletes the file if no other configuration remains), letting SteamOS use the stock MangoHud Level 2 configuration.
- Apply restores the exact user-approved `[preset 2]` layout from V7.4.109.
- Other presets are preserved; changes are backed up to `presets.conf.bak.*` before modification.
- Both buttons work immediately. Refresh the performance overlay by switching it off and back to Level 2.
- The existing one-time setup marker is unchanged, so future Moses updates will not silently reapply the custom preset after restoring stock.
- No changes to game installation, removal, Steam integration, artwork, external storage, or other functions.
